# End-to-end tests (Playwright for Python + Chromium)
Drive the built app with real mouse/keyboard events (the 21-step MVP scenario, plus example-project checks).

    npm run build && npx vite preview --config apps/web/vite.config.ts --port 4173 &
    pip install playwright && playwright install chromium
    python3 tests/e2e/acceptance.py        # run from the repo root; screenshots/exports go to ./e2e-out
    python3 tests/e2e/example-project.py

They use the `?e2e` URL flag, which exposes `window.__formax` (session + UI store) for assertions only.
