import sys, os
os.makedirs('e2e-out', exist_ok=True)
from playwright.sync_api import sync_playwright
log=[]; errors=[]
def step(n, ok, note=''):
    log.append((n, ok)); print(('PASS' if ok else 'FAIL'), n, note); sys.stdout.flush()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    ctx=b.new_context(viewport={'width':1500,'height':900}, accept_downloads=True); ctx.add_init_script("try{localStorage.setItem('formax.welcomed','1')}catch(e){}"); pg=ctx.new_page()
    pg.on('console', lambda m: errors.append(m.text) if m.type=='error' else None); pg.on('pageerror', lambda e: errors.append('PAGEERROR '+str(e)))
    pg.goto('http://127.0.0.1:4173/?e2e'); pg.wait_for_selector('.plan-canvas')
    S=pg.evaluate
    pg.click('.menu:has-text("File") > button'); pg.click('text=Load example project'); pg.wait_for_timeout(400)
    step('example opens (2 levels, 0 errors)', S("__formax.session.project.levels.length")==2 and S("__formax.session.model.issues.filter(i=>i.severity==='error').length")==0)
    pg.select_option('.levelsel select','L2'); pg.wait_for_timeout(300)
    step('second level plan shows content', S("__formax.session.model.byType('wall','L2').length")==5)
    pg.click('.tabs button:has-text("Parameters")')
    pi=pg.locator('.prow:has(code:text-is("floor_height")) input'); pi.fill('3000'); pi.press('Enter'); pg.wait_for_timeout(200)
    step('floor_height drives level 2 elevation', S("__formax.session.model.levels.get('L2').elevation")==3000)
    pi=pg.locator('.prow:has(code:text-is("building_width")) input'); pi.fill('25000'); pi.press('Enter'); pg.wait_for_timeout(200)
    t=pg.locator('.perr').first.inner_text() if pg.locator('.perr').count() else ''
    step('constraint violation rejected, last valid state kept', 'fit the 20 m plot' in t and S("__formax.session.model.get('w1').length")==15000, t.replace('\n',' ')[:90])
    pi.fill('0'); pi.press('Enter'); pg.wait_for_timeout(200)
    t=pg.locator('.perr').first.inner_text() if pg.locator('.perr').count() else ''
    step('geometry conflict explained (width 0)', S("__formax.session.model.get('w1').length")==15000 and len(t)>10, t.replace('\n',' ')[:140])
    pi.fill('18000'); pi.press('Enter')
    pg.keyboard.press('F3'); pg.wait_for_timeout(1500); pg.screenshot(path='e2e-out/ex3d.png')
    pg.click('button:has-text("Orthographic")'); pg.wait_for_timeout(500); pg.click('button:has-text("Perspective")')
    with pg.expect_download() as d: pg.click('.menu:has-text("Export") > button'); pg.click('text=Elevation (SVG)')
    d.value.save_as('e2e-out/elev.svg'); svg=open('e2e-out/elev.svg').read()
    step('elevation SVG export derives from model', svg.startswith('<?xml') and '#cfe6f1' in svg and '+3.000' in svg, f'{len(svg)}B')
    pg.click('.menu:has-text("Drawing") > button'); pg.click('text=Preview elevation'); pg.wait_for_selector('.svgbox svg'); pg.screenshot(path='e2e-out/elev.png'); pg.keyboard.press('Escape')
    # autosave + recovery
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(2500)
    pg.reload(); pg.wait_for_timeout(800)
    step('autosave recovery offered after reload with unsaved work', pg.locator('.dlg:has-text("Recover unsaved work")').count()==1)
    pg.click('button:has-text("Recover")'); pg.wait_for_timeout(300)
    step('recovered project restored', S("__formax.session.project.levels.length")==2 and S("__formax.session.dirty")==True)
    # invalid file safety
    pg.click('.menu:has-text("File") > button'); 
    pg.set_input_files('input[type=file]', files=[]) if False else None
    step('no console errors', len(errors)==0, '; '.join(errors)[:300])
    b.close()
print('RESULT', sum(1 for l in log if l[1]), 'passed', sum(1 for l in log if not l[1]), 'failed')
