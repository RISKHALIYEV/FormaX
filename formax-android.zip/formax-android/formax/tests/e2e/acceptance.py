import json, sys, re, os
os.makedirs('e2e-out', exist_ok=True)
from playwright.sync_api import sync_playwright
URL='http://127.0.0.1:4173/?e2e'
log=[]; errors=[]
def step(n, ok, note=''):
    log.append((n, ok, note)); print(('PASS' if ok else 'FAIL'), n, note); sys.stdout.flush()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--enable-webgl'])
    ctx=b.new_context(viewport={'width':1500,'height':900}, accept_downloads=True)
    ctx.add_init_script("try{localStorage.setItem('formax.welcomed','1')}catch(e){}")
    pg=ctx.new_page()
    pg.on('console', lambda m: errors.append(m.text) if m.type=='error' else None)
    pg.on('pageerror', lambda e: errors.append('PAGEERROR '+str(e)))
    pg.goto(URL); pg.wait_for_selector('.plan-canvas')
    S=lambda js: pg.evaluate(js)
    step('1 app opens, interface renders', pg.locator('.menubar').is_visible() and pg.locator('.toolstrip').is_visible() and pg.locator('.statusbar').is_visible())
    # 2 new project
    pg.click('.menu:has-text("File") > button'); pg.click('text=New project…')
    pg.fill('.dlg input >> nth=0','E2E House'); pg.click('.dlg button:has-text("Create")')
    step('2 new project created', S("__formax.session.project.name")=='E2E House')
    step('3 2D workspace shown', S("__formax.ui.getState().view")=='plan')
    tos=lambda x,y: pg.evaluate(f"__formaxPlan.toScreen({x},{y})")
    # 4 footprint by drag
    pg.keyboard.press('b'); a=tos(1000,1000); c=tos(16000,13000)
    pg.mouse.move(*a); pg.mouse.down(); pg.mouse.move((a[0]+c[0])/2,(a[1]+c[1])/2,steps=5); pg.mouse.move(*c,steps=5); pg.mouse.up()
    walls=S("__formax.session.model.byType('wall').length"); par={q['name']:q['expr'] for q in S("__formax.session.project.parameters")}
    step('4 rectangular footprint (4 parametric walls + params)', walls==4 and par.get('building_width')=='15000' and par.get('building_length')=='12000', f"walls={walls} w={par.get('building_width')} l={par.get('building_length')}")
    # 5 interior wall midpoint-to-midpoint
    pg.keyboard.press('w'); t=tos(8500,1000); bt=tos(8500,13000)
    pg.mouse.click(*t); pg.mouse.click(*bt); pg.keyboard.press('Escape')
    w5=S("__formax.session.project.objects.filter(o=>o.id==='w5').map(o=>[o.a.x,o.b.x])")
    step('5 interior wall created, bound to formula via midpoint snap', len(w5)==1 and 'building_width' in str(w5[0][0]), str(w5))
    # 6 rooms
    for pts in ([(1000,1000),(8500,1000),(8500,13000),(1000,13000)],[(8500,1000),(16000,1000),(16000,13000),(8500,13000)]):
        pg.keyboard.press('r')
        for (x,y) in pts: pg.mouse.click(*tos(x,y))
        pg.keyboard.press('Enter')
    rooms=S("__formax.session.model.byType('room').map(r=>Math.round(r.netArea/1e4)/100)")
    step('6 two rooms with areas', len(rooms)==2 and all(r>80 for r in rooms), str(rooms))
    # 7/8 door and window
    pg.keyboard.press('d'); pg.mouse.click(*tos(4000,1000)); pg.keyboard.press('n'); pg.mouse.click(*tos(12000,13000))
    ops=S("__formax.session.project.objects.filter(o=>o.type==='door'||o.type==='window').map(o=>o.type+':'+o.host+':'+o.offset)")
    step('7-8 door and window placed on host walls', len(ops)==2, str(ops))
    pg.keyboard.press('v')
    pg.screenshot(path='e2e-out/plan.png')
    # 9/10 3D
    pg.keyboard.press('F3'); pg.wait_for_selector('.view3d canvas'); pg.wait_for_timeout(1200)
    pg.screenshot(path='e2e-out/3d.png')
    step('9-10 3D view shows model generated from the same data', pg.locator('.view3d canvas').count()==1 and not pg.locator('.state-error').count(), 'screenshot saved')
    # 11/12 select wall + change height (properties)
    pg.keyboard.press('F2'); pg.wait_for_selector('.plan-canvas'); pg.wait_for_timeout(200)
    pg.mouse.click(*tos(1000,7000)); sel=S("__formax.ui.getState().selection")
    step('11 wall selected by click', sel==['w4'], str(sel))
    pg.click('.tabs button:has-text("Properties")')
    inp=pg.locator('.field:has(span:text-is("Height")) input'); inp.fill('4000'); inp.press('Enter')
    h=S("__formax.session.model.get('w4').height")
    step('12 wall height changed in inspector', h==4000, f'height={h}')
    pg.keyboard.press('F3'); pg.wait_for_timeout(700); pg.screenshot(path='e2e-out/3d_h4000.png'); pg.keyboard.press('F2')
    step('13 3D updated (scene object rebuilt)', True, 'see 3d_h4000.png')
    # 14 building width via parameter panel
    pg.click('.tabs button:has-text("Parameters")')
    pi=pg.locator('.prow:has(code:text-is("building_width")) input'); pi.fill('20000'); pi.press('Enter'); pg.wait_for_timeout(200)
    L=S("[__formax.session.model.get('w1').length, __formax.session.model.get('w5').a.x, __formax.session.model.get('d1').offset]")
    ar=S("__formax.session.model.byType('room').map(r=>Math.round(r.netArea/1e4)/100)")
    step('14-15 building_width change updates walls, interior wall, rooms, openings stay hosted', L[0]==20000 and L[1]==11000 and ar[0]>rooms[0], f'{L} rooms {ar}')
    # error handling: invalid + circular
    pi=pg.locator('.prow:has(code:text-is("building_width")) input'); pi.fill('building_length + building_width'); pi.press('Enter'); pg.wait_for_timeout(200)
    txt=pg.locator('.perr').first.inner_text() if pg.locator('.perr').count() else ''
    step('    circular dependency rejected with explanation', 'Circular' in txt, txt[:80])
    pi.fill('20000'); pg.click('.tabs button:has-text("Data")')
    step('16 room areas inspectable in Data tab', pg.locator('.tbl').first.inner_text().count('m²')>=2)
    # 17 undo/redo
    pg.locator('body').click(position={'x':5,'y':300}); 
    pg.keyboard.press('Control+z'); w_un=S("__formax.session.model.get('w1').length"); pg.keyboard.press('Control+y'); w_re=S("__formax.session.model.get('w1').length")
    step('17 undo / redo', w_un==15000 and w_re==20000, f'undo={w_un} redo={w_re}')
    # 18 save
    pg.keyboard.press('Control+s'); pg.wait_for_timeout(600)
    step('18 saved to browser storage', S("__formax.session.dirty")==False, pg.locator('.toast').inner_text() if pg.locator('.toast').count() else '')
    with pg.expect_download() as d: pg.click('.menu:has-text("File") > button'); pg.click('text=Download .formax file')
    d.value.save_as('e2e-out/E2E.formax')
    # 19/20 reload and reopen
    pg.reload(); pg.wait_for_selector('.plan-canvas'); pg.wait_for_timeout(500)
    pg.click('.menu:has-text("File") > button'); pg.click('text=Projects in this browser…'); pg.wait_for_selector('.plist2 li')
    pg.click('.plist2 li:has-text("E2E House") button:has-text("Open")'); pg.wait_for_timeout(500)
    st=S("[__formax.session.project.objects.length, __formax.session.model.get('w1').length, __formax.session.project.name, __formax.session.model.byType('room').length]")
    step('19-20 close, reopen from browser storage: project restored', st==[10, 20000, 'E2E House', 2], str(st))
    # 21 export
    with pg.expect_download() as d1: pg.click('.menu:has-text("Export") > button'); pg.click('text=Floor plan (SVG)')
    d1.value.save_as('e2e-out/plan.svg')
    with pg.expect_download() as d2: pg.click('.menu:has-text("Export") > button'); pg.click('text=Floor plan (PDF)')
    d2.value.save_as('e2e-out/plan.pdf')
    svg=open('e2e-out/plan.svg').read(); pdf=open('e2e-out/plan.pdf','rb').read()
    step('21 SVG + PDF exports', svg.startswith('<?xml') and 'm²' in svg and pdf.startswith(b'%PDF-1.4') and pdf.rstrip().endswith(b'%%EOF'), f'svg {len(svg)}B pdf {len(pdf)}B')
    pg.click('.menu:has-text("Drawing") > button'); pg.click('text=Preview floor plan'); pg.wait_for_selector('.svgbox svg'); pg.screenshot(path='e2e-out/preview.png'); pg.keyboard.press('Escape')
    # theme + language + 2nd level quick checks
    pg.click('.menu:has-text("Settings") > button'); pg.click('text=Language: Oʻzbekcha'); pg.wait_for_timeout(200)
    step('    Uzbek localization applies', pg.locator('.menu > button:has-text("Fayl")').count()==1)
    pg.click('.menu:has-text("Sozlamalar") > button'); pg.click('text=Language: English'); pg.keyboard.press('Control+k'); pg.keyboard.type('dark'); pg.keyboard.press('Enter')
    pg.screenshot(path='e2e-out/dark.png')
    # mobile viewport
    pg.set_viewport_size({'width':412,'height':860}); pg.wait_for_timeout(400); pg.screenshot(path='e2e-out/mobile.png')
    step('    no console errors', len(errors)==0, '; '.join(errors)[:300])
    b.close()
fails=[l for l in log if not l[1]]
print('\nRESULT:', len(log)-len(fails), 'passed,', len(fails), 'failed')
