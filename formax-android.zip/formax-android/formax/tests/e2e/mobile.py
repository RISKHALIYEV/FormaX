# Mobile smoke test: phone viewport + touch, welcome screen, panels, back hook, overflow check.
import sys, os
from playwright.sync_api import sync_playwright
os.makedirs('e2e-out', exist_ok=True); errors=[]; res=[]
def step(n, ok, note=''): res.append(ok); print(('PASS' if ok else 'FAIL'), n, note)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-gl=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    ctx=b.new_context(viewport={'width':390,'height':780}, device_scale_factor=2, has_touch=True, is_mobile=True)
    pg=ctx.new_page(); pg.on('console', lambda m: errors.append(m.text) if m.type=='error' else None); pg.on('pageerror', lambda e: errors.append(str(e)))
    pg.goto('http://127.0.0.1:4173/?e2e'); pg.wait_for_selector('.dlg.welcome')
    step('welcome screen shows on first run', pg.locator('.dlg.welcome svg').count()>=1)
    pg.screenshot(path='e2e-out/m_welcome.png')
    pg.click('.dlg.welcome button:has-text("Open example house")'); pg.wait_for_selector('.plan-canvas')
    pg.wait_for_timeout(500)
    ov=pg.evaluate("document.documentElement.scrollWidth - window.innerWidth"); step('no horizontal page overflow', ov<=0, f'overflow={ov}')
    pg.screenshot(path='e2e-out/m_plan.png')
    pg.evaluate("window.__formax.ui.setState({panel:'left'})"); pg.wait_for_timeout(200); pg.screenshot(path='e2e-out/m_panel.png')
    step('Back closes the open panel', pg.evaluate("window.__formaxBack()") is True and pg.evaluate("__formax.ui.getState().panel")is None)
    pg.evaluate("window.__formax.ui.setState({view:'3d'})"); pg.wait_for_timeout(800); pg.screenshot(path='e2e-out/m_3d.png')
    step('Back leaves 3D view', pg.evaluate("window.__formaxBack()") is True and pg.evaluate("__formax.ui.getState().view")=='plan')
    step('Back at root is not consumed (host handles exit)', pg.evaluate("window.__formaxBack()") is False)
    st=pg.evaluate("(()=>{const r=[...document.querySelectorAll('.tool')].map(e=>e.getBoundingClientRect().height);return Math.min(...r)})()"); step('touch targets >= 44px high', st>=44, f'min={st}')
    pg.evaluate("window.__formaxOpenText('x.formax','not json')"); pg.wait_for_timeout(300)
    step('host open-file hook rejects invalid file with a dialog', pg.locator('.dlg:has-text("Cannot open")').count()==1)
    step('no console errors', not errors, str(errors[:3]))
    b.close()
print('RESULT', sum(res), 'passed', len(res)-sum(res), 'failed'); sys.exit(0 if all(res) else 1)
