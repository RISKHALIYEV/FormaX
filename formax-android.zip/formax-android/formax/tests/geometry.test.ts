import { describe, it, expect } from 'vitest';
import { v2, add, sub, dist, rotate, segmentIntersection, polygonArea, validatePolygon, wallPolygon, offsetPolygonInward, pointInPolygon, projectOnSegment, toMM, fromMM, convertLength, formatLength, polygonCentroid } from '@formax/geometry';

describe('point operations', () => {
  it('adds, subtracts, measures and rotates', () => {
    expect(add(v2(1, 2), v2(3, 4))).toEqual(v2(4, 6));
    expect(sub(v2(5, 5), v2(2, 1))).toEqual(v2(3, 4));
    expect(dist(v2(0, 0), v2(3, 4))).toBe(5);
    const r = rotate(v2(1, 0), Math.PI / 2); expect(r.x).toBeCloseTo(0); expect(r.y).toBeCloseTo(1);
    const o = rotate(v2(2, 1), Math.PI, v2(1, 1)); expect(o.x).toBeCloseTo(0); expect(o.y).toBeCloseTo(1);
  });
  it('projects a point on a segment with clamping', () => {
    expect(projectOnSegment(v2(5, 3), v2(0, 0), v2(10, 0)).point).toEqual(v2(5, 0));
    expect(projectOnSegment(v2(-5, 3), v2(0, 0), v2(10, 0)).t).toBe(0);
  });
});
describe('line intersections', () => {
  it('finds a crossing, a touching end and rejects parallel / non-overlapping', () => {
    expect(segmentIntersection(v2(0, 0), v2(10, 10), v2(0, 10), v2(10, 0))!.point).toEqual(v2(5, 5));
    expect(segmentIntersection(v2(0, 0), v2(10, 0), v2(10, 0), v2(10, 10))).not.toBeNull();
    expect(segmentIntersection(v2(0, 0), v2(10, 0), v2(0, 1), v2(10, 1))).toBeNull();
    expect(segmentIntersection(v2(0, 0), v2(1, 0), v2(5, -1), v2(5, 1))).toBeNull();
  });
});
describe('polygons', () => {
  const sq = [v2(0, 0), v2(10, 0), v2(10, 10), v2(0, 10)];
  it('area is signed by orientation', () => { expect(polygonArea(sq)).toBe(100); expect(polygonArea([...sq].reverse())).toBe(-100); });
  it('validates simple polygons and rejects bow-ties, slivers, short lists', () => {
    expect(validatePolygon(sq).valid).toBe(true);
    expect(validatePolygon([v2(0, 0), v2(10, 10), v2(10, 0), v2(0, 10)]).valid).toBe(false);
    expect(validatePolygon([v2(0, 0), v2(5, 0), v2(10, 0)]).valid).toBe(false);
    expect(validatePolygon([v2(0, 0), v2(1, 1)]).valid).toBe(false);
  });
  it('point in polygon and centroid', () => { expect(pointInPolygon(v2(5, 5), sq)).toBe(true); expect(pointInPolygon(v2(15, 5), sq)).toBe(false); expect(polygonCentroid(sq)).toEqual(v2(5, 5)); });
});
describe('wall geometry', () => {
  it('builds a thick wall rectangle, optionally extended at the ends', () => {
    expect(Math.abs(polygonArea(wallPolygon(v2(0, 0), v2(1000, 0), 200)))).toBeCloseTo(200000);
    expect(Math.abs(polygonArea(wallPolygon(v2(0, 0), v2(1000, 0), 200, true, true)))).toBeCloseTo(240000);
  });
});
describe('room boundaries', () => {
  it('offsets a polygon inward per edge (mitred)', () => {
    const net = offsetPolygonInward([v2(0, 0), v2(1000, 0), v2(1000, 800), v2(0, 800)], [50, 100, 50, 100]);
    expect(Math.abs(polygonArea(net))).toBeCloseTo((1000 - 200) * (800 - 100));
  });
  it('works for clockwise input too', () => {
    const net = offsetPolygonInward([v2(0, 0), v2(0, 800), v2(1000, 800), v2(1000, 0)], [100, 100, 100, 100]);
    expect(Math.abs(polygonArea(net))).toBeCloseTo(800 * 600);
  });
});
describe('unit conversion', () => {
  it('converts between mm, cm and m', () => {
    expect(toMM(1.5, 'm')).toBe(1500); expect(fromMM(250, 'cm')).toBe(25); expect(convertLength(3, 'm', 'cm')).toBe(300);
    expect(formatLength(3200, 'm')).toBe('3.200 m');
  });
});
