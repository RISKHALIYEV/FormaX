import { describe, it, expect } from 'vitest';
import { Session, defaultProject, addBuildingFootprint, addWall, addRoom, addOpening, addLevel, copyLevelContent, deleteObjects, wallBoxes, boxVolume, findSnap, hitTest, translate, rotateObjects, scaleObjects, duplicateObjects, centerOf, addConstraint, type ArchModel, type RWall } from '@formax/core';
import { v2 } from '@formax/geometry';

const SNAP = { tol: 200, grid: 100, endpoints: true, midpoints: true, intersections: true, edges: true, gridOn: true, level: 'L1' };
function house(): Session {
  const s = new Session(defaultProject('t'));
  expect(s.commit('footprint', (p) => addBuildingFootprint(p, { x: 0, y: 0, width: 15000, length: 12000, level: 'L1' })).ok).toBe(true);
  // interior wall from midpoint of top (y=0) to midpoint of bottom (y=length) -> bound to building_width / 2
  const m = s.model;
  const top = findSnap(m, v2(7500, 0), { ...SNAP }), bottom = findSnap(m, v2(7500, 12000), { ...SNAP });
  expect(top.kind).toBe('midpoint'); expect(bottom.kind).toBe('midpoint');
  expect(s.commit('wall', (p) => addWall(p, { a: top.ex, b: bottom.ex, level: 'L1' })).ok).toBe(true);
  expect(s.commit('rooms', (p) => { addRoom(p, { level: 'L1', name: 'Left', points: [{ x: 0, y: 0 }, { x: 'building_width / 2', y: 0 }, { x: 'building_width / 2', y: 'building_length' }, { x: 0, y: 'building_length' }] }); addRoom(p, { level: 'L1', name: 'Right', points: [{ x: 'building_width / 2', y: 0 }, { x: 'building_width', y: 0 }, { x: 'building_width', y: 'building_length' }, { x: 'building_width / 2', y: 'building_length' }] }); }).ok).toBe(true);
  return s;
}
describe('architecture objects', () => {
  it('creates data-backed objects with ids, layers, materials, parents', () => {
    const s = house(); const w = s.project.objects.find((o) => o.id === 'w1')!;
    expect(w).toMatchObject({ type: 'wall', layer: 'walls', level: 'L1', parent: 'L1', material: 'plaster' });
    expect(s.model.byType('wall').length).toBe(5); expect(s.model.byType('room').length).toBe(2);
  });
  it('computes net room areas from wall faces', () => {
    const s = house(); const [l, r] = [s.model.get<any>('r1'), s.model.get<any>('r2')];
    // left room: 7500 x 12000 centre-line; faces: ext wall 100 each side, interior wall 50
    expect(l.grossArea).toBe(7500 * 12000);
    expect(l.netArea).toBeCloseTo((7500 - 100 - 50) * (12000 - 200), 0);
    expect(r.netArea).toBeCloseTo(l.netArea, 0);
  });
  it('places doors/windows on host walls and rejects ones that do not fit', () => {
    const s = house();
    expect(s.commit('door', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' })).ok).toBe(true);
    expect(s.commit('window', (p) => addOpening(p, { type: 'window', host: 'w2', offset: 6000, level: 'L1' })).ok).toBe(true);
    const bad = s.commit('bad', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 100, level: 'L1' }));
    expect(bad.ok).toBe(false); expect(bad.error).toMatch(/does not fit on wall w1/);
    expect(s.project.objects.filter((o) => o.type === 'door').length).toBe(1);
  });
  it('splits walls around openings with correct remaining volume', () => {
    const s = house(); s.commit('d', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' })); s.commit('n', (p) => addOpening(p, { type: 'window', host: 'w1', offset: 8000, level: 'L1' }));
    const w = s.model.get<RWall>('w1')!, boxes = wallBoxes(w, s.model.openingsOf('w1'));
    const vol = boxes.reduce((a, b) => a + boxVolume(b, w.thickness), 0);
    const full = (w.length + w.thickness) * w.height * w.thickness;
    expect(vol).toBeCloseTo(full - 900 * 2100 * 200 - 1200 * 1200 * 200, 3);
  });
});
describe('parametric behaviour of the building', () => {
  it('changing building_width updates walls, interior wall, rooms and openings stay hosted', () => {
    const s = house(); s.commit('d', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' }));
    const before = s.model.get<any>('r1').netArea;
    const res = s.setParameter('building_width', '20000'); expect(res.ok).toBe(true);
    expect(s.model.get<RWall>('w1')!.length).toBe(20000); expect(s.model.get<RWall>('w2')!.a.x).toBe(20000);
    const mid = s.model.get<RWall>('w5')!; expect(mid.a.x).toBe(10000); expect(mid.b.x).toBe(10000);
    expect(s.model.get<any>('r1').netArea).toBeGreaterThan(before); expect(s.model.get<any>('r1').grossArea).toBe(10000 * 12000);
    expect(s.model.engine.dependentsOf('building_width').length).toBeGreaterThan(5);
  });
  it('is incremental: only dependents of the changed parameter are recomputed', () => {
    const s = house(); const res = s.setParameter('building_length', '9000');
    expect(res.ok).toBe(true); const rc = res.value!.recomputed;
    expect(rc).toContain('building_length'); expect(rc).not.toContain('building_width'); expect(rc.some((id) => id.startsWith('w1.a.y'))).toBe(false);
    expect(res.value!.affectedObjects).toContain('w2');
  });
  it('rejects changes that break geometry and keeps the last valid state', () => {
    const s = house(); s.commit('d', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' }));
    const r = s.setParameter('building_width', '2000'); // wall w1 shorter than door position + room polygons collapse
    expect(r.ok).toBe(false); expect(r.error).toBeTruthy();
    expect(s.project.parameters.find((p) => p.name === 'building_width')!.expr).toBe('15000'); expect(s.model.get<RWall>('w1')!.length).toBe(15000); expect(s.dirty).toBe(true);
  });
  it('rejects invalid / circular / unknown formulas with explanations', () => {
    const s = house();
    expect(s.setParameter('building_width', 'building_length + building_width').error).toMatch(/Circular/);
    expect(s.setParameter('building_width', '10 +').error).toMatch(/Invalid formula/);
    expect(s.setParameter('building_width', 'nope * 2').error).toMatch(/Unknown parameter/);
    expect(s.model.get<RWall>('w1')!.length).toBe(15000);
  });
  it('enforces user constraints', () => {
    const s = house(); expect(s.commit('c', (p) => addConstraint(p, 'Max width', 'building_width <= 20000', 'Plot is only 20 m wide')).ok).toBe(true);
    const r = s.setParameter('building_width', '25000'); expect(r.ok).toBe(false); expect(r.error).toMatch(/Plot is only 20 m wide/);
    expect(s.setParameter('building_width', '18000').ok).toBe(true);
  });
  it('wall height edits only affect that wall; floor_height drives all', () => {
    const s = house(); expect(s.commit('h', (p) => { (p.objects.find((o) => o.id === 'w1') as any).height = 4000; }).ok).toBe(true);
    expect(s.model.get<RWall>('w1')!.height).toBe(4000); expect(s.model.get<RWall>('w2')!.height).toBe(3200);
    s.setParameter('floor_height', '3000'); expect(s.model.get<RWall>('w2')!.height).toBe(3000); expect(s.model.get<RWall>('w1')!.height).toBe(4000);
  });
  it('supports a second storey with elevation derived from floor_height', () => {
    const s = house(); s.commit('lvl', (p) => { const id = addLevel(p); copyLevelContent(p, 'L1', id); });
    expect(s.model.levels.get('L2')!.elevation).toBe(3200); expect(s.model.byType('wall', 'L2').length).toBe(5);
    s.setParameter('floor_height', '3000'); expect(s.model.levels.get('L2')!.elevation).toBe(3000);
    s.setParameter('building_width', '16000'); expect(s.model.byType('wall', 'L2').find((w) => w.id !== 'w5')!.length).toBeGreaterThan(0);
  });
});
describe('undo / redo', () => {
  it('undoes and redoes commits and parameter edits', () => {
    const s = house(); const n = s.project.objects.length;
    s.setParameter('building_width', '18000'); expect(s.model.get<RWall>('w1')!.length).toBe(18000);
    expect(s.undo()).toBe(true); expect(s.model.get<RWall>('w1')!.length).toBe(15000);
    expect(s.redo()).toBe(true); expect(s.model.get<RWall>('w1')!.length).toBe(18000);
    s.undo(); s.undo(); expect(s.project.objects.length).toBeLessThan(n); expect(s.canRedo).toBe(true);
    s.commit('x', (p) => addRoom(p, { level: 'L1', points: [{ x: 0, y: 0 }, { x: 1000, y: 0 }, { x: 1000, y: 1000 }] })); expect(s.canRedo).toBe(false);
  });
  it('failed transactions do not touch history', () => {
    const s = house(); const u = s.undoLabel; s.setParameter('building_width', '5 +'); expect(s.undoLabel).toBe(u);
  });
});
describe('selection, snapping and editing', () => {
  it('hit-tests walls, openings, rooms with sensible priority', () => {
    const s = house(); s.commit('d', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' }));
    expect(hitTest(s.model, v2(3000, 0), 50, 'L1')).toBe('d1'); expect(hitTest(s.model, v2(10000, 0), 50, 'L1')).toBe('w1');
    expect(hitTest(s.model, v2(3000, 6000), 50, 'L1')).toBe('r1'); expect(hitTest(s.model, v2(-5000, -5000), 50, 'L1')).toBeNull();
  });
  it('snaps to endpoints, intersections, midpoints and grid and keeps formulas', () => {
    const s = house();
    const e = findSnap(s.model, v2(15050, 40), { ...SNAP }); expect(e.kind).toBe('endpoint'); expect(e.ex.x).toBe('building_width');
    expect(findSnap(s.model, v2(30, 6010), { ...SNAP, endpoints: false }).kind).toBe('midpoint');
    expect(findSnap(s.model, v2(3010, 4040), { ...SNAP }).point).toEqual(v2(3000, 4000));
    const i = findSnap(s.model, v2(7510, 20), { ...SNAP, midpoints: false, endpoints: false }); expect(i.kind).toBe('intersection'); expect(String(i.ex.x)).toMatch(/building_width/);
  });
  it('move keeps formulas; rotate/scale/duplicate/delete work', () => {
    const s = house();
    s.commit('move', (p) => translate(p, ['w1'], 1000, 0)); expect(s.model.get<RWall>('w1')!.a.x).toBe(1000);
    s.undo();
    s.commit('dup', (p) => duplicateObjects(p, ['w1'], 0, 500)); expect(s.model.byType('wall').length).toBe(6);
    s.commit('rot', (p, m) => rotateObjects(p, m, ['w5'], Math.PI / 2, centerOf(m, ['w5']))); const w = s.model.get<RWall>('w5')!; expect(Math.abs(w.a.y - w.b.y)).toBeLessThan(1e-3);
    s.commit('scale', (p, m: ArchModel) => scaleObjects(p, m, ['w5'], 2, centerOf(m, ['w5']))); expect(s.model.get<RWall>('w5')!.length).toBeCloseTo(24000, 0);
    expect(s.commit('bad scale', (p, m) => scaleObjects(p, m, ['w5'], -1, v2(0, 0))).ok).toBe(false);
    s.commit('del', (p) => deleteObjects(p, ['w1'])); expect(s.model.get('w1')).toBeUndefined();
  });
  it('deleting a wall removes its hosted openings', () => {
    const s = house(); s.commit('d', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' })); s.commit('del', (p) => deleteObjects(p, ['w1']));
    expect(s.project.objects.some((o) => o.type === 'door')).toBe(false);
  });
});
import { addParameter } from '@formax/core';
describe('parameter names', () => {
  it('rejects reserved / prototype-polluting names', () => {
    const s = new Session(defaultProject());
    for (const n of ['__proto__', 'constructor', 'pi', '1abc', 'a b', 'if']) expect(s.commit('p', (p) => addParameter(p, n, '1')).ok).toBe(false);
    expect(s.commit('p', (p) => addParameter(p, 'plot_width', '20000')).ok).toBe(true);
  });
});
