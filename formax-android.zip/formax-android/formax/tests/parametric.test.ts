import { describe, it, expect } from 'vitest';
import { evaluateExpr, parseExpr, ExprError, Engine } from '@formax/parametric';

const load = (o: Record<string, string>) => { const e = new Engine(); const r = e.load(Object.fromEntries(Object.entries(o).map(([k, v]) => [k, { expr: v, referenceable: true }]))); return { e, r }; };

describe('formula parser', () => {
  it('evaluates arithmetic with precedence, unary, power, functions', () => {
    expect(evaluateExpr('1 + 2 * 3')).toBe(7); expect(evaluateExpr('(1 + 2) * 3')).toBe(9); expect(evaluateExpr('-2 ^ 2')).toBe(-4);
    expect(evaluateExpr('2 ^ 3 ^ 2')).toBe(512); expect(evaluateExpr('10 % 4')).toBe(2); expect(evaluateExpr('max(1, 5, 3) + sqrt(16)')).toBe(9);
    expect(evaluateExpr('if(3 > 2, 10, 20)')).toBe(10); expect(evaluateExpr('1.5e3')).toBe(1500);
  });
  it('supports booleans and comparisons', () => {
    expect(evaluateExpr('true && !false')).toBe(true); expect(evaluateExpr('2 >= 3 || 1 == 1')).toBe(true);
  });
  it('reports clear errors instead of throwing generic ones', () => {
    expect(() => evaluateExpr('1 +')).toThrow(ExprError); expect(() => evaluateExpr('1 / 0')).toThrow(/Division by zero/);
    expect(() => evaluateExpr('foo + 1')).toThrow(/Unknown parameter 'foo'/); expect(() => evaluateExpr('1 + true')).toThrow(/boolean/);
    expect(() => evaluateExpr('bar(1)')).toThrow(/Unknown function/); expect(() => parseExpr('2 $ 3')).toThrow(/Unexpected character/); expect(() => evaluateExpr('')).toThrow();
  });
  it('is not an eval: code-like input is rejected as a syntax error', () => {
    for (const s of ['process.exit()', 'constructor.constructor("1")()', 'alert(1);', '__proto__', 'constructor', 'toString(1)', 'constructor(1)']) expect(() => evaluateExpr(s)).toThrow();
  });
});
describe('dependency evaluation', () => {
  it('resolves formulas with multiple dependencies in the right order', () => {
    const { e, r } = load({ window_width: 'room_width * 0.35', room_width: 'building_width / 2', building_width: '15000', area: 'room_width * building_length', building_length: '12000' });
    expect(r.ok).toBe(true);
    expect(e.value('room_width')).toBe(7500); expect(e.value('window_width')).toBe(2625); expect(e.value('area')).toBe(90000000);
    const o = e.order(); expect(o.indexOf('building_width')).toBeLessThan(o.indexOf('room_width')); expect(o.indexOf('room_width')).toBeLessThan(o.indexOf('window_width'));
  });
  it('recomputes only affected nodes (incremental)', () => {
    const { e } = load({ a: '10', b: 'a * 2', c: 'b + 1', x: '5', y: 'x * 2' });
    const r = e.update({ a: { expr: '20', referenceable: true } });
    expect(r.ok).toBe(true); expect(new Set(r.recomputed)).toEqual(new Set(['a', 'b', 'c']));
    expect(e.value('c')).toBe(41); expect(e.value('y')).toBe(10);
  });
  it('detects circular dependencies and names the cycle', () => {
    const { e, r } = load({ a: 'b + 1', b: 'c + 1', c: 'a + 1', ok: '1' });
    expect(r.ok).toBe(false); expect(r.errors.a).toMatch(/Circular dependency: .*a.*b.*c|Circular dependency/); expect(e.findCycles().length).toBeGreaterThan(0); expect(e.value('ok')).toBe(1);
    expect(load({ s: 's + 1' }).r.errors.s).toMatch(/Circular/);
  });
  it('flags invalid formulas and propagates the error to dependents', () => {
    const { r } = load({ a: '1 +', b: 'a + 1', c: 'zzz', d: '1/0' });
    expect(r.errors.a).toMatch(/Invalid formula/); expect(r.errors.b).toMatch(/Depends on 'a'/); expect(r.errors.c).toMatch(/Unknown parameter/); expect(r.errors.d).toMatch(/Division/);
  });
  it('transactions revert completely when an edit introduces an error', () => {
    const { e } = load({ w: '100', h: 'w / 2' });
    const bad = e.transaction({ w: { expr: '0', referenceable: true }, h: { expr: '10 / w', referenceable: true } });
    expect(bad.ok).toBe(false); expect(e.value('w')).toBe(100); expect(e.value('h')).toBe(50); expect(e.errors).toEqual({});
    const cyc = e.transaction({ w: { expr: 'h', referenceable: true } }); expect(cyc.ok).toBe(false); expect(e.value('w')).toBe(100);
  });
  it('recovers when the broken formula is fixed', () => {
    const { e } = load({ a: '1 +', b: 'a + 1' }); const r = e.update({ a: { expr: '4', referenceable: true } });
    expect(r.ok).toBe(true); expect(e.value('b')).toBe(5);
  });
});
