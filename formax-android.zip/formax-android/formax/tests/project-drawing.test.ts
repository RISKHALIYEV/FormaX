import { describe, it, expect } from 'vitest';
import { Session, defaultProject, addBuildingFootprint, addWall, addRoom, addOpening, findSnap } from '@formax/core';
import { serializeProject, parseProjectFile, makeAsset, FORMAT_VERSION } from '@formax/project-format';
import { buildPlan, buildElevation, layoutSheet, toSVG, toPDF } from '@formax/drawing';
import { v2 } from '@formax/geometry';

function sample() {
  const s = new Session(defaultProject('Sample'));
  s.commit('f', (p) => addBuildingFootprint(p, { x: 0, y: 0, width: 12000, length: 9000, level: 'L1' }));
  const o = { tol: 200, grid: 100, endpoints: true, midpoints: true, intersections: true, edges: true, gridOn: true, level: 'L1' };
  const a = findSnap(s.model, v2(6000, 0), o), b = findSnap(s.model, v2(6000, 9000), o);
  s.commit('w', (p) => addWall(p, { a: a.ex, b: b.ex, level: 'L1' }));
  s.commit('r', (p) => { addRoom(p, { level: 'L1', name: 'Living', points: [{ x: 0, y: 0 }, { x: 'building_width / 2', y: 0 }, { x: 'building_width / 2', y: 'building_length' }, { x: 0, y: 'building_length' }] }); addRoom(p, { level: 'L1', name: 'Bedroom', points: [{ x: 'building_width / 2', y: 0 }, { x: 'building_width', y: 0 }, { x: 'building_width', y: 'building_length' }, { x: 'building_width / 2', y: 'building_length' }] }); });
  s.commit('d', (p) => addOpening(p, { type: 'door', host: 'w1', offset: 3000, level: 'L1' }));
  s.commit('n', (p) => addOpening(p, { type: 'window', host: 'w1', offset: 9000, level: 'L1' }));
  return s;
}
describe('project file format', () => {
  it('saves and reloads identically (round trip) and rebuilds the same model', () => {
    const s = sample(), text = serializeProject(s.project), r = parseProjectFile(text);
    expect(r.ok).toBe(true); if (!r.ok) return;
    expect(r.project).toEqual(s.project);
    const s2 = new Session(r.project); expect(s2.model.byType('wall').length).toBe(5); expect(s2.model.get<any>('r1').netArea).toBeCloseTo(s.model.get<any>('r1').netArea, 6); expect(s2.model.issues).toEqual([]);
  });
  it('is versioned and validates schema', () => {
    const s = sample(), f = JSON.parse(serializeProject(s.project)); expect(f.format).toBe('formax'); expect(f.schemaVersion).toBe(FORMAT_VERSION);
    f.schemaVersion = 99; expect(parseProjectFile(JSON.stringify(f))).toMatchObject({ ok: false });
    expect((parseProjectFile(JSON.stringify(f)) as any).errors[0]).toMatch(/newer/);
    expect(parseProjectFile('{nope')).toMatchObject({ ok: false }); expect(parseProjectFile('{"format":"other"}')).toMatchObject({ ok: false });
    const g = JSON.parse(serializeProject(s.project)); delete g.project.levels; expect(parseProjectFile(JSON.stringify(g))).toMatchObject({ ok: false });
    const h = JSON.parse(serializeProject(s.project)); h.project.objects.push({ ...h.project.objects[0] }); expect((parseProjectFile(JSON.stringify(h)) as any).errors.join()).toMatch(/duplicate object id/);
    const k = JSON.parse(serializeProject(s.project)); k.project.objects.find((o: any) => o.type === 'door').host = 'zz'; expect((parseProjectFile(JSON.stringify(k)) as any).errors.join()).toMatch(/missing host wall/);
  });
  it('detects corruption and supports recovery mode', () => {
    const s = sample(), f = JSON.parse(serializeProject(s.project)); f.project.parameters[0].expr = '9999';
    const bad = parseProjectFile(JSON.stringify(f)); expect(bad.ok).toBe(false); expect((bad as any).errors[0]).toMatch(/Integrity/);
    const rec = parseProjectFile(JSON.stringify(f), { ignoreIntegrity: true }); expect(rec.ok).toBe(true); expect((rec as any).warnings.length).toBe(1);
  });
  it('checks asset integrity', () => {
    const s = sample(), a = makeAsset('a1', 'note.txt', 'text/plain', btoa('hello'));
    expect(parseProjectFile(serializeProject(s.project, { assets: [a] })).ok).toBe(true);
    const f = JSON.parse(serializeProject(s.project, { assets: [a] })); f.assets[0].data = btoa('tampered'); expect((parseProjectFile(JSON.stringify(f)) as any).errors[0]).toMatch(/Asset 'a1' is corrupted/);
  });
});
describe('drawing export', () => {
  it('floor plan derives from the model: changing the width changes the drawing', () => {
    const s = sample(), L = (sc: Session) => layoutSheet(buildPlan(sc.model, 'L1'), { paper: 'A3', scale: 100 });
    const a = toSVG(L(s)); s.setParameter('building_width', '14000'); const b = toSVG(L(s));
    expect(a).not.toEqual(b); expect(a).toContain('Living'); expect(a).toMatch(/\d+\.\d\d m²/); expect(a).toContain('12200'); expect(b).toContain('14200');
  });
  it('produces well-formed SVG and a structurally valid PDF', () => {
    const s = sample(), lay = layoutSheet(buildPlan(s.model, 'L1'), { paper: 'A3', scale: 'auto', projectName: 'Sample' }); expect(lay.fits).toBe(true);
    const svg = toSVG(lay); expect(svg.startsWith('<?xml')).toBe(true); expect(svg).toContain('</svg>'); expect(svg).toContain('Scale 1:');
    const pdf = toPDF(lay), txt = Buffer.from(pdf).toString('latin1'); expect(txt.startsWith('%PDF-1.4')).toBe(true); expect(txt.trimEnd().endsWith('%%EOF')).toBe(true);
    const xrefPos = Number(/startxref\n(\d+)/.exec(txt)![1]); expect(txt.slice(xrefPos, xrefPos + 4)).toBe('xref');
    const offs = [...txt.matchAll(/(\d{10}) 00000 n/g)].map((m) => Number(m[1])); offs.forEach((o, i) => expect(txt.slice(o, o + 7)).toBe(`${i + 1} 0 obj`));
    const len = Number(/\/Length (\d+)/.exec(txt)![1]); const st = txt.indexOf('stream\n') + 7; expect(txt.slice(st + len, st + len + 9)).toBe('endstream');
  });
  it('generates elevations with openings from the model', () => {
    const s = sample(), sh = buildElevation(s.model, 'south'); expect(sh.prims.length).toBeGreaterThan(8);
    expect(toSVG(layoutSheet(sh, { scale: 'auto' }))).toContain('#cfe6f1');
  });
});
