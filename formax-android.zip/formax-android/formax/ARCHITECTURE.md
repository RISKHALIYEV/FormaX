# Architecture

## Layers (dependencies point downward; the shared core never imports React or the DOM)
```
apps/web (React UI, Plan2D canvas, panels, storage)      apps/desktop (Tauri)   apps/android (WebView)
        │
packages/core            Session: project + model + undo/redo + transactions
packages/rendering       Three.js Viewport3D (only package that touches WebGL)
packages/drawing         Plan / elevation → primitives → SVG / PDF
packages/project-format  .formax serialize / validate / parse
packages/architecture    Project schema, ArchModel (resolution + validation), ops, snapping, hit-testing, wall meshing
packages/parametric      Expression parser, dependency Engine
packages/geometry        2D computational geometry, units
packages/localization    en / uz dictionaries
```
`packages/ui` from the suggested layout was not created: UI components live in `apps/web/src` because the only UI is the React app. They can be split out when a second UI shell exists.

## Single source of truth
The **Project** (JSON) holds parameters, constraints, levels, layers, materials and objects. Every geometric field is `number | formula`.
`ArchModel` resolves a Project into numeric objects (`RWall`, `RRoom`, …) using the parametric `Engine`. The 2D editor, 3D renderer,
inspector, schedules and drawings all read the *resolved model*; nothing stores pixel coordinates. Internal unit: **millimetres**.

## Parametric core (`packages/parametric`)
- **Formula evaluator**: tokenizer + recursive-descent parser → AST → tree-walking evaluator. Numbers, booleans, `+ - * / % ^`, comparisons, `&& || !`, `if()`, `min max abs sqrt round floor ceil sin cos tan rad deg pow clamp`, `pi`. Never `eval` / `Function`. Own-property lookups only (a prototype-name bug was found and fixed by a test).
- **Dependency graph** (`Engine`): nodes = parameters (referenceable) + object fields / constraints (leaves). Edges derived from identifiers.
- **Cycle detection**: DFS; the cycle path is reported (`a → b → a`) and affected nodes are marked invalid.
- **Incremental recomputation**: an update re-evaluates only the changed nodes and their transitive dependents, in topological order.
- **Transactions**: `Engine.transaction` reverts on any new error. `ArchModel.changeParameter` additionally re-validates geometry (door fits wall, polygons valid, constraints hold) and reverts if *new* errors appear. `Session.commit` does the same for structural edits (draft copy → rebuild → compare error sets → accept or reject).
- **Change history**: parameter edits are logged in the project; undo/redo uses project snapshots (max 200).

Trade-off: structural edits (add/delete/move objects) rebuild the whole model (O(objects)); only parameter edits are incrementally recomputed. This is fast at MVP scale and keeps the code simple; a per-object incremental path is the natural next step.

## Architecture objects
`wall, room, door, window, slab, roof(flat), column, beam` + annotation/draft objects `dimension, line, polyline, circle`.
Every object has `id, type, name, layer, level, material, parent` plus type-specific expression fields. *Building* is the project itself; *Floor* is a `Level` (elevation/height are formulas, e.g. a second level at `floor_height`). Openings reference a host wall (`host`) and are positioned by `offset` along it. Room area = polygon area after insetting each edge by half the thickness of the wall it runs along (net area); gross (centre-line) area is also reported.
Snapping carries formulas: snapping to a wall's midpoint produces `(a + b) / 2` in terms of the original coordinate formulas, which is why the partition wall follows `building_width / 2`.

## Geometry kernel decision (Open CASCADE evaluation)
Open CASCADE Technology is the only realistic open-source B-rep kernel. Notes (from general knowledge, **not benchmarked or integrated here**): LGPL-2.1 with an exception (dynamic linking / replaceable library obligations apply); WebAssembly builds exist (e.g. opencascade.js) but are large (tens of MB), slow to load and awkward to bundle; the C++ API is large. Architectural walls with rectangular openings do not need B-rep booleans, so the MVP uses a **clearly separated, deterministic 2D geometry layer** (`packages/geometry`) plus analytic wall splitting (`wallBoxes`). It is *not* a B-rep kernel: no curved walls, no arbitrary solids, no sweeps. When those are required, integrate a kernel behind a new `kernel` interface and keep `ArchModel` unchanged.

## Rendering
`Viewport3D` keeps a cache `id → {signature, Object3D}`; only objects whose resolved data/colour changed are rebuilt and disposed. Rendering is on demand (no continuous redraw). Z-up scene in metres.
The 2D canvas draws directly from the resolved model with `requestAnimationFrame` coalescing and no React re-render per frame.

## Drawing
`buildPlan` / `buildElevation` return vector primitives (model mm, paper-mm line widths); `layoutSheet` fits them to a paper size and scale (or auto-fits); `toSVG` and `toPDF` (hand-written single-page PDF, Helvetica) serialise them. Section views are **not** implemented.

## Platform isolation
Browser APIs live in `apps/web` (`storage.ts` IndexedDB, `actions.ts` download/open). Tauri and Android only host the same bundle.

## Extension points
New object type: add to `types.ts` → `exprPaths` → `ArchModel.resolveOne` → `validate` → renderer `build` → drawing. Cloud sync: `Session` already serialises through `project-format`; add a sync adapter beside `storage.ts`. Geometry kernel: see above.
