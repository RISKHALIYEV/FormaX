# Development
Requirements: Node 20+ (developed on Node 22), npm. Optional: Rust + Tauri prerequisites (desktop), Android SDK + JDK 17 (Android), Python + Playwright (e2e).

| Command | Purpose |
|---|---|
| `npm install` | install dependencies |
| `npm run dev` | Vite dev server on :5173 |
| `npm run build` | production web build → `apps/web/dist` |
| `npm run preview` | serve the build |
| `npm test` | Vitest unit tests |
| `npm run typecheck` | strict TypeScript (whole monorepo) |
| `npm run example` | regenerate `examples/sample.formax` from the core |
| `npm run desktop:build` | Tauri build (needs Rust; unverified) |
| `npm run android:build` | sync assets + Gradle (needs Android SDK; unverified) |

Packages are consumed through path aliases (`aliases.ts` for Vite/Vitest, `tsconfig.json` paths); there is no per-package build step.
Rules: `geometry`, `parametric`, `architecture`, `core`, `drawing`, `project-format` must not import React/DOM (the autosave/download helpers live in `apps/web`). `rendering` may use WebGL only.
Test hook: append `?e2e` to the URL to expose `window.__formax` (session, UI store).
