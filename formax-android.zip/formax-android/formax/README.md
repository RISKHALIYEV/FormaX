# FormaX — parametric architecture software (no AI)

> **One parameter change. The entire dependent project updates.**

FormaX is a deterministic, local-first architecture design tool: a 2D plan editor, a 3D model view and a real parametric
dependency engine sharing **one data model**. No AI, no ML, no external services, no accounts, no ads.

**Status: working MVP foundation (v0.1.0), not a replacement for AutoCAD / Revit / Archicad.** See [ROADMAP.md](ROADMAP.md) for what is missing.

## What works (verified — see [TESTING.md](TESTING.md))
- Plan editor: building footprint, interior walls, rooms, doors/windows hosted on walls, columns, lines, polylines, circles, dimensions; select / box-select / move / rotate / scale / duplicate / delete; snaps (endpoint, midpoint, intersection, nearest-on-edge, grid, orthogonal); pan / zoom; layers (visibility, lock); undo / redo.
- 3D view (Three.js): perspective + orthographic, orbit / pan / zoom, selection highlight, real openings cut into walls, slabs, flat roofs, materials, multi-level buildings.
- Parametric core: named numeric/boolean parameters, safe formula language (no `eval`), dependency graph with cycle detection, incremental recompute, constraints, transactional edits that keep the last valid state, parameter history.
- Data: property inspector (every geometric field accepts a number or a formula), room areas (net of wall thickness), quantities, room and door/window schedules, CSV export.
- Drawing: floor plan and elevation generated from the model (dimensions, scale, paper size) → **SVG** and **PDF**.
- Persistence: native `.formax` file (versioned, validated, integrity-checked), IndexedDB project store, autosave with crash recovery, download / open files.
- UI: light/dark themes, command palette (Ctrl+K), keyboard shortcuts, context menu, English + Uzbek (menus, tools, status), responsive layout for tablets/phones.

## Quick start
```bash
npm install
npm run dev            # http://localhost:5173 (development)
npm start              # production build + local server (http://localhost:4173)
npm test               # 45 unit tests
npm run typecheck
npm run build          # -> apps/web/dist
```
The production build (`apps/web/dist/index.html`) is also a single classic script, so it can be opened by double-clicking the file.

Open **File › Load example project** for a two-storey house, or choose the *Building footprint* tool (B) and drag a rectangle.
Change `building_width` in the **Parameters** tab and watch walls, partition, rooms and areas follow.

## Platforms
| Platform | State |
|---|---|
| Web | Built and verified (Chromium, end-to-end script) |
| Windows (Tauri 2) | Configuration only. **Not built** (no Rust toolchain available). See `apps/desktop/README.md` |
| Android (WebView host, `com.formax.architecture`) | Project complete and statically validated; **APK not compiled in the preparation environment** (no Google/Gradle network). Build: GitHub Actions or `scripts/build-android.sh`. See `docs/ANDROID_BUILD.md`, `docs/TERMUX_BUILD.md` (Uzbek) |

Docs: [ANDROID_BUILD](docs/ANDROID_BUILD.md) · [TERMUX_BUILD (uz)](docs/TERMUX_BUILD.md) · [CHANGELOG](CHANGELOG.md) · [ARCHITECTURE](ARCHITECTURE.md) · [DEVELOPMENT](DEVELOPMENT.md) · [TESTING](TESTING.md) · [PROJECT_FORMAT](PROJECT_FORMAT.md) · [ROADMAP](ROADMAP.md) · [LICENSES](LICENSES.md)
