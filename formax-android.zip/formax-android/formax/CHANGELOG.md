# Changelog
## Unreleased (Android preparation)
- Android: new package id `com.formax.architecture`; Gradle wrapper 8.7 + `gradle.properties`; version/signing via properties and env vars; no permissions.
- Android host: native "Save as" for .formax/SVG/PDF/CSV, hardware Back handling, bar colours following the theme, "open with" for project files, external navigation blocked, splash screen, adaptive + themed + legacy icons.
- Branding: FormaX logo set (SVG/PNG, dark/light), Play icon, splash art, five UI illustrations (SVG, inline, offline), first-run welcome screen, dark theme is now the default.
- Web: PWA manifest + offline service worker (http/https only), safe-area insets, 44 px touch targets, 16 px inputs (no keyboard zoom), boot splash.
- Fix: on phone-width screens the 2D/3D viewport collapsed to zero height (hidden hint row occupied the `1fr` grid row).
- Build: `scripts/build-android.sh|build-debug.sh|build-release.sh`, `.github/workflows/android-build.yml`, `docs/TERMUX_BUILD.md` (Uzbek), `docs/ANDROID_BUILD.md`.
- Android: splash vector drawable (`drawable/ic_splash.xml`), explicit SDK install step in CI, `scripts/verify-android.mjs` static verifier.
- Tests: new `tests/e2e/mobile.py`; e2e scripts dismiss the welcome screen.
## 0.1.0
- Initial MVP (see README).
