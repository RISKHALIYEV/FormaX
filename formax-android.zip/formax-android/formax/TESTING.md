# Testing
## Unit / integration (Vitest) — `npm test`
45 tests in `tests/*.test.ts`: geometry (points, intersections, polygon validation, wall geometry, room offsets, units), parametric (parsing, precedence, errors, injection attempts, dependency order, incremental recompute, cycles, invalid formulas, transactions, recovery), architecture/session (object creation, hosts, wall splitting volumes, net room areas, parametric updates, constraint violations, rollback, undo/redo, second level, snapping with formulas, hit-testing, move/rotate/scale/duplicate/delete), project format (round trip, schema validation, future version rejection, duplicate ids, missing hosts, integrity corruption + recovery mode, asset integrity), drawing (plan derives from model, SVG well-formed, PDF xref/stream offsets valid, elevation).

## End-to-end (Playwright + Chromium) — `tests/e2e/`
`acceptance.py` runs the 21-step MVP scenario through real mouse/keyboard input (draw footprint, partition via midpoint snaps, two rooms, door, window, 3D, select wall, change height, change `building_width`, circular-formula rejection, undo/redo, save, reload, reopen from IndexedDB, SVG + PDF export, Uzbek UI, console-error check). `example-project.py` checks the two-storey example, constraint rejection, geometry-conflict messages, elevation export, autosave recovery.

## Mobile / Android preparation
`tests/e2e/mobile.py` (phone viewport, touch): welcome screen, no horizontal overflow, Back hook behaviour, touch target size, host open-file hook, console errors. Android resources are checked statically (XML well-formed, resource references resolve, icon sizes per density). The APK itself has **not** been built or run.

## Not covered
Real touch devices (pinch/one-finger orbit are implemented but only desktop input was exercised), Firefox/Safari, Windows and Android builds, large-model performance, PDF rendering in third-party viewers (structure validated, not visually compared), automated accessibility audit.
