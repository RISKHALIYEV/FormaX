# FormaX — Termux orqali APK yig'ish (O'zbekcha qo'llanma)

> **Halol ogohlantirish.** Bu loyiha tayyorlangan muhitda (Linux sandbox) Google va Gradle serverlariga ulanish yo'q edi,
> shuning uchun **APK bu yerda yig'ilmagan va Termux'da sinab ko'rilmagan.** Veb-qism (typecheck, 45 ta unit test, brauzer testlari) tekshirilgan.
> Android qismi esa faqat statik tekshirilgan (XML, resurslar, skript sintaksisi). Quyida ikki yo'l bor:
>
> * **A yo'l (TAVSIYA): GitHub Actions** — telefondan ishga tushirasiz, bulutda yig'iladi, tayyor APK'ni yuklab olasiz. Termux'da Android SDK bilan bog'liq muammolar yo'q.
> * **B yo'l (tajribaviy): Termux'ning o'zida** — ishlashi kafolatlanmagan. Asosiy to'siq: Gradle yuklab oladigan `aapt2` dasturi x86_64 uchun, telefon esa odatda aarch64 (ARM). Skript Termux'ning o'z `aapt2` paketini ulashga urinadi.

---

## A yo'l — GitHub Actions (telefondan)

1. Loyihani o'zingizning **GitHub** repozitoriyangizga yuklang (bepul hisob yetarli; xususiy repo ham bo'ladi).
   Termux'da:
   ```bash
   pkg update && pkg install -y git gh
   cd ~/formax                       # ZIP ochilgan papka
   git init && git add -A && git commit -m "FormaX"
   gh auth login                     # ko'rsatmalarga amal qiling
   gh repo create formax --private --source=. --push
   ```
2. Yig'ishni ishga tushiring (ikki usul):
   * **Brauzerda:** github.com → repo → **Actions** → **Android APK** → **Run workflow** → `build_type = debug` → Run.
     (Telefonda kerak bo'lsa brauzerda "Desktop site" ni yoqing.)
   * **Termux'da:** `gh workflow run android-build.yml -f build_type=debug`
3. 5–10 daqiqa kuting. Holatni ko'rish: `gh run watch` yoki Actions sahifasi.
4. APK'ni yuklab oling:
   * Brauzerda: tugagan run sahifasi → pastda **Artifacts** → `formax-debug-apk` (ZIP, ichida `app-debug.apk`).
   * Termux'da: `gh run download --name formax-debug-apk` (joriy papkaga tushadi).
5. O'rnatish: pastdagi "O'rnatish" bo'limiga qarang.

Debug APK imzo kalitisiz o'rnatiladi (Android uni avtomatik debug kaliti bilan imzolaydi). Paket nomi: `com.formax.architecture.debug`,
shuning uchun keyinroq release versiya bilan yonma-yon turadi.

---

## B yo'l — Termux'da to'g'ridan-to'g'ri (tajribaviy, tekshirilmagan)

### Talablar
* Termux'ni **F-Droid** yoki GitHub'dan o'rnating (Google Play'dagi eski nusxa yangilanmaydi).
* Kamida **6 GB** bo'sh joy, **4 GB** RAM tavsiya etiladi. Yig'ish vaqtida telefon qizishi va Termux fonda o'chirilishi mumkin: `termux-wake-lock` ishlating.

### 1. Paketlar
```bash
pkg update && pkg upgrade -y
pkg install -y nodejs git unzip wget openjdk-17 aapt2
termux-wake-lock
```
Versiyalarni tekshiring (`node -v` ≥ 20, `java -version` ≥ 17).

### 2. Android SDK (faqat buyruq qatori asboblari)
```bash
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-11076708_latest.zip && mv cmdline-tools latest
export ANDROID_HOME=$HOME/android-sdk
yes | $ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager "platforms;android-34" "build-tools;34.0.0"
```
> `build-tools` ichidagi ba'zi dasturlar x86_64 uchun va telefonda ishlamaydi — Gradle uchun muhimi `aapt2`, uni quyida Termux versiyasi bilan almashtiramiz.

### 3. Muhit o'zgaruvchilari (`~/.bashrc` ga qo'shing)
```bash
export JAVA_HOME=$PREFIX/lib/jvm/java-17-openjdk
export ANDROID_HOME=$HOME/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export PATH=$JAVA_HOME/bin:$PATH
```
`source ~/.bashrc`. Agar `JAVA_HOME` yo'li boshqacha bo'lsa: `ls $PREFIX/lib/jvm`.

### 4. Yig'ish
```bash
cd ~/formax
bash scripts/build-debug.sh        # yoki: bash scripts/build-android.sh debug
```
Skript ketma-ket: `npm ci` → typecheck → testlar → veb build → Android assets'ga nusxalash → Gradle (`assembleDebug`) → APK'ni `dist-apk/` ga yig'adi.
Termux aniqlansa, Gradle'ga `-Pandroid.aapt2FromMavenOverride=<Termux aapt2>` beriladi.

Birinchi yig'ish Gradle (8.7) va Android Gradle Plugin'ni internetdan yuklaydi (yuzlab MB). Keyingilari tezroq.

### 5. APK joylashuvi
* Skript nusxasi: `~/formax/dist-apk/app-debug.apk`
* Asl joyi: `~/formax/apps/android/app/build/outputs/apk/debug/app-debug.apk`

---

## O'rnatish
```bash
termux-setup-storage
cp dist-apk/app-debug.apk ~/storage/downloads/
```
So'ng **Files** ilovasida `Download/app-debug.apk` ni oching → "Noma'lum manbalardan o'rnatish"ga ruxsat bering → O'rnatish.
(Kompyuter bilan: `adb install -r app-debug.apk`.) Ilova hech qanday ruxsat so'ramaydi va internet ishlatmaydi.

---

## Release APK va imzolash
Release APK **imzolanishi shart**, aks holda o'rnatilmaydi. Kalit va parollar repozitoriyga **qo'shilmaydi**.

1. Kalit yarating (bir marta; faylni va parollarni yo'qotmang — keyingi yangilanishlar shu kalit bilan imzolanadi):
   ```bash
   keytool -genkeypair -v -keystore formax-release.jks -alias formax -keyalg RSA -keysize 2048 -validity 10000
   ```
2. **Termux'da imzolab yig'ish:**
   ```bash
   export FORMAX_KEYSTORE_PATH=$HOME/formax-release.jks
   export FORMAX_KEYSTORE_PASSWORD='...'
   export FORMAX_KEY_ALIAS=formax
   export FORMAX_KEY_PASSWORD='...'
   export FORMAX_VERSION_NAME=0.1.0 FORMAX_VERSION_CODE=1
   bash scripts/build-release.sh
   ```
   Natija: `dist-apk/app-release.apk`. (Kalit berilmasa `app-release-unsigned.apk` chiqadi — o'rnatib bo'lmaydi.)
3. **GitHub Actions'da:** repo → Settings → Secrets and variables → Actions → quyidagi 4 ta secret:
   `FORMAX_KEYSTORE_BASE64` (`base64 -w0 formax-release.jks` natijasi), `FORMAX_KEYSTORE_PASSWORD`, `FORMAX_KEY_ALIAS`, `FORMAX_KEY_PASSWORD`.
   So'ng Run workflow → `build_type = release`.

Har yangi versiyada `FORMAX_VERSION_CODE` ni oshiring (CI'da avtomatik: run raqami).

---

## Muammolarni hal qilish
| Belgi | Sabab / yechim |
|---|---|
| `aapt2: ... Syntax error` / `cannot execute binary file` / `Exec format error` | Gradle x86_64 `aapt2` yuklagan. `pkg install aapt2`, so'ng `AAPT2_PATH=$(command -v aapt2) bash scripts/build-debug.sh`. Hal bo'lmasa — A yo'l (GitHub Actions). |
| `SDK location not found` | `ANDROID_HOME` o'rnatilmagan: 3-bosqich. |
| `Failed to install the following SDK components` / litsenziya | `yes \| sdkmanager --licenses` ni qayta ishga tushiring. |
| `Unsupported class file major version` | JDK 17 kerak (`java -version`). |
| `OutOfMemoryError` / Termux yopilib qoladi | `~/.gradle/gradle.properties` ga `org.gradle.jvmargs=-Xmx1024m` yozing, boshqa ilovalarni yoping, `termux-wake-lock`. |
| `npm ci` xatosi | `node -v` ≥ 20 ekanini tekshiring; internetni tekshiring. |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | Telefonda boshqa kalit bilan imzolangan nusxa bor; avval uni o'chiring. |
| Ilova oq/qora ekranda | `bash scripts/build-debug.sh` veb build'ni qayta nusxalaydi; assets'da `apps/android/app/src/main/assets/web/index.html` borligini tekshiring. |
| Loyihani ochishda "integrity check failed" | Fayl qo'lda tahrirlangan; "recovery mode" orqali oching. |
