# FormaX Android — technical notes

## Approach: native WebView host (not Capacitor)
The repository already contained a small native Android host (`apps/android`, Kotlin + `WebViewAssetLoader`) that serves the **real FormaX web bundle**
from `assets/web` on the secure virtual origin `https://appassets.androidplatform.net`. I kept it instead of adding Capacitor because
the web bundle is already a single classic script that works inside a WebView, Capacitor would add a Node-side plugin layer and a second Android project to
maintain, and the only native features FormaX needs (file save, back button, bar colours, open-with) are ~150 lines of Kotlin.
There is one data model and one geometry engine: the Android app runs exactly the code in `packages/*` and `apps/web`.

| Item | Value |
|---|---|
| Application ID / namespace | `com.formax.architecture` (debug builds: `.debug` suffix) |
| Version | `-PformaxVersionName`, `-PformaxVersionCode` (defaults 0.1.0 / 1; CI uses the run number) |
| minSdk / targetSdk / compileSdk | 26 / 34 / 34 |
| Toolchain | JDK 17, Gradle 8.7 (wrapper), AGP 8.5.2, Kotlin 1.9.24 |
| Permissions | **none** (no INTERNET, no storage) — the app cannot reach a network |
| Orientation | portrait + landscape (rotation keeps state via `configChanges`) |

## Native ↔ web contract
* `window.FormaXAndroid.saveFile(name, mime, base64)` → system "Save as" (Storage Access Framework). Result returns through `window.__formaxNative.saved(ok, name)`.
* `window.FormaXAndroid.setTheme(dark)` → status/navigation bar colours follow the app theme.
* Hardware Back calls `window.__formaxBack()`; it closes dialogs, menus, panels, tool, selection, 3D view in that order. At the root, double-Back exits.
* "Open with" on a `content://` JSON/`.formax` file calls `window.__formaxOpenText(name, text)` (guarded by the unsaved-changes dialog).
* Web side: `apps/web/src/native.ts`, hooks in `App.tsx`, `actions.ts` (`download()`).

## Branding resources
`assets/` holds the sources (logos, illustrations, splash, 512 px Play icon); `assets/tools/gen_*.py` regenerate every PNG
(needs `pip install cairosvg pillow`). Android resources: adaptive icon (background, foreground, monochrome/themed) + legacy square/round PNGs in all
five densities, splash through `androidx.core:core-splashscreen`, dark theme with matching bar colours.

## Offline
No remote scripts, fonts or API calls exist in the web code. Android: all assets are packaged. Web: `public/sw.js` caches the shell when served over http(s)
(skipped inside the app). Projects live in IndexedDB; export/import use files.

## Build
`bash scripts/build-android.sh debug|release` (see `docs/TERMUX_BUILD.md`, Uzbek) or the GitHub Actions workflow `.github/workflows/android-build.yml`.
Signing: environment variables `FORMAX_KEYSTORE_PATH/_PASSWORD`, `FORMAX_KEY_ALIAS`, `FORMAX_KEY_PASSWORD`; nothing secret is committed.
`isMinifyEnabled` is false (no R8) because release shrinking was not tested.
