# Roadmap / known gaps
## Not implemented (honest list)
- **Section views** (elevations only). Arcs and point tool in the plan (circle, line, polyline exist).
- **Automatic room detection** from walls; rooms are boundary polygons whose points you pick (snaps keep them parametric).
- Wall joins are limited to the per-wall "extend ends" flag; no mitre/T-junction cleanup, no curved or sloped walls, no gable/hip roofs (flat roofs only), no stairs, no openings in slabs.
- Door/window `offset` is a plain mm distance (formulas allowed, e.g. `building_width / 2`, but no automatic "keep centred" mode).
- Rotate/scale write numeric coordinates (formula bindings of moved points are baked). Columns have no rotation.
- Elevation draws openings only for walls in the viewer-facing half of the building (heuristic).
- Undo stores full snapshots; structural edits rebuild the whole model. Untested on large projects.
- Native desktop dialogs / file association handling; Android file export; `Windows` and `Android` builds are unverified.
- Uzbek localization covers menus, tool names and status text; inspector/dialog text is English. PDF text is Latin-1 only.
- B-rep kernel (Open CASCADE) evaluation is desk research only.
## Next priorities (in order)
1. Section views + level-aware elevations; automatic room detection and wall-join cleanup.
2. Incremental per-object recompute for structural edits; performance profiling on 5k+ objects.
3. Native desktop file dialogs (`tauri-plugin-dialog/fs`), file association, produce and test a Windows installer.
4. Android: native save/export bridge, build and test on devices, touch refinement.
5. Gable roofs, stairs, openings in slabs, schedules with grouping/filtering, IFC export.
6. Optional kernel integration behind a `kernel` interface; optional sync adapter (CRDT or file-based).
