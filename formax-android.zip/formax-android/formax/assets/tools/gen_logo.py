# Generates FormaX logo family. Mark: an "X" formed by two structural diagonals over an architectural grid frame,
# with a parametric node (circle) at the intersection.
TEAL="#18A3B3"; TEAL_D="#0E6670"; INK="#15191C"; PAPER="#F4F6F7"

def mark(stroke, accent, grid, size=512, bg=None, pad=0):
    s = size
    body = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="{s}" height="{s}">
{f'<rect width="512" height="512" fill="{bg}"/>' if bg else ''}
<g fill="none" stroke-linecap="square" stroke-linejoin="miter">
  <path d="M96 96H416V416H96Z" stroke="{grid}" stroke-width="10" opacity=".55"/>
  <path d="M96 256H416M256 96V416" stroke="{grid}" stroke-width="6" opacity=".35"/>
  <path d="M96 96L416 416" stroke="{stroke}" stroke-width="40"/>
  <path d="M416 96L256 256" stroke="{accent}" stroke-width="40"/>
  <path d="M96 416L256 256" stroke="{stroke}" stroke-width="40"/>
</g>
<circle cx="256" cy="256" r="30" fill="{INK if bg and bg!=PAPER else '#FFFFFF'}" stroke="{accent}" stroke-width="14"/>
</svg>'''
    return body

def write(n, t): open(n,'w').write(t)
# primary (works on dark & light)
write('../logo/logo.svg', mark('#E8F1F3', TEAL, '#9FB6BC'))
write('../logo/logo-dark.svg', mark('#E8F1F3', TEAL, '#9FB6BC'))        # for dark backgrounds
write('../logo/logo-light.svg', mark(INK, TEAL_D, '#51656B'))            # for light backgrounds
import cairosvg
cairosvg.svg2png(url='../logo/logo.svg', write_to='../logo/logo.png', output_width=1024, output_height=1024, background_color='#15191C')
