import cairosvg, os, io
from PIL import Image
TEAL="#18A3B3"; INK="#15191C"
def mk(stroke, accent, grid, ring_fill, bg=None, with_grid=True, scale=1.0):
    # content drawn in a 512 box, scaled about center
    t = f'translate({256-256*scale} {256-256*scale}) scale({scale})'
    g = f'''<path d="M96 96H416V416H96Z" stroke="{grid}" stroke-width="10" opacity=".55"/><path d="M96 256H416M256 96V416" stroke="{grid}" stroke-width="6" opacity=".35"/>''' if with_grid else ''
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">{f'<rect width="512" height="512" fill="{bg}"/>' if bg else ''}
<g transform="{t}"><g fill="none" stroke-linecap="square">{g}
<path d="M96 96L416 416" stroke="{stroke}" stroke-width="40"/><path d="M416 96L256 256" stroke="{accent}" stroke-width="40"/><path d="M96 416L256 256" stroke="{stroke}" stroke-width="40"/></g>
<circle cx="256" cy="256" r="30" fill="{ring_fill}" stroke="{accent}" stroke-width="14"/></g></svg>'''
def png(svg, px, path, bg=None):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cairosvg.svg2png(bytestring=svg.encode(), write_to=path, output_width=px, output_height=px, background_color=bg)

R='../../apps/android/app/src/main/res'
# --- adaptive: foreground (mark in the 66/108 safe zone -> scale 0.52 of canvas), background (dark + faint grid), monochrome
fg = mk('#E8F1F3', TEAL, '#9FB6BC', '#FFFFFF', scale=0.56, with_grid=False)
bg_svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108"><rect width="108" height="108" fill="{INK}"/>
<g stroke="#2B363B" stroke-width=".6" fill="none">{''.join(f'<path d="M{i} 0V108M0 {i}H108"/>' for i in range(0,109,9))}</g></svg>'''
mono = mk('#000000', '#000000', '#000000', '#00000000', scale=0.56, with_grid=False).replace('fill="#00000000"','fill="none"')
dens_adapt = {'mdpi':108,'hdpi':162,'xhdpi':216,'xxhdpi':324,'xxxhdpi':432}
dens_legacy = {'mdpi':48,'hdpi':72,'xhdpi':96,'xxhdpi':144,'xxxhdpi':192}
for d,px in dens_adapt.items():
    png(fg, px, f'{R}/mipmap-{d}/ic_launcher_foreground.png')
    png(bg_svg, px, f'{R}/mipmap-{d}/ic_launcher_background.png')
    png(mono, px, f'{R}/mipmap-{d}/ic_launcher_monochrome.png')
# --- legacy full-bleed icons (rounded square + round)
full = mk('#E8F1F3', TEAL, '#9FB6BC', '#FFFFFF', bg=INK, scale=0.8)
for d,px in dens_legacy.items():
    for name, rad in (('ic_launcher', 0.2), ('ic_launcher_round', 0.5)):
        buf = io.BytesIO(); cairosvg.svg2png(bytestring=full.encode(), write_to=buf, output_width=px*4, output_height=px*4)
        im = Image.open(buf).convert('RGBA')
        from PIL import ImageDraw
        m = Image.new('L', im.size, 0); ImageDraw.Draw(m).rounded_rectangle([0,0,im.size[0]-1,im.size[1]-1], radius=int(im.size[0]*rad), fill=255)
        im.putalpha(m); im = im.resize((px,px), Image.LANCZOS)
        p=f'{R}/mipmap-{d}/{name}.png'; os.makedirs(os.path.dirname(p), exist_ok=True); im.save(p)
# --- Play Store 512 (full-bleed square; Play applies its own mask)
png(full, 512, '../icons/playstore-512.png')
png(fg, 432, '../icons/adaptive-foreground-432.png'); png(bg_svg, 432, '../icons/adaptive-background-432.png'); png(mono, 432, '../icons/adaptive-monochrome-432.png')
png(full, 192, '../icons/legacy-192.png')
# favicons / PWA icons for web
W='../../apps/web/public'; os.makedirs(W, exist_ok=True)
png(full, 192, f'{W}/icon-192.png'); png(full, 512, f'{W}/icon-512.png'); png(mk('#E8F1F3',TEAL,'#9FB6BC','#FFFFFF',bg=INK,scale=0.6), 512, f'{W}/icon-maskable-512.png')
open(f'{W}/favicon.svg','w').write(mk('#E8F1F3', TEAL, '#9FB6BC', '#FFFFFF', bg=INK, scale=0.9))
# --- Splash 1080x1920 graphic (dark, subtle grid, logo, name)
sp = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1920"><rect width="1080" height="1920" fill="{INK}"/>
<g stroke="#232D32" stroke-width="2" fill="none">{''.join(f'<path d="M{x} 0V1920"/>' for x in range(0,1081,90))}{''.join(f'<path d="M0 {y}H1080"/>' for y in range(0,1921,90))}</g>
<g stroke="#2F3D43" stroke-width="3">{''.join(f'<path d="M{x} 0V1920"/>' for x in range(0,1081,360))}{''.join(f'<path d="M0 {y}H1080"/>' for y in range(0,1921,360))}</g>
<g transform="translate(340 640) scale(0.78)"><g fill="none" stroke-linecap="square"><path d="M96 96H416V416H96Z" stroke="#9FB6BC" stroke-width="10" opacity=".55"/>
<path d="M96 96L416 416" stroke="#E8F1F3" stroke-width="40"/><path d="M416 96L256 256" stroke="{TEAL}" stroke-width="40"/><path d="M96 416L256 256" stroke="#E8F1F3" stroke-width="40"/></g>
<circle cx="256" cy="256" r="30" fill="#fff" stroke="{TEAL}" stroke-width="14"/></g>
<text x="540" y="1180" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="96" font-weight="700" fill="#E8F1F3" letter-spacing="6">Forma<tspan fill="{TEAL}">X</tspan></text>
<text x="540" y="1250" text-anchor="middle" font-family="DejaVu Sans, Arial, sans-serif" font-size="30" fill="#7F959B" letter-spacing="8">PARAMETRIC ARCHITECTURE</text></svg>'''
open('../splash/splash.svg','w').write(sp)
cairosvg.svg2png(bytestring=sp.encode(), write_to='../splash/splash-1080x1920.png', output_width=1080, output_height=1920)
print('ok')
