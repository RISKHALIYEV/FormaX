T="#18A3B3"; TD="#0E6670"; L="currentColor"
def wrap(body, title):
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 220" role="img" aria-label="{title}" fill="none" stroke-linecap="round" stroke-linejoin="round">
<style>.l{{stroke:#7F959B;stroke-width:2}}.a{{stroke:{T};stroke-width:3}}.f{{fill:{T};stroke:none}}.p{{fill:#7F959B;opacity:.12;stroke:none}}.g{{stroke:#7F959B;stroke-width:1;opacity:.25}}</style>
<title>{title}</title>{body}</svg>'''
grid=''.join(f'<path class="g" d="M{x} 20V200"/>' for x in range(40,300,40))+''.join(f'<path class="g" d="M20 {y}H300"/>' for y in range(40,200,40))
I={}
I['empty-project']=wrap(grid+'<rect class="p" x="70" y="60" width="180" height="110"/><path class="l" stroke-dasharray="6 6" d="M70 60H250V170H70Z"/><path class="a" d="M160 90V140M135 115H185"/><circle class="f" cx="160" cy="115" r="4"/>','Empty project')
I['no-files']=wrap(grid+'<path class="p" d="M95 50H190L225 85V170H95Z"/><path class="l" d="M95 50H190L225 85V170H95Z"/><path class="l" d="M190 50V85H225"/><path class="a" d="M125 120H195M125 140H170" stroke-dasharray="2 8"/><circle class="a" cx="215" cy="150" r="22" fill="#15191C" fill-opacity=".0"/><path class="a" d="M231 166L248 183"/>','No files')
I['create-project']=wrap(grid+'<path class="l" d="M60 160V70H200V160Z"/><path class="p" d="M60 70H200V160H60Z"/><path class="l" d="M60 115H200M130 70V160"/><path class="a" d="M200 70L255 70M255 70L255 125M200 160L255 160M255 125L255 160" stroke-dasharray="1 7"/><path class="a" d="M220 50L250 80M250 50L235 65"/><circle class="f" cx="130" cy="115" r="5"/><path class="a" d="M60 175H200M60 170V180M200 170V180"/>','Create project')
I['error']=wrap(grid+'<path class="p" d="M160 45L250 165H70Z"/><path class="l" d="M160 45L250 165H70Z"/><path class="a" d="M160 90V130"/><circle class="f" cx="160" cy="147" r="4"/><path class="l" d="M45 175L95 175M225 175L275 175" stroke-dasharray="3 6"/>','Error')
I['welcome']=wrap(grid+'<path class="p" d="M60 160V100L110 60L160 100V160Z"/><path class="l" d="M60 160V100L110 60L160 100V160Z"/><path class="p" d="M160 160V80H260V160Z"/><path class="l" d="M160 160V80H260V160Z"/><path class="l" d="M95 160V125H125V160M180 105H210V130H180Z M225 105H245V130H225Z"/><path class="a" d="M40 160H280"/><path class="a" d="M60 182H260M60 177V187M260 177V187"/><circle class="f" cx="110" cy="60" r="5"/>','Welcome')
for k,v in I.items(): open(f'../illustrations/{k}.svg','w').write(v)
print(list(I))
