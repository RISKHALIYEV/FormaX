# `.formax` project format (schema version 1)
A UTF-8 JSON file:
```jsonc
{
  "format": "formax",
  "schemaVersion": 1,
  "app": { "name": "FormaX", "version": "0.1.0" },
  "metadata": { "name": "…", "created": "ISO-8601", "modified": "ISO-8601" },
  "project": { "id", "name", "units": "mm|cm|m",
    "parameters": [{ "name", "expr", "description?" }],
    "constraints": [{ "id", "name", "expr", "message" }],
    "levels": [{ "id", "name", "elevation": <expr>, "height": <expr> }],
    "layers": [{ "id", "name", "visible", "locked" }], "materials": [{ "id", "name", "color" }],
    "objects": [{ "id", "type", "name", "layer", "level", "material", "parent?", …type-specific fields }],
    "parameterHistory": [{ "time", "name", "from", "to" }] },
  "assets": [{ "id", "name", "mime", "data": "<base64>", "checksum" }],
  "integrity": { "algorithm": "cyrb53", "hash": "…" }
}
```
`<expr>` is a number (millimetres) or a formula string over parameter names. **Geometry is not stored**: meshes are derived from the parametric source on load (the "separate geometry storage" is a derived cache that does not exist yet). **Assets** are a separate, individually checksummed array (none are produced by the app yet).
Loading (`parseProjectFile`) never throws: it rejects non-JSON, wrong `format`, missing/invalid/newer `schemaVersion`, malformed fields, duplicate ids, objects on missing levels, openings with missing hosts, invalid parameter names, corrupted assets and integrity mismatches (the latter can be opened in explicit recovery mode). The hash is a 53-bit non-cryptographic checksum: it detects corruption, **not** tampering. Migrations: none needed yet; the hook is in `parseProjectFile`. Files are pretty-printed with 1-space indent.
Browser storage: IndexedDB database `formax` (`projects`, `autosave`) holds the same text.
