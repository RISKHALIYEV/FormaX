import { Component, useEffect, type ReactNode } from 'react';
import { session, useSession } from './session';
import { useUI } from './store';
import * as A from './actions';
import { commands, byId } from './commands';
import { Plan2D } from './Plan2D';
import { View3D } from './View3D';
import { LeftPanel, RightPanel, ToolStrip, ToolHint } from './panels';
import { MenuBar, ViewSwitch, StatusBar, Toast, Dialogs, Palette, ContextMenu } from './chrome';
import { getAutosave } from './storage';
import { Icon } from './icons';
import { Illustration } from './illustrations';
import { nativeTheme } from './native';

class Boundary extends Component<{ children: ReactNode; label: string }, { err: Error | null }> {
  override state = { err: null as Error | null };
  static getDerivedStateFromError(err: Error) { return { err }; }
  override render() { return this.state.err ? <div className="state-error" role="alert"><Illustration n="error" className="art art-sm" /><p><b>{this.props.label} crashed:</b> {this.state.err.message}</p><button className="btn" onClick={() => this.setState({ err: null })}>Try again</button></div> : this.props.children; }
}
const SHORT: Record<string, string> = { 'ctrl+n': 'file.new', 'ctrl+o': 'file.open', 'ctrl+s': 'file.save', 'ctrl+shift+s': 'file.download', 'ctrl+z': 'edit.undo', 'ctrl+y': 'edit.redo', 'ctrl+shift+z': 'edit.redo', 'ctrl+a': 'edit.all', 'ctrl+d': 'edit.duplicate', delete: 'edit.delete', backspace: 'edit.delete', f2: 'view.plan', f3: 'view.3d', f1: 'help', pageup: 'view.up', pagedown: 'view.down', z: 'view.fit', 'ctrl+k': 'palette' };
const TOOLKEY: Record<string, Parameters<typeof A.setTool>[0]> = { v: 'select', b: 'footprint', w: 'wall', r: 'room', d: 'door', n: 'window', k: 'column', l: 'line', p: 'polyline', c: 'circle', m: 'dimension' };

export function App() {
  const s = useSession(); const theme = useUI((u) => u.theme), view = useUI((u) => u.view), panel = useUI((u) => u.panel);
  useEffect(() => { document.documentElement.dataset.theme = theme; nativeTheme(theme === 'dark'); }, [theme]);
  // first-run welcome screen
  useEffect(() => { try { if (!localStorage.getItem('formax.welcomed')) { localStorage.setItem('formax.welcomed', '1'); useUI.setState({ dialog: { kind: 'welcome' } }); } } catch { /* storage unavailable */ } }, []);
  // hooks for the Android host: hardware Back (returns true when the app consumed it) and opening a file handed over by the system
  useEffect(() => {
    const w = window as unknown as { __formaxBack?: () => boolean; __formaxOpenText?: (name: string, text: string) => void };
    w.__formaxBack = () => {
      const u = useUI.getState();
      if (u.dialog) { useUI.setState({ dialog: null }); return true; }
      if (u.palette || u.context || u.menu) { useUI.setState({ palette: false, context: null, menu: null }); return true; }
      if (u.panel) { useUI.setState({ panel: null }); return true; }
      if (u.tool !== 'select') { A.setTool('select'); return true; }
      if (u.selection.length) { useUI.setState({ selection: [] }); return true; }
      if (u.view === '3d') { useUI.setState({ view: 'plan' }); return true; }
      return false;
    };
    w.__formaxOpenText = (name, text) => A.guardDirty(() => A.openText(text, name));
    return () => { delete w.__formaxBack; delete w.__formaxOpenText; };
  }, []);
  useEffect(() => { document.title = `${s.dirty ? '• ' : ''}${s.project.name} – FormaX`; }, [s.project.name, s.dirty, s.version]);
  // autosave (debounced) + unsaved-change guard
  useEffect(() => { if (!s.dirty) return; const h = setTimeout(() => void A.autosave(), 1500); return () => clearTimeout(h); }, [s.version, s.dirty]);
  useEffect(() => { const h = (e: BeforeUnloadEvent) => { if (session.dirty) { e.preventDefault(); e.returnValue = ''; } }; window.addEventListener('beforeunload', h); return () => window.removeEventListener('beforeunload', h); }, []);
  // recovery on start
  useEffect(() => { void getAutosave().then((a) => { if (a?.unsaved) useUI.setState({ dialog: { kind: 'recover', time: a.time, text: a.text } }); }).catch(() => {}); }, []);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement; if (el.closest('input, textarea, select') || useUI.getState().dialog) { if (e.key === 'Escape' && el instanceof HTMLInputElement && !useUI.getState().dialog) el.blur(); return; }
      const key = `${e.ctrlKey || e.metaKey ? 'ctrl+' : ''}${e.shiftKey ? 'shift+' : ''}${e.key.toLowerCase()}`; const k2 = key.replace('shift+', '');
      if (e.key === 'Escape') { useUI.setState({ cancel: useUI.getState().cancel + 1, context: null, menu: null, selection: useUI.getState().tool === 'select' ? [] : useUI.getState().selection, tool: useUI.getState().tool }); return; }
      if (e.key === 'Enter') { useUI.setState({ finish: useUI.getState().finish + 1 }); return; }
      const id = SHORT[key] ?? (e.ctrlKey ? undefined : SHORT[k2]);
      if (id) { e.preventDefault(); if (id === 'palette') useUI.setState({ palette: true }); else { const c = byId(id); if (!c.enabled || c.enabled()) c.run(); } return; }
      if (!e.ctrlKey && !e.metaKey && !e.altKey && TOOLKEY[key]) { e.preventDefault(); A.setTool(TOOLKEY[key]); return; }
      const st = useUI.getState(), g = st.grid; if (e.key.startsWith('Arrow') && st.selection.length && st.view === 'plan') { e.preventDefault(); A.nudge(e.key === 'ArrowLeft' ? -g : e.key === 'ArrowRight' ? g : 0, e.key === 'ArrowUp' ? g : e.key === 'ArrowDown' ? -g : 0); }
    };
    window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h);
  }, []);
  void commands;
  return (
    <div className="app" data-panel={panel ?? ''}>
      <MenuBar />
      <div className="workspace">
        <ToolStrip />
        <aside className="left" aria-label="Project browser"><LeftPanel /></aside>
        <main className="center"><ViewSwitch /><ToolHint />
          <div className="viewport" onPointerDown={() => { if (useUI.getState().panel) useUI.setState({ panel: null }); }}>
            <Boundary label={view === 'plan' ? 'Plan editor' : '3D view'}>{view === 'plan' ? <Plan2D /> : <View3D />}</Boundary>
          </div>
        </main>
        <aside className="right" aria-label="Inspector"><RightPanel /></aside>
      </div>
      <StatusBar /><Toast /><ContextMenu /><Palette /><Dialogs />
    </div>
  );
}
