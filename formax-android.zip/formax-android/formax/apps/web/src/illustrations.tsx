import createProject from '../../../assets/illustrations/create-project.svg?raw';
import emptyProject from '../../../assets/illustrations/empty-project.svg?raw';
import errorArt from '../../../assets/illustrations/error.svg?raw';
import noFiles from '../../../assets/illustrations/no-files.svg?raw';
import welcome from '../../../assets/illustrations/welcome.svg?raw';
import logo from '../../../assets/logo/logo.svg?raw';

const ART = { 'create-project': createProject, 'empty-project': emptyProject, error: errorArt, 'no-files': noFiles, welcome } as const;
export type ArtName = keyof typeof ART;
/** Inline SVG (bundled, works offline and from file://). Illustrations are static, trusted project assets. */
export const Illustration = ({ n, className = 'art' }: { n: ArtName; className?: string }) => <div className={className} aria-hidden="true" dangerouslySetInnerHTML={{ __html: ART[n] }} />;
export const Logo = ({ size = 56 }: { size?: number }) => <span className="logo-mark" style={{ width: size, height: size }} aria-hidden="true" dangerouslySetInnerHTML={{ __html: logo }} />;
