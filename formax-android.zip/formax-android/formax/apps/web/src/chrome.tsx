import { useEffect, useRef, useState } from 'react';
import { formatLength, type LengthUnit } from '@formax/geometry';
import { session, useSession } from './session';
import { useUI, type Dialog } from './store';
import * as A from './actions';
import { Icon } from './icons';
import { Illustration, Logo } from './illustrations';
import { commands, byId, MENUS } from './commands';
import { deleteProject, clearAutosave } from './storage';

const MENU_KEY: Record<string, Parameters<typeof A.tr>[0]> = { File: 'menu.file', Edit: 'menu.edit', View: 'menu.view', Model: 'menu.model', Architecture: 'menu.architecture', Parametric: 'menu.parametric', Drawing: 'menu.drawing', Export: 'menu.export', Settings: 'menu.settings' };

export function MenuBar() {
  const open = useUI((s) => s.menu), lang = useUI((s) => s.lang); useSession();
  useEffect(() => { const h = (e: PointerEvent) => { if (!(e.target as HTMLElement).closest?.('.menubar')) useUI.setState({ menu: null }); }; window.addEventListener('pointerdown', h); return () => window.removeEventListener('pointerdown', h); }, []);
  return (
    <div className="menubar" role="menubar">
      <div className="brand" aria-label="FormaX"><svg width="22" height="22" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="currentColor" /><path d="M8 25V7h17M8 16h11" stroke="var(--bg-panel)" strokeWidth="3" fill="none" /></svg><b>FormaX</b></div>
      {Object.entries(MENUS).map(([name, items]) => (
        <div key={name} className="menu">
          <button role="menuitem" aria-haspopup="true" aria-expanded={open === name} className={open === name ? 'on' : ''} onClick={() => useUI.setState({ menu: open === name ? null : name })} onMouseEnter={() => open && useUI.setState({ menu: name })}>{A.tr(MENU_KEY[name])}</button>
          {open === name && <ul className="dropdown" role="menu">{items.map((id, i) => { if (id === '-') return <li key={i} className="sepline" role="separator" />; const c = byId(id), dis = c.enabled ? !c.enabled() : false;
            return <li key={id + i}><button role="menuitem" disabled={dis} onClick={() => { useUI.setState({ menu: null }); c.run(); }}><span>{c.label}</span>{c.shortcut && <kbd>{c.shortcut}</kbd>}</button></li>; })}</ul>}
        </div>
      ))}
      <div className="spacer" />
      <button className="icon" title="Undo (Ctrl+Z)" aria-label="Undo" disabled={!session.canUndo} onClick={A.undo}><Icon n="undo" /></button>
      <button className="icon" title="Redo (Ctrl+Y)" aria-label="Redo" disabled={!session.canRedo} onClick={A.redo}><Icon n="redo" /></button>
      <button className="icon" title="Command palette (Ctrl+K)" aria-label="Command palette" onClick={() => useUI.setState({ palette: true })}><Icon n="cmd" /></button>
      <span hidden>{lang}</span>
    </div>
  );
}
export function ViewSwitch() {
  const view = useUI((s) => s.view); useUI((s) => s.lang); const s = useSession(), level = A.activeLevel();
  return (
    <div className="viewbar">
      <div className="seg" role="tablist" aria-label="View">
        <button role="tab" aria-selected={view === 'plan'} className={view === 'plan' ? 'on' : ''} onClick={() => useUI.setState({ view: 'plan' })}><Icon n="plan" size={16} /> {A.tr('view.2d')}</button>
        <button role="tab" aria-selected={view === '3d'} className={view === '3d' ? 'on' : ''} onClick={() => useUI.setState({ view: '3d' })}><Icon n="cube" size={16} /> {A.tr('view.3d')}</button>
      </div>
      <label className="levelsel">Level <select value={level} onChange={(e) => useUI.setState({ level: e.target.value, selection: [] })}>{s.project.levels.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></label>
      <button className="btn small" onClick={() => useUI.setState({ frame: useUI.getState().frame + 1 })} title="Zoom to fit (Z)"><Icon n="fit" size={14} /> Fit</button>
      <div className="panels-toggle"><button className="icon" aria-label="Project panel" onClick={() => useUI.setState({ panel: useUI.getState().panel === 'left' ? null : 'left' })}><Icon n="layers" /></button><button className="icon" aria-label="Properties panel" onClick={() => useUI.setState({ panel: useUI.getState().panel === 'right' ? null : 'right' })}><Icon n="sliders" /></button></div>
    </div>
  );
}
export function StatusBar() {
  const s = useSession(), cur = useUI((u) => u.cursor), sel = useUI((u) => u.selection), snaps = useUI((u) => u.snaps), view = useUI((u) => u.view), saved = useUI((u) => u.lastSaved), grid = useUI((u) => u.grid);
  const errs = s.model.issues.filter((i) => i.severity === 'error').length, warns = s.model.issues.length - errs;
  const f = (n: number) => formatLength(n, s.project.units).replace(/ \w+$/, '');
  const msg = s.lastIssues.find((i) => i.severity === 'error');
  const toggle = (k: keyof typeof snaps) => useUI.getState().setPrefs({ snaps: { ...snaps, [k]: !snaps[k] } });
  return (
    <footer className="statusbar">
      <span className="mono cursor" title="Cursor position (snapped)">{view === 'plan' ? `X ${f(cur.x)}  Y ${f(cur.y)}` : '3D'}{view === 'plan' && cur.kind ? ` · ${cur.kind}` : ''}</span>
      <select className="units" aria-label="Display units" value={s.project.units} onChange={(e) => A.run('Units', (p) => { p.units = e.target.value as LengthUnit; })}>{['mm', 'cm', 'm'].map((u) => <option key={u}>{u}</option>)}</select>
      <span className="snapbtns" role="group" aria-label="Snaps">{(['endpoints', 'midpoints', 'intersections', 'edges', 'grid', 'ortho'] as const).map((k) => <button key={k} className={snaps[k] ? 'chip on' : 'chip'} aria-pressed={snaps[k]} onClick={() => toggle(k)} title={`Snap: ${k}`}>{k === 'endpoints' ? 'End' : k === 'midpoints' ? 'Mid' : k === 'intersections' ? 'Int' : k === 'edges' ? 'Near' : k === 'grid' ? `Grid ${grid}` : 'Ortho'}</button>)}</span>
      <span className="sel">{sel.length ? `${sel.length} selected` : A.tr('status.noselection')}</span>
      <span className="spacer" />
      {msg && <span className="statusmsg err" title={msg.message}>{msg.message}</span>}
      <button className={errs ? 'issuebtn bad' : 'issuebtn'} onClick={() => useUI.setState({ dialog: { kind: 'issues' } })} title="Validation issues"><Icon n={errs ? 'warn' : 'ok'} size={14} /> {errs} errors · {warns} warnings</button>
      <span className={s.dirty ? 'dirty' : 'clean'} title={saved ? `Last saved ${new Date(saved).toLocaleTimeString()}` : ''}>{s.dirty ? '● ' + A.tr('status.unsaved') : A.tr('status.saved')}</span>
    </footer>
  );
}
export function Toast() {
  const t = useUI((s) => s.toast);
  useEffect(() => { if (!t) return; const h = setTimeout(() => useUI.setState((s) => (s.toast?.id === t.id ? { toast: null } : {})), t.kind === 'error' ? 8000 : 3500); return () => clearTimeout(h); }, [t]);
  if (!t) return null;
  return <div className={`toast ${t.kind}`} role={t.kind === 'error' ? 'alert' : 'status'}><Icon n={t.kind === 'error' ? 'warn' : t.kind === 'ok' ? 'ok' : 'cmd'} size={16} /><span>{t.msg}</span><button className="icon" aria-label="Dismiss" onClick={() => useUI.setState({ toast: null })}><Icon n="x" size={14} /></button></div>;
}
export function ContextMenu() {
  const c = useUI((s) => s.context), sel = useUI((s) => s.selection); useSession();
  if (!c) return null;
  const items = ['edit.duplicate', 'edit.rotate', 'edit.scale', 'edit.delete', '-', 'view.fit'];
  return <ul className="dropdown ctx" role="menu" style={{ left: Math.min(c.x, window.innerWidth - 220), top: Math.min(c.y, window.innerHeight - 220) }}>
    <li className="ctxhead">{sel.length ? `${sel.length} selected` : 'Nothing selected'}</li>
    {items.map((id, i) => { if (id === '-') return <li key={i} className="sepline" />; const cm = byId(id), dis = cm.enabled ? !cm.enabled() : false; return <li key={id}><button disabled={dis} onClick={() => { useUI.setState({ context: null }); cm.run(); }}><span>{cm.label}</span>{cm.shortcut && <kbd>{cm.shortcut}</kbd>}</button></li>; })}</ul>;
}
export function Palette() {
  const open = useUI((s) => s.palette); const [q, setQ] = useState(''), [i, setI] = useState(0); const ref = useRef<HTMLInputElement>(null); useSession();
  useEffect(() => { if (open) { setQ(''); setI(0); setTimeout(() => ref.current?.focus(), 0); } }, [open]);
  if (!open) return null;
  const list = commands.filter((c) => (c.label + ' ' + c.id + ' ' + (c.keywords ?? '')).toLowerCase().includes(q.toLowerCase()));
  const go = (k: number) => { const c = list[k]; if (!c || (c.enabled && !c.enabled())) return; useUI.setState({ palette: false }); c.run(); };
  return <div className="overlay" onPointerDown={() => useUI.setState({ palette: false })}><div className="palette" role="dialog" aria-label="Command palette" onPointerDown={(e) => e.stopPropagation()}>
    <input ref={ref} value={q} placeholder="Type a command…" onChange={(e) => { setQ(e.target.value); setI(0); }} onKeyDown={(e) => { if (e.key === 'ArrowDown') { e.preventDefault(); setI(Math.min(list.length - 1, i + 1)); } else if (e.key === 'ArrowUp') { e.preventDefault(); setI(Math.max(0, i - 1)); } else if (e.key === 'Enter') go(i); else if (e.key === 'Escape') useUI.setState({ palette: false }); }} />
    <ul>{list.length === 0 && <li className="muted pad">No matching command</li>}{list.slice(0, 40).map((c, k) => <li key={c.id}><button className={k === i ? 'on' : ''} disabled={c.enabled ? !c.enabled() : false} onMouseEnter={() => setI(k)} onClick={() => go(k)}><span>{c.label}</span>{c.shortcut && <kbd>{c.shortcut}</kbd>}</button></li>)}</ul></div></div>;
}

function FormDialog({ d, close }: { d: Extract<Dialog, { kind: 'form' }>; close: () => void }) {
  const [vals, setVals] = useState(() => Object.fromEntries(d.fields.map((f) => [f.key, f.value]))), [err, setErr] = useState<string | null>(null);
  const submit = (e: React.FormEvent) => { e.preventDefault(); const r = d.onSubmit(vals); if (typeof r === 'string') setErr(r); else close(); };
  return <form className="dlg" onSubmit={submit}>{d.art && <Illustration n={d.art} className="art art-sm" />}<h2>{d.title}</h2>
    {d.fields.map((f, k) => <label key={f.key} className="dfield"><span>{f.label}</span>{f.type === 'select' ? <select value={vals[f.key]} onChange={(e) => setVals({ ...vals, [f.key]: e.target.value })}>{f.options!.map((o) => <option key={o}>{o}</option>)}</select> : <input autoFocus={k === 0} type={f.type === 'number' ? 'text' : 'text'} inputMode={f.type === 'number' ? 'decimal' : 'text'} value={vals[f.key]} spellCheck={false} onChange={(e) => { setVals({ ...vals, [f.key]: e.target.value }); setErr(null); }} />}{f.hint && <small>{f.hint}</small>}</label>)}
    {err && <div className="perr" role="alert"><Icon n="warn" size={14} /> {err}</div>}
    <div className="dbtns"><button type="button" className="btn" onClick={close}>Cancel</button><button type="submit" className="btn primary">{d.submit}</button></div></form>;
}
function ProjectsDialog({ close }: { close: () => void }) {
  const [list, setList] = useState<Awaited<ReturnType<typeof A.projectsList>> | null>(null), [err, setErr] = useState<string | null>(null);
  const load = () => A.projectsList().then(setList).catch((e) => setErr(e.message)); useEffect(() => { void load(); }, []);
  return <div className="dlg wide"><h2>Projects in this browser</h2>
    {err && <div className="perr"><Icon n="warn" size={14} /> {err}</div>}{!list && !err && <p className="muted">Loading…</p>}
    {list && list.length === 0 && <div className="empty-state"><Illustration n="no-files" /><p className="muted">No saved projects yet. Use File › Save in this browser.</p></div>}
    <ul className="plist2">{list?.map((p) => <li key={p.id}><div><strong>{p.name}</strong><small>{new Date(p.modified).toLocaleString()}</small></div>
      <button className="btn" onClick={() => A.guardDirty(() => { A.openText(p.text, p.name); useUI.setState({ projectKey: p.id }); close(); })}>Open</button>
      <button className="btn danger" onClick={() => useUI.setState({ dialog: { kind: 'confirm', title: `Delete “${p.name}”?`, message: 'This permanently removes the saved copy from this browser.', confirm: 'Delete', danger: true, onConfirm: () => { void deleteProject(p.id).then(() => useUI.setState({ dialog: { kind: 'projects' } })); } } })}>Delete</button></li>)}</ul>
    <div className="dbtns"><button className="btn" onClick={close}>Close</button></div></div>;
}
function WelcomeDialog({ close }: { close: () => void }) {
  return <div className="dlg welcome"><Illustration n="welcome" /><h2><Logo size={28} /> FormaX</h2>
    <p>Parametric architecture software. Change one parameter and the whole dependent project updates. Works fully offline; your projects stay on this device.</p>
    <div className="dbtns col"><button className="btn primary" onClick={() => { close(); A.newProject(); }}>New project</button><button className="btn" onClick={() => { close(); A.loadExample(); }}>Open example house</button><button className="btn" onClick={() => { close(); A.openFilePicker(); }}>Open .formax file</button></div></div>;
}
function IssuesDialog({ close }: { close: () => void }) {
  const s = useSession();
  return <div className="dlg wide"><h2>Validation issues</h2>{s.model.issues.length === 0 ? <p className="ok-line"><Icon n="ok" size={16} /> No issues. All formulas resolve, constraints hold and geometry is valid.</p> :
    <ul className="issues big">{s.model.issues.map((i, k) => <li key={k} className={i.severity}><Icon n="warn" size={14} /><span>{i.message}</span>{i.objectId && <button className="btn small" onClick={() => { A.select([i.objectId!]); close(); }}>Select</button>}</li>)}</ul>}
    <div className="dbtns"><button className="btn" onClick={close}>Close</button></div></div>;
}
export function Dialogs() {
  const d = useUI((s) => s.dialog); const close = () => useUI.setState({ dialog: null });
  useEffect(() => { if (!d) return; const h = (e: KeyboardEvent) => { if (e.key === 'Escape') close(); }; window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h); }, [d]);
  if (!d) return null;
  let body: React.ReactNode;
  switch (d.kind) {
    case 'form': body = <FormDialog d={d} close={close} />; break;
    case 'confirm': body = <div className="dlg"><h2>{d.title}</h2><p className="pre">{d.message}</p><div className="dbtns">{d.confirm !== 'OK' && <button className="btn" onClick={close} autoFocus>Cancel</button>}<button className={d.danger ? 'btn danger' : 'btn primary'} onClick={() => { close(); d.onConfirm(); }}>{d.confirm}</button></div></div>; break;
    case 'projects': body = <ProjectsDialog close={close} />; break;
    case 'issues': body = <IssuesDialog close={close} />; break;
    case 'welcome': body = <WelcomeDialog close={close} />; break;
    case 'preview': body = <div className="dlg preview"><h2>{d.title}</h2><div className="svgbox" dangerouslySetInnerHTML={{ __html: d.svg.replace(/^<\?xml[^>]*\?>/, '').replace(/width="[\d.]+mm" height="[\d.]+mm"/, 'width="100%"') }} /><div className="dbtns"><button className="btn" onClick={close}>Close</button></div></div>; break;
    case 'recover': body = <div className="dlg"><h2>Recover unsaved work?</h2><p>FormaX found an autosaved copy from {new Date(d.time).toLocaleString()} that was never saved.</p><div className="dbtns"><button className="btn" onClick={() => { void clearAutosave(); close(); }}>Discard</button><button className="btn primary" onClick={() => { A.openText(d.text, 'autosave'); session.dirty = true; close(); }}>Recover</button></div></div>; break;
    case 'help': body = <div className="dlg wide"><h2>Keyboard shortcuts</h2><div className="kbd-grid">{[['V', 'Select'], ['B', 'Building footprint'], ['W', 'Interior wall'], ['R', 'Room'], ['D / N', 'Door / window'], ['K', 'Column'], ['L / P / C / M', 'Line / polyline / circle / dimension'], ['Enter', 'Finish room / polyline'], ['Esc', 'Cancel tool, deselect'], ['Shift (drawing)', 'Orthogonal'], ['Space + drag', 'Pan'], ['Wheel', 'Zoom'], ['Arrows', 'Nudge selection by grid'], ['Ctrl+Z / Y', 'Undo / redo'], ['Ctrl+D', 'Duplicate'], ['Del', 'Delete'], ['Ctrl+S', 'Save in browser'], ['Ctrl+K', 'Command palette'], ['F2 / F3', 'Plan / 3D'], ['PgUp / PgDn', 'Level up / down']].map(([k, v]) => <div key={k}><kbd>{k}</kbd><span>{v}</span></div>)}</div><div className="dbtns"><button className="btn" onClick={close}>Close</button></div></div>; break;
  }
  return <div className="overlay" onPointerDown={close}><div role="dialog" aria-modal="true" onPointerDown={(e) => e.stopPropagation()}>{body}</div></div>;
}
