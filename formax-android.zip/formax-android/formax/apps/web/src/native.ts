/** Bridge to the Android host (see apps/android MainActivity.kt). Everything here is a no-op in a normal browser. */
interface AndroidBridge { saveFile(name: string, mime: string, base64: string): void; setTheme(dark: boolean): void }
interface NativeCallbacks { saved?: (ok: boolean, name: string) => void }
type Win = Window & { FormaXAndroid?: AndroidBridge; __formaxNative?: NativeCallbacks };
const w = window as Win;
export const isAndroid = (): boolean => !!w.FormaXAndroid;

let pending: ((ok: boolean) => void) | null = null;
w.__formaxNative = { saved: (ok) => { const p = pending; pending = null; p?.(ok); } };

function toBase64(buf: ArrayBuffer): string {
  const b = new Uint8Array(buf); let s = ''; const CH = 0x8000;
  for (let i = 0; i < b.length; i += CH) s += String.fromCharCode(...b.subarray(i, i + CH));
  return btoa(s);
}
/** Hands a file to the system "Save as" dialog. Resolves true when it was written, false when cancelled or failed. */
export async function nativeSave(name: string, mime: string, data: BlobPart): Promise<boolean> {
  const bridge = w.FormaXAndroid; if (!bridge) return false;
  const buf = await new Blob([data], { type: mime }).arrayBuffer();
  return new Promise<boolean>((res) => { pending?.(false); pending = res; try { bridge.saveFile(name, mime, toBase64(buf)); } catch { pending = null; res(false); } });
}
export function nativeTheme(dark: boolean) { try { w.FormaXAndroid?.setTheme(dark); } catch { /* host without theme support */ } }
