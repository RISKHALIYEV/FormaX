import { useEffect, useRef } from 'react';
import { Vec2, v2, dist, bboxOf, sub, normalize, perp, add, scale as vscale, polygonCentroid } from '@formax/geometry';
import { hitTest, findSnap, addWall, addRoom, addOpening, addGeneric, addBuildingFootprint, translate, type RObj, type SnapResult, type P2E } from '@formax/core';
import { session } from './session';
import { useUI } from './store';
import { run, select, activeLevel, wallAt, toast, fmtLen } from './actions';

interface View { cx: number; cy: number; zoom: number }
interface Draft { pts: SnapResult[] }
const bboxOfObj = (m: typeof session.model, o: RObj): { min: Vec2; max: Vec2 } | null => {
  switch (o.type) {
    case 'wall': return bboxOf(o.polygon); case 'room': return bboxOf(o.net); case 'slab': case 'roof': case 'polyline': return bboxOf(o.points);
    case 'column': return bboxOf([v2(o.p.x - o.width / 2, o.p.y - o.depth / 2), v2(o.p.x + o.width / 2, o.p.y + o.depth / 2)]);
    case 'beam': case 'line': case 'dimension': return bboxOf([o.a, o.b]);
    case 'circle': return bboxOf([v2(o.c.x - o.r, o.c.y - o.r), v2(o.c.x + o.r, o.c.y + o.r)]);
    case 'door': case 'window': { const w = m.get(o.host); if (w?.type !== 'wall') return null; const d = normalize(sub(w.b, w.a)), c = add(w.a, vscale(d, o.offset)); return bboxOf([add(c, vscale(d, -o.width / 2)), add(c, vscale(d, o.width / 2))]); }
  }
};

export function Plan2D() {
  const canvas = useRef<HTMLCanvasElement>(null);
  const view = useRef<View>({ cx: 7500, cy: 6000, zoom: 0.04 });
  const S = useRef({ draft: { pts: [] } as Draft, hover: null as SnapResult | null, mouse: v2(0, 0), dragMove: null as null | { start: Vec2; delta: Vec2; ids: string[] }, box: null as null | { a: Vec2; b: Vec2 }, fp: null as null | { a: SnapResult }, space: false, pointers: new Map<number, { x: number; y: number }>(), pinch: null as null | { d: number; c: Vec2 }, pan: null as null | { x: number; y: number; cx: number; cy: number; moved: boolean }, down: null as null | { x: number; y: number; button: number; world: Vec2; hitId: string | null }, raf: 0 });

  const W = () => canvas.current!.clientWidth, H = () => canvas.current!.clientHeight;
  const toWorld = (px: number, py: number): Vec2 => { const v = view.current; return v2(v.cx + (px - W() / 2) / v.zoom, v.cy - (py - H() / 2) / v.zoom); };
  const toScreen = (p: Vec2): Vec2 => { const v = view.current; return v2((p.x - v.cx) * v.zoom + W() / 2, H() / 2 - (p.y - v.cy) * v.zoom); };
  const selectable = () => new Set(session.project.layers.filter((l) => l.visible && !l.locked).map((l) => l.id));
  const snapAt = (w: Vec2, shift: boolean): SnapResult => {
    const u = useUI.getState(), a = S.current.draft.pts[S.current.draft.pts.length - 1];
    return findSnap(session.model, w, { tol: 12 / view.current.zoom, grid: u.grid, endpoints: u.snaps.endpoints, midpoints: u.snaps.midpoints, intersections: u.snaps.intersections, edges: u.snaps.edges, gridOn: u.snaps.grid, level: activeLevel(), anchor: a ? { pt: a.point, ex: a.ex } : undefined, ortho: (shift || u.snaps.ortho) && !!a });
  };
  if (typeof window !== 'undefined' && location.search.includes('e2e')) (window as unknown as Record<string, unknown>).__formaxPlan = { toScreen: (x: number, y: number) => { const s = toScreen(v2(x, y)), r = canvas.current!.getBoundingClientRect(); return [s.x + r.left, s.y + r.top]; } };
  const invalidate = () => { if (S.current.raf) return; S.current.raf = requestAnimationFrame(() => { S.current.raf = 0; draw(); }); };

  const zoomExtents = () => {
    const m = session.model, lv = activeLevel(); const pts: Vec2[] = [];
    for (const o of m.resolved.values()) if (o.level === lv) { const b = bboxOfObj(m, o); if (b) pts.push(b.min, b.max); }
    const bb = bboxOf(pts) ?? { min: v2(-2000, -2000), max: v2(18000, 14000) };
    const w = Math.max(bb.max.x - bb.min.x, 2000), h = Math.max(bb.max.y - bb.min.y, 2000);
    view.current = { cx: (bb.min.x + bb.max.x) / 2, cy: (bb.min.y + bb.max.y) / 2, zoom: Math.min(W() / (w * 1.25), H() / (h * 1.25)) };
    invalidate();
  };

  // ---------------- drawing ----------------
  function draw() {
    const c = canvas.current; if (!c) return; const dpr = window.devicePixelRatio || 1, w = c.clientWidth, h = c.clientHeight;
    if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
    const g = c.getContext('2d')!; g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const css = getComputedStyle(c), col = (n: string) => css.getPropertyValue(n).trim();
    g.fillStyle = col('--plan-bg'); g.fillRect(0, 0, w, h);
    const u = useUI.getState(), m = session.model, lv = activeLevel(), vz = view.current.zoom, sel = new Set(u.selection);
    const layerVis = new Set(session.project.layers.filter((l) => l.visible).map((l) => l.id));
    // grid
    let step = u.grid; while (step * vz < 7) step *= 5;
    const tl = toWorld(0, 0), br = toWorld(w, h);
    g.lineWidth = 1;
    for (let k = 0; k < 2; k++) {
      const st = k ? step * 5 : step; g.strokeStyle = k ? col('--plan-grid-major') : col('--plan-grid'); g.beginPath();
      for (let x = Math.ceil(tl.x / st) * st; x <= br.x; x += st) { const sx = Math.round(toScreen(v2(x, 0)).x) + 0.5; g.moveTo(sx, 0); g.lineTo(sx, h); }
      for (let y = Math.ceil(br.y / st) * st; y <= tl.y; y += st) { const sy = Math.round(toScreen(v2(0, y)).y) + 0.5; g.moveTo(0, sy); g.lineTo(w, sy); }
      g.stroke();
    }
    g.strokeStyle = col('--plan-axis'); g.beginPath(); const o0 = toScreen(v2(0, 0)); g.moveTo(0, o0.y); g.lineTo(w, o0.y); g.moveTo(o0.x, 0); g.lineTo(o0.x, h); g.stroke();
    const path = (pts: Vec2[], close = true) => { g.beginPath(); pts.forEach((p, i) => { const s = toScreen(p); i ? g.lineTo(s.x, s.y) : g.moveTo(s.x, s.y); }); if (close) g.closePath(); };
    const move = S.current.dragMove; const off = (id: string) => (move && move.ids.includes(id) ? move.delta : null);
    const shift = (pts: Vec2[], d: Vec2 | null) => (d ? pts.map((p) => v2(p.x + d.x, p.y + d.y)) : pts);
    // level below (ghost)
    const li = session.project.levels.findIndex((l) => l.id === lv);
    if (li > 0) { g.fillStyle = col('--plan-ghost'); for (const wl of m.byType('wall', session.project.levels[li - 1].id)) { path(wl.polygon); g.fill(); } }
    const objs = [...m.resolved.values()].filter((o) => o.level === lv && layerVis.has(o.layer));
    for (const o of objs) if (o.type === 'room') { path(shift(o.net, off(o.id))); g.fillStyle = sel.has(o.id) ? col('--plan-room-sel') : col('--plan-room'); g.fill(); g.strokeStyle = col('--plan-room-line'); g.lineWidth = 1; g.stroke(); }
    for (const o of objs) if (o.type === 'slab' || o.type === 'roof') { path(shift(o.points, off(o.id))); g.setLineDash([6, 4]); g.strokeStyle = col('--plan-room-line'); g.stroke(); g.setLineDash([]); }
    for (const o of objs) if (o.type === 'wall') { path(shift(o.polygon, off(o.id))); g.fillStyle = col('--plan-wall'); g.fill(); }
    for (const o of objs) if (o.type === 'door' || o.type === 'window') {
      const wl = m.get(o.host); if (wl?.type !== 'wall') continue;
      const dd = off(wl.id) ?? v2(0, 0), d = normalize(sub(wl.b, wl.a)), n = perp(d), cc = add(add(wl.a, vscale(d, o.offset)), dd), hw = o.width / 2, ht = wl.thickness / 2 + 2;
      const quad = [add(add(cc, vscale(d, -hw)), vscale(n, -ht)), add(add(cc, vscale(d, hw)), vscale(n, -ht)), add(add(cc, vscale(d, hw)), vscale(n, ht)), add(add(cc, vscale(d, -hw)), vscale(n, ht))];
      path(quad); g.fillStyle = col('--plan-bg'); g.fill();
      g.strokeStyle = col('--plan-ink'); g.lineWidth = 1.2;
      if (o.type === 'window') { for (const f of [-1, 0, 1]) { path([add(add(cc, vscale(d, -hw)), vscale(n, (f * wl.thickness) / 3)), add(add(cc, vscale(d, hw)), vscale(n, (f * wl.thickness) / 3))], false); g.stroke(); } }
      else { const hinge = add(cc, vscale(d, -hw)); path([hinge, add(hinge, vscale(n, o.width))], false); g.stroke(); const arc: Vec2[] = []; for (let i = 0; i <= 14; i++) { const th = (i / 14) * (Math.PI / 2); arc.push(add(hinge, add(vscale(d, o.width * Math.cos(th)), vscale(n, o.width * Math.sin(th))))); } path(arc, false); g.lineWidth = 0.8; g.stroke(); }
    }
    g.lineWidth = 1.2; g.strokeStyle = col('--plan-ink');
    for (const o of objs) {
      const d = off(o.id);
      if (o.type === 'column') { path(shift([v2(o.p.x - o.width / 2, o.p.y - o.depth / 2), v2(o.p.x + o.width / 2, o.p.y - o.depth / 2), v2(o.p.x + o.width / 2, o.p.y + o.depth / 2), v2(o.p.x - o.width / 2, o.p.y + o.depth / 2)], d)); g.fillStyle = col('--plan-wall'); g.fill(); }
      else if (o.type === 'beam' || o.type === 'line') { path(shift([o.a, o.b], d), false); g.strokeStyle = col('--plan-ink'); g.stroke(); }
      else if (o.type === 'polyline') { path(shift(o.points, d), false); g.stroke(); }
      else if (o.type === 'circle') { const s = toScreen(d ? add(o.c, d) : o.c); g.beginPath(); g.arc(s.x, s.y, o.r * vz, 0, Math.PI * 2); g.stroke(); }
      else if (o.type === 'dimension') drawDim(g, shift([o.a, o.b], d), o.offset, col('--plan-dim'));
    }
    g.font = `${Math.max(10, Math.min(14, 11 + vz * 20))}px ${css.getPropertyValue('--font-ui')}`; g.textAlign = 'center'; g.fillStyle = col('--plan-ink');
    for (const o of objs) if (o.type === 'room' && vz > 0.012) { const cs = toScreen(add(polygonCentroid(o.net), off(o.id) ?? v2(0, 0))); g.fillText(o.name, cs.x, cs.y - 4); g.fillStyle = col('--plan-dim'); g.fillText(`${(o.netArea / 1e6).toFixed(2)} m²`, cs.x, cs.y + 12); g.fillStyle = col('--plan-ink'); }
    // selection overlay
    g.strokeStyle = col('--accent'); g.lineWidth = 2; g.fillStyle = col('--accent');
    for (const o of objs) if (sel.has(o.id)) {
      const d = off(o.id) ?? (o.type === 'door' || o.type === 'window' ? off(o.host) : null);
      if (o.type === 'wall') { path(shift(o.polygon, d)); g.stroke(); for (const p of [o.a, o.b]) { const s = toScreen(d ? add(p, d) : p); g.fillRect(s.x - 3.5, s.y - 3.5, 7, 7); } const mid = toScreen(add(vscale(add(o.a, o.b), 0.5), d ?? v2(0, 0))); g.textAlign = 'center'; g.fillText(fmtLen(o.length), mid.x, mid.y - 10); }
      else if (o.type === 'room') { path(shift(o.net, d)); g.stroke(); } else if (o.type === 'slab' || o.type === 'roof') { path(shift(o.points, d)); g.stroke(); }
      else { const b = bboxOfObj(m, o); if (b) { const a = toScreen(v2(b.min.x, b.max.y)), z = toScreen(v2(b.max.x, b.min.y)); g.strokeRect(a.x - 4, a.y - 4, z.x - a.x + 8, z.y - a.y + 8); } }
    }
    // tool previews
    const tool = u.tool, st = S.current, hv = st.hover;
    g.lineWidth = 1.5; g.strokeStyle = col('--accent'); g.setLineDash([5, 4]);
    const pts = st.draft.pts.map((p) => p.point);
    if (hv && pts.length && ['wall', 'line', 'dimension', 'polyline', 'room'].includes(tool)) { path([...pts, hv.point], false); g.stroke(); if (tool === 'room' && pts.length >= 2) { path([...pts, hv.point]); g.fillStyle = col('--plan-room-sel'); g.fill(); } const last = pts[pts.length - 1]; const mid = toScreen(add(vscale(add(last, hv.point), 0.5), v2(0, 0))); g.setLineDash([]); g.fillStyle = col('--accent'); g.textAlign = 'center'; g.fillText(fmtLen(dist(last, hv.point)), mid.x, mid.y - 8); }
    if (hv && pts.length && tool === 'circle') { const s = toScreen(pts[0]); g.beginPath(); g.arc(s.x, s.y, dist(pts[0], hv.point) * vz, 0, Math.PI * 2); g.stroke(); }
    if (tool === 'footprint' && st.fp && hv) { const a = st.fp.a.point, b = hv.point; path([a, v2(b.x, a.y), b, v2(a.x, b.y)]); g.stroke(); g.setLineDash([]); g.fillStyle = col('--accent'); g.textAlign = 'center'; const sc = toScreen(v2((a.x + b.x) / 2, Math.max(a.y, b.y))); g.fillText(`${fmtLen(Math.abs(b.x - a.x))} × ${fmtLen(Math.abs(b.y - a.y))}`, sc.x, sc.y - 8); }
    if (st.box) { const a = toScreen(st.box.a), b = toScreen(st.box.b); g.setLineDash([4, 3]); g.strokeStyle = col('--accent'); g.strokeRect(a.x, a.y, b.x - a.x, b.y - a.y); g.fillStyle = col('--plan-room-sel'); g.fillRect(a.x, a.y, b.x - a.x, b.y - a.y); }
    g.setLineDash([]);
    if ((tool === 'door' || tool === 'window') && hv) { const wa = wallAt(m, lv, hv.point, 12 / vz); if (wa) { const wl = m.get(wa.id); if (wl?.type === 'wall') { path(wl.polygon); g.strokeStyle = col('--accent'); g.lineWidth = 2; g.stroke(); } } }
    if (hv && tool !== 'select') { const s = toScreen(hv.point); g.strokeStyle = col('--snap'); g.lineWidth = 1.5; g.beginPath(); if (hv.kind === 'endpoint') g.rect(s.x - 5, s.y - 5, 10, 10); else if (hv.kind === 'midpoint') { g.moveTo(s.x, s.y - 6); g.lineTo(s.x + 6, s.y + 5); g.lineTo(s.x - 6, s.y + 5); g.closePath(); } else if (hv.kind === 'intersection') { g.moveTo(s.x - 6, s.y - 6); g.lineTo(s.x + 6, s.y + 6); g.moveTo(s.x + 6, s.y - 6); g.lineTo(s.x - 6, s.y + 6); } else if (hv.kind === 'edge') { g.arc(s.x, s.y, 5, 0, Math.PI * 2); } else { g.moveTo(s.x - 5, s.y); g.lineTo(s.x + 5, s.y); g.moveTo(s.x, s.y - 5); g.lineTo(s.x, s.y + 5); } g.stroke(); }
    // empty-state hint
    if (!session.project.objects.length) { g.fillStyle = col('--plan-dim'); g.textAlign = 'center'; g.font = `500 15px ${css.getPropertyValue('--font-ui')}`; g.fillText('Empty project', w / 2, h / 2 - 8); g.font = `13px ${css.getPropertyValue('--font-ui')}`; g.fillText('Pick “Building footprint” (B) and drag a rectangle, or use Architecture › Building footprint…', w / 2, h / 2 + 14); }
    // scale bar
    const nice = [100, 200, 500, 1000, 2000, 5000, 10000].find((n) => n * vz > 70) ?? 20000; g.strokeStyle = col('--plan-ink'); g.lineWidth = 2; g.beginPath(); g.moveTo(14, h - 16); g.lineTo(14 + nice * vz, h - 16); g.moveTo(14, h - 21); g.lineTo(14, h - 11); g.moveTo(14 + nice * vz, h - 21); g.lineTo(14 + nice * vz, h - 11); g.stroke(); g.fillStyle = col('--plan-ink'); g.textAlign = 'left'; g.font = `11px ${css.getPropertyValue('--font-ui')}`; g.fillText(fmtLen(nice), 14, h - 26);
  }
  function drawDim(g: CanvasRenderingContext2D, [a, b]: Vec2[], offset: number, color: string) {
    const d = normalize(sub(b, a)), n = perp(d), o = vscale(n, offset), a2 = toScreen(add(a, o)), b2 = toScreen(add(b, o)), a1 = toScreen(a), b1 = toScreen(b);
    g.strokeStyle = color; g.fillStyle = color; g.lineWidth = 1; g.beginPath(); g.moveTo(a1.x, a1.y); g.lineTo(a2.x, a2.y); g.moveTo(b1.x, b1.y); g.lineTo(b2.x, b2.y); g.moveTo(a2.x, a2.y); g.lineTo(b2.x, b2.y); g.stroke();
    g.save(); g.translate((a2.x + b2.x) / 2, (a2.y + b2.y) / 2); let ang = Math.atan2(b2.y - a2.y, b2.x - a2.x); if (Math.abs(ang) > Math.PI / 2) ang += Math.PI; g.rotate(ang); g.textAlign = 'center'; g.fillText(fmtLen(dist(a, b)), 0, -4); g.restore();
  }

  // ---------------- interaction ----------------
  const clickTool = (snap: SnapResult, w: Vec2) => {
    const u = useUI.getState(), lv = activeLevel(), st = S.current, d = st.draft;
    const two = (fn: (a: SnapResult, b: SnapResult) => string | void, chain: boolean) => {
      if (!d.pts.length) { d.pts = [snap]; return; }
      if (dist(d.pts[0].point, snap.point) < 1) return;
      fn(d.pts[0], snap); d.pts = chain ? [snap] : [];
    };
    switch (u.tool) {
      case 'wall': two((a, b) => { run('Wall', (p) => addWall(p, { a: a.ex, b: b.ex, level: lv })); }, true); break;
      case 'line': two((a, b) => { run('Line', (p) => addGeneric(p, 'line', lv, { a: a.ex, b: b.ex })); }, true); break;
      case 'dimension': two((a, b) => { run('Dimension', (p) => addGeneric(p, 'dimension', lv, { a: a.ex, b: b.ex, offset: 600 })); }, false); break;
      case 'circle': two((a, b) => { run('Circle', (p) => addGeneric(p, 'circle', lv, { c: a.ex, r: Math.round(dist(a.point, b.point)) })); }, false); break;
      case 'polyline': case 'room': {
        if (d.pts.length >= 3 && u.tool === 'room' && dist(d.pts[0].point, snap.point) < 1) { finish(); return; }
        d.pts.push(snap); break;
      }
      case 'column': { const r = run('Column', (p) => addGeneric(p, 'column', lv, { p: snap.ex, width: 400, depth: 400, height: p.levels.find((l) => l.id === lv)!.height })); if (r.ok) select([r.value as string]); break; }
      case 'door': case 'window': {
        const wa = wallAt(session.model, lv, w, 12 / view.current.zoom); if (!wa) { toast(`Click on a wall to place the ${u.tool}.`); return; }
        const off = Math.round(wa.offset / 50) * 50, r = run(u.tool === 'door' ? 'Door' : 'Window', (p) => addOpening(p, { type: u.tool as 'door' | 'window', host: wa.id, offset: off, level: lv })); if (r.ok) select([r.value as string]); break;
      }
    }
  };
  const finish = () => {
    const u = useUI.getState(), d = S.current.draft, lv = activeLevel(); const ex: P2E[] = d.pts.map((p) => p.ex);
    if (u.tool === 'room' && ex.length >= 3) { const r = run('Room', (p) => addRoom(p, { points: ex, level: lv })); if (r.ok) select([r.value as string]); }
    else if (u.tool === 'polyline' && ex.length >= 2) run('Polyline', (p) => addGeneric(p, 'polyline', lv, { points: ex }));
    d.pts = []; invalidate();
  };
  useEffect(() => { S.current.draft.pts = []; S.current.fp = null; invalidate(); }, [useUI((s) => s.cancel)]);
  useEffect(() => { if (useUI.getState().finish) finish(); }, [useUI((s) => s.finish)]);
  useEffect(() => { zoomExtents(); }, [useUI((s) => s.frame), useUI((s) => s.level)]);

  useEffect(() => {
    const c = canvas.current!, ro = new ResizeObserver(() => invalidate()); ro.observe(c);
    const un1 = session.subscribe(invalidate), un2 = useUI.subscribe(invalidate);
    const kd = (e: KeyboardEvent) => { if (e.code === 'Space' && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) S.current.space = true; }; const ku = (e: KeyboardEvent) => { if (e.code === 'Space') S.current.space = false; };
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku); zoomExtents();
    return () => { ro.disconnect(); un1(); un2(); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); cancelAnimationFrame(S.current.raf); S.current.raf = 0; };
  }, []);

  const local = (e: { clientX: number; clientY: number }) => { const r = canvas.current!.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
  const onDown = (e: React.PointerEvent) => {
    const c = canvas.current!; c.setPointerCapture(e.pointerId); const p = local(e), st = S.current; st.pointers.set(e.pointerId, p);
    useUI.setState({ context: null, menu: null });
    if (st.pointers.size === 2) { const [a, b] = [...st.pointers.values()]; st.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), c: v2((a.x + b.x) / 2, (a.y + b.y) / 2) }; st.down = null; st.dragMove = null; st.box = null; st.fp = null; st.pan = null; return; }
    const w = toWorld(p.x, p.y), u = useUI.getState();
    if (e.button === 1 || e.button === 2 || (e.button === 0 && st.space)) { st.pan = { x: p.x, y: p.y, cx: view.current.cx, cy: view.current.cy, moved: false }; st.down = { ...p, button: e.button, world: w, hitId: null }; return; }
    const snap = snapAt(w, e.shiftKey); st.hover = snap;
    const hitId = u.tool === 'select' ? hitTest(session.model, w, 8 / view.current.zoom, activeLevel(), selectable()) : null;
    st.down = { ...p, button: 0, world: w, hitId };
    if (u.tool === 'footprint') st.fp = { a: snap };
    if (u.tool === 'select') { if (hitId && !u.selection.includes(hitId) && !e.shiftKey) select([hitId]); }
  };
  const onMove = (e: React.PointerEvent) => {
    const st = S.current, p = local(e), u = useUI.getState(); st.pointers.set(e.pointerId, p);
    if (st.pinch && st.pointers.size >= 2) {
      const [a, b] = [...st.pointers.values()], d = Math.hypot(a.x - b.x, a.y - b.y), cc = v2((a.x + b.x) / 2, (a.y + b.y) / 2), v = view.current, before = toWorld(st.pinch.c.x, st.pinch.c.y);
      v.zoom = Math.max(0.002, Math.min(2, v.zoom * (d / st.pinch.d))); const after = toWorld(cc.x, cc.y); v.cx += before.x - after.x; v.cy += before.y - after.y; st.pinch = { d, c: cc }; invalidate(); return;
    }
    const w = toWorld(p.x, p.y); st.mouse = w;
    if (st.pan) { const dx = p.x - st.pan.x, dy = p.y - st.pan.y; if (Math.hypot(dx, dy) > 4) st.pan.moved = true; view.current.cx = st.pan.cx - dx / view.current.zoom; view.current.cy = st.pan.cy + dy / view.current.zoom; invalidate(); return; }
    const snap = snapAt(w, e.shiftKey); st.hover = snap; useUI.setState({ cursor: { x: snap.point.x, y: snap.point.y, kind: snap.kind } });
    const dn = st.down;
    if (dn && u.tool === 'select') {
      const moved = Math.hypot(p.x - dn.x, p.y - dn.y) > 5;
      if (moved && dn.hitId) { const ids = u.selection.includes(dn.hitId) ? u.selection : [dn.hitId]; const g = u.snaps.grid ? u.grid : 1, raw = sub(w, dn.world); st.dragMove = { start: dn.world, ids, delta: v2(Math.round(raw.x / g) * g, Math.round(raw.y / g) * g) }; }
      else if (moved && !dn.hitId) st.box = { a: dn.world, b: w };
    }
    invalidate();
  };
  const onUp = (e: React.PointerEvent) => {
    const st = S.current, p = local(e), u = useUI.getState(); st.pointers.delete(e.pointerId);
    if (st.pinch) { if (st.pointers.size < 2) st.pinch = null; st.down = null; return; }
    const dn = st.down; st.down = null; const w = toWorld(p.x, p.y);
    if (st.pan) { const was = st.pan; st.pan = null; if (dn?.button === 2 && !was.moved) { const id = hitTest(session.model, w, 8 / view.current.zoom, activeLevel(), selectable()); if (id && !u.selection.includes(id)) select([id]); useUI.setState({ context: { x: e.clientX, y: e.clientY } }); } return; }
    if (!dn) return; const moved = Math.hypot(p.x - dn.x, p.y - dn.y) > 5;
    if (u.tool === 'select') {
      if (st.dragMove) { const m = st.dragMove; st.dragMove = null; if (Math.abs(m.delta.x) + Math.abs(m.delta.y) > 0) run('Move', (pr) => translate(pr, m.ids, m.delta.x, m.delta.y)); }
      else if (st.box) { const b = st.box; st.box = null; const lo = v2(Math.min(b.a.x, b.b.x), Math.min(b.a.y, b.b.y)), hi = v2(Math.max(b.a.x, b.b.x), Math.max(b.a.y, b.b.y)), crossing = b.b.x < b.a.x, ok = selectable(), ids: string[] = [];
        for (const o of session.model.resolved.values()) { if (o.level !== activeLevel() || !ok.has(o.layer)) continue; const bb = bboxOfObj(session.model, o); if (!bb) continue; const inside = bb.min.x >= lo.x && bb.max.x <= hi.x && bb.min.y >= lo.y && bb.max.y <= hi.y, hit = bb.max.x >= lo.x && bb.min.x <= hi.x && bb.max.y >= lo.y && bb.min.y <= hi.y; if (crossing ? hit : inside) ids.push(o.id); }
        select(e.shiftKey ? [...new Set([...u.selection, ...ids])] : ids); }
      else if (!moved) { if (dn.hitId) select(e.shiftKey ? (u.selection.includes(dn.hitId) ? u.selection.filter((x) => x !== dn.hitId) : [...u.selection, dn.hitId]) : [dn.hitId]); else if (!e.shiftKey) select([]); }
    } else if (u.tool === 'footprint') {
      const fp = st.fp; st.fp = null; if (fp) { const b = snapAt(w, false).point, a = fp.a.point, wd = Math.abs(b.x - a.x), ln = Math.abs(b.y - a.y);
        if (wd < 500 || ln < 500) { if (moved) toast('Footprint must be at least 500 × 500 mm.'); } else { const r = run('Building footprint', (pr) => addBuildingFootprint(pr, { x: Math.min(a.x, b.x), y: Math.min(a.y, b.y), width: wd, length: ln, level: activeLevel() })); if (r.ok) { select(r.value!.ids); useUI.setState({ tool: 'select' }); } } }
    } else if (!moved) clickTool(snapAt(w, e.shiftKey), w);
    invalidate();
  };
  const onWheel = (e: React.WheelEvent) => { const p = local(e), v = view.current, before = toWorld(p.x, p.y); v.zoom = Math.max(0.002, Math.min(2, v.zoom * Math.exp(-e.deltaY * 0.0015))); const after = toWorld(p.x, p.y); v.cx += before.x - after.x; v.cy += before.y - after.y; invalidate(); };
  const tool = useUI((s) => s.tool);
  return <canvas ref={canvas} className="plan-canvas" data-tool={tool} aria-label="2D plan editor" onPointerDown={onDown} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} onWheel={onWheel} onContextMenu={(e) => e.preventDefault()} onDoubleClick={() => { const t = useUI.getState().tool; if (t === 'room' || t === 'polyline') { S.current.draft.pts.pop(); finish(); } else if (t === 'wall' || t === 'line') { S.current.draft.pts = []; invalidate(); } }} onPointerLeave={() => { S.current.hover = null; invalidate(); }} />;
}
