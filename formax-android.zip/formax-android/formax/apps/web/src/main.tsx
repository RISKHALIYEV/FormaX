import { createRoot } from 'react-dom/client';
import { App } from './App';
import './styles.css';
import { session } from './session';
import { useUI } from './store';
// Test hook: only exposed with ?e2e in the URL (used by the end-to-end acceptance script).
if (new URLSearchParams(location.search).has('e2e')) (window as unknown as Record<string, unknown>).__formax = { session, ui: useUI };
createRoot(document.getElementById('root')!).render(<App />);
// Offline shell for the hosted web build. Skipped inside the Android app (assets are bundled) and on file://.
if ('serviceWorker' in navigator && location.protocol.startsWith('http') && location.hostname !== 'appassets.androidplatform.net') {
  window.addEventListener('load', () => { navigator.serviceWorker.register('./sw.js').catch(() => { /* optional */ }); });
}
