import { Illustration } from './illustrations';
import { useState } from 'react';
import { wallBoxes, boxVolume, exprPaths, getPath, setField, setProp, removeParameter, removeConstraint, type ArchObject } from '@formax/core';
import { session, useSession } from './session';
import { useUI } from './store';
import * as A from './actions';
import { Icon } from './icons';
import { TOOLS, TOOL_HELP } from './commands';

const TYPE_LABEL: Record<string, string> = { wall: 'Walls', room: 'Rooms', door: 'Doors', window: 'Windows', slab: 'Slabs', roof: 'Roofs', column: 'Columns', beam: 'Beams', dimension: 'Dimensions', line: 'Lines', polyline: 'Polylines', circle: 'Circles' };
const pathLabel = (p: string) => p.replace(/^a\./, 'Start ').replace(/^b\./, 'End ').replace(/^p\./, 'Position ').replace(/^c\./, 'Centre ').replace(/^points\.(\d+)\./, (_, i) => `Point ${Number(i) + 1} `).replace(/\.x$|^x$/, 'X').replace(/\.y$/, 'Y').replace(/^(\w)/, (m) => m.toUpperCase());
const valueOf = (o: ArchObject, path: string): number | undefined => { const e = getPath(o, path); const v = typeof e === 'number' ? e : session.model.engine.value(`${o.id}.${path}`); return typeof v === 'number' ? v : undefined; };

export function ToolStrip() {
  const tool = useUI((s) => s.tool); useUI((s) => s.lang);
  return (
    <nav className="toolstrip" aria-label="Tools">
      {TOOLS.map((t, i) => (
        <button key={t.id} className={tool === t.id ? 'tool on' : 'tool'} title={`${t.label} (${t.key})`} aria-pressed={tool === t.id} onClick={() => A.setTool(t.id)}>
          <Icon n={t.icon} size={20} /><span>{t.label}</span>{i === 0 && <i className="sep" />}
        </button>
      ))}
    </nav>
  );
}
export function ToolHint() { const tool = useUI((s) => s.tool), view = useUI((s) => s.view); return <div className="toolhint">{view === 'plan' ? TOOL_HELP[tool] : 'Select objects in 3D; edit them in Properties. Switch to Plan to draw.'}</div>; }

function Section({ title, children, action, open = true }: { title: string; children: React.ReactNode; action?: React.ReactNode; open?: boolean }) {
  const [o, setO] = useState(open);
  return <section className="section"><header><button className="fold" onClick={() => setO(!o)} aria-expanded={o}>{o ? '▾' : '▸'} {title}</button>{action}</header>{o && <div className="section-body">{children}</div>}</section>;
}
export function LeftPanel() {
  const s = useSession(); const level = A.activeLevel(); const sel = useUI((u) => u.selection); useUI((u) => u.lang);
  const byType = new Map<string, ArchObject[]>(); for (const o of s.project.objects) if (o.level === level) { (byType.get(o.type) ?? byType.set(o.type, []).get(o.type)!).push(o); }
  const toggle = (k: 'visible' | 'locked', id: string) => A.run('Layer', (p) => { const l = p.layers.find((x) => x.id === id)!; l[k] = !l[k]; });
  return (
    <div className="panel-body">
      <Section title="Project">
        <div className="proj-name" title={s.project.name}>{s.project.name}</div>
        <ul className="levels" aria-label="Levels">
          {s.project.levels.map((l) => { const r = s.model.levels.get(l.id); return <li key={l.id}><button className={l.id === level ? 'row on' : 'row'} onClick={() => useUI.setState({ level: l.id, selection: [] })}><span>{l.name}</span><em>{r && Number.isFinite(r.elevation) ? A.fmtLen(r.elevation) : '—'}</em></button></li>; })}
        </ul>
      </Section>
      <Section title="Objects on level">
        {byType.size === 0 && <div className="empty-state"><Illustration n="empty-project" /><p className="muted">No objects on this level yet. Pick the Building footprint tool and drag a rectangle.</p></div>}
        {[...byType].map(([t, list]) => (
          <details key={t} open={list.some((o) => sel.includes(o.id))}><summary>{TYPE_LABEL[t] ?? t} <em>{list.length}</em></summary>
            <ul className="objlist">{list.map((o) => <li key={o.id}><button className={sel.includes(o.id) ? 'row on' : 'row'} onClick={(e) => A.select(e.shiftKey ? (sel.includes(o.id) ? sel.filter((x) => x !== o.id) : [...sel, o.id]) : [o.id])}><span>{o.name}</span><em>{o.id}</em></button></li>)}</ul>
          </details>))}
      </Section>
      <Section title="Layers">
        <ul className="layers">{s.project.layers.map((l) => (
          <li key={l.id}><span className="lname">{l.name}</span>
            <button className="icon" title={l.visible ? 'Hide layer' : 'Show layer'} aria-pressed={l.visible} onClick={() => toggle('visible', l.id)}><Icon n={l.visible ? 'eye' : 'eyeoff'} size={15} /></button>
            <button className="icon" title={l.locked ? 'Unlock layer' : 'Lock layer (not selectable)'} aria-pressed={l.locked} onClick={() => toggle('locked', l.id)}><Icon n={l.locked ? 'lock' : 'unlock'} size={15} /></button></li>))}</ul>
      </Section>
    </div>
  );
}

function ExprField({ obj, path }: { obj: ArchObject; path: string }) {
  const raw = String(getPath(obj, path)), v = valueOf(obj, path), err = session.model.engine.error(`${obj.id}.${path}`);
  const [text, setText] = useState(raw);
  const commit = () => { if (text.trim() === raw) return; if (!text.trim()) { setText(raw); return A.toast('Value cannot be empty', 'error'); } const r = A.run(`Edit ${path}`, (p) => setField(p, obj.id, path, text)); if (!r.ok) setText(raw); };
  const isFormula = typeof getPath(obj, path) === 'string';
  return (
    <label className={err ? 'field bad' : 'field'}><span>{pathLabel(path)}</span>
      <input value={text} spellCheck={false} onChange={(e) => setText(e.target.value)} onBlur={commit} onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); if (e.key === 'Escape') { setText(raw); (e.target as HTMLInputElement).blur(); } }} />
      <em title={err ?? 'Resolved value (mm)'}>{err ? '!' : isFormula && v !== undefined ? `= ${Math.round(v * 100) / 100}` : ''}</em></label>
  );
}
function Properties() {
  const s = useSession(); const ids = useUI((u) => u.selection).filter((id) => s.model.project.objects.some((o) => o.id === id));
  if (!ids.length) return (
    <div className="props-empty"><h3>No selection</h3><p>Select an object in the plan, the project browser or the 3D view to inspect and edit it.</p>
      <dl className="kv"><dt>Objects</dt><dd>{s.project.objects.length}</dd><dt>Levels</dt><dd>{s.project.levels.length}</dd><dt>Parameters</dt><dd>{s.project.parameters.length}</dd></dl></div>);
  const objs = ids.map((id) => s.project.objects.find((o) => o.id === id)!);
  const setAll = (key: 'layer' | 'material', v: string) => A.run('Edit property', (p) => ids.forEach((id) => setProp(p, id, key, v)));
  const first = objs[0], same = (k: 'layer' | 'material') => (objs.every((o) => o[k] === first[k]) ? first[k] : '');
  const issues = s.model.issues.filter((i) => ids.includes(i.objectId ?? ''));
  return (
    <div className="props">
      <h3>{objs.length > 1 ? `${objs.length} objects` : `${TYPE_LABEL[first.type]?.replace(/s$/, '') ?? first.type}`}<small>{objs.length === 1 ? first.id : [...new Set(objs.map((o) => o.type))].join(', ')}</small></h3>
      {objs.length === 1 && <label className="field"><span>Name</span><input defaultValue={first.name} key={first.id + first.name} onBlur={(e) => e.target.value.trim() && e.target.value !== first.name && A.run('Rename', (p) => setProp(p, first.id, 'name', e.target.value.trim()))} /></label>}
      <label className="field"><span>Layer</span><select value={same('layer')} onChange={(e) => setAll('layer', e.target.value)}>{!same('layer') && <option value="">(mixed)</option>}{s.project.layers.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}</select></label>
      <label className="field"><span>Material</span><select value={same('material')} onChange={(e) => setAll('material', e.target.value)}>{!same('material') && <option value="">(mixed)</option>}{s.project.materials.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select>
        <i className="swatch" style={{ background: s.project.materials.find((m) => m.id === same('material'))?.color ?? 'transparent' }} /></label>
      {objs.length === 1 && <>
        <dl className="kv"><dt>Level</dt><dd>{s.model.levels.get(first.level)?.name ?? first.level}</dd>{'host' in first && <><dt>Host wall</dt><dd>{first.host}</dd></>}</dl>
        <h4>Geometry <small>values in mm · formulas allowed</small></h4>
        {exprPaths(first).map((p) => <ExprField key={`${first.id}.${p}.${String(getPath(first, p))}`} obj={first} path={p} />)}
        <Derived id={first.id} /></>}
      {issues.length > 0 && <ul className="issues">{issues.map((i, k) => <li key={k} className={i.severity}><Icon n="warn" size={14} /> {i.message}</li>)}</ul>}
    </div>
  );
}
function Derived({ id }: { id: string }) {
  const r = session.model.get(id); if (!r) return null;
  const rows: [string, string][] = [];
  if (r.type === 'wall') { const ops = session.model.openingsOf(r.id); rows.push(['Length', A.fmtLen(r.length)], ['Area (net of openings)', `${((r.length * r.height - ops.reduce((a, o) => a + o.width * o.height, 0)) / 1e6).toFixed(2)} m²`], ['Openings', String(ops.length)]); }
  if (r.type === 'room') rows.push(['Net area', `${(r.netArea / 1e6).toFixed(2)} m²`], ['Gross (centre-line) area', `${(r.grossArea / 1e6).toFixed(2)} m²`], ['Perimeter', A.fmtLen(r.perimeter)]);
  if (r.type === 'door' || r.type === 'window') rows.push(['Opening area', `${((r.width * r.height) / 1e6).toFixed(2)} m²`]);
  if (!rows.length) return null;
  return <><h4>Derived</h4><dl className="kv">{rows.map(([k, v]) => [<dt key={k}>{k}</dt>, <dd key={k + 'v'}>{v}</dd>])}</dl></>;
}

function ParamRow({ name, expr, description }: { name: string; expr: string; description?: string }) {
  const [text, setText] = useState(expr), [err, setErr] = useState<string | null>(null);
  const v = session.model.engine.value(name), e = session.model.engine.error(name);
  const commit = () => { if (text.trim() === expr) { setErr(null); return; } const r = session.setParameter(name, text.trim()); if (!r.ok) { setErr(r.error ?? 'Rejected'); } else setErr(null); };
  return (
    <li className={err || e ? 'prow bad' : 'prow'}>
      <div className="pline"><code title={description}>{name}</code>
        <input value={text} spellCheck={false} aria-label={`Formula for ${name}`} onChange={(x) => { setText(x.target.value); setErr(null); }} onBlur={commit} onKeyDown={(x) => { if (x.key === 'Enter') (x.target as HTMLInputElement).blur(); if (x.key === 'Escape') { setText(expr); setErr(null); } }} />
        <button className="icon" title="Delete parameter" onClick={() => A.run(`Remove ${name}`, (p) => removeParameter(p, name))}><Icon n="trash" size={14} /></button></div>
      <div className="pval">{e ? <span className="err">{e}</span> : <span>= {typeof v === 'number' ? Math.round(v * 1000) / 1000 : String(v)}</span>}</div>
      {err && <div className="perr" role="alert"><Icon n="warn" size={13} /> {err} <em>Last valid value kept.</em></div>}
    </li>
  );
}
function Parameters() {
  const s = useSession();
  return (
    <div className="params">
      <div className="bar"><button className="btn" onClick={A.addParameterDialog}><Icon n="plus" size={14} /> Parameter</button><button className="btn" onClick={A.addConstraintDialog}><Icon n="plus" size={14} /> Constraint</button></div>
      <ul className="plist">{s.project.parameters.map((p) => <ParamRow key={p.name + '|' + p.expr} {...p} />)}</ul>
      <h4>Constraints</h4>
      {s.project.constraints.length === 0 && <p className="muted">None. A constraint is a true/false formula that must always hold, e.g. <code>building_width &lt;= 20000</code>.</p>}
      <ul className="clist">{s.project.constraints.map((c) => { const v = s.model.engine.value(`constraint:${c.id}`); return <li key={c.id} className={v === true ? 'ok' : 'bad'}><Icon n={v === true ? 'ok' : 'warn'} size={14} /><div><strong>{c.name}</strong><code>{c.expr}</code></div><button className="icon" title="Remove constraint" onClick={() => A.run('Remove constraint', (p) => removeConstraint(p, c.id))}><Icon n="trash" size={14} /></button></li>; })}</ul>
      <h4>Parameter history</h4>
      {s.project.parameterHistory.length === 0 ? <p className="muted">No parameter edits yet.</p> : <ul className="hist">{[...s.project.parameterHistory].reverse().slice(0, 12).map((h, i) => <li key={i}><code>{h.name}</code> {h.from} → <b>{h.to}</b><time>{new Date(h.time).toLocaleTimeString()}</time></li>)}</ul>}
    </div>
  );
}
function DataTab() {
  const s = useSession(), m = s.model, area = (a: number) => `${(a / 1e6).toFixed(2)} m²`;
  const walls = m.byType('wall'), rooms = m.byType('room'), ops = [...m.byType('door'), ...m.byType('window')];
  let vol = 0, len = 0; for (const w of walls) { vol += wallBoxes(w, m.openingsOf(w.id)).reduce((a, b) => a + boxVolume(b, w.thickness), 0); len += w.length; }
  const slabArea = m.byType('slab').reduce((a, x) => a + Math.abs(x.points.reduce((t, p, i, arr) => t + (p.x * arr[(i + 1) % arr.length].y - arr[(i + 1) % arr.length].x * p.y), 0)) / 2, 0);
  return (
    <div className="data">
      <h4>Project statistics</h4>
      <dl className="kv"><dt>Walls</dt><dd>{walls.length} · {A.fmtLen(len)}</dd><dt>Wall volume (net)</dt><dd>{(vol / 1e9).toFixed(2)} m³</dd><dt>Doors / windows</dt><dd>{m.byType('door').length} / {m.byType('window').length}</dd><dt>Rooms</dt><dd>{rooms.length} · {area(rooms.reduce((a, r) => a + r.netArea, 0))}</dd><dt>Slab area</dt><dd>{area(slabArea)}</dd><dt>Levels</dt><dd>{s.project.levels.length}</dd></dl>
      <h4>Room schedule <button className="btn small" onClick={A.exportSchedule} disabled={!rooms.length}>CSV</button></h4>
      {rooms.length === 0 ? <p className="muted">No rooms yet. Use the Room tool.</p> : <table className="tbl"><thead><tr><th>Room</th><th>Level</th><th>Net</th><th>Gross</th></tr></thead><tbody>{rooms.map((r) => <tr key={r.id} onClick={() => A.select([r.id])}><td>{r.name}</td><td>{m.levels.get(r.level)?.name}</td><td>{area(r.netArea)}</td><td>{area(r.grossArea)}</td></tr>)}<tr className="total"><td colSpan={2}>Total</td><td>{area(rooms.reduce((a, r) => a + r.netArea, 0))}</td><td>{area(rooms.reduce((a, r) => a + r.grossArea, 0))}</td></tr></tbody></table>}
      <h4>Door &amp; window schedule</h4>
      {ops.length === 0 ? <p className="muted">No openings yet.</p> : <table className="tbl"><thead><tr><th>Id</th><th>Type</th><th>Host</th><th>W × H</th></tr></thead><tbody>{ops.map((o) => <tr key={o.id} onClick={() => A.select([o.id])}><td>{o.id}</td><td>{o.type}</td><td>{o.host}</td><td>{Math.round(o.width)} × {Math.round(o.height)}</td></tr>)}</tbody></table>}
    </div>
  );
}
export function RightPanel() {
  const tab = useUI((s) => s.rightTab); useUI((s) => s.lang);
  const tabs: ['properties' | 'parameters' | 'data', string][] = [['properties', 'Properties'], ['parameters', 'Parameters'], ['data', 'Data']];
  return (
    <div className="panel-body right">
      <div className="tabs" role="tablist">{tabs.map(([id, l]) => <button key={id} role="tab" aria-selected={tab === id} className={tab === id ? 'on' : ''} onClick={() => useUI.setState({ rightTab: id })}>{l}</button>)}</div>
      <div className="tabbody" role="tabpanel">{tab === 'properties' ? <Properties /> : tab === 'parameters' ? <Parameters /> : <DataTab />}</div>
    </div>
  );
}
