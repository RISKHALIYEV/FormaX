import { useSyncExternalStore } from 'react';
import { Session } from '@formax/core';
export const session = new Session();
/** Re-renders the calling component whenever the document changes. */
export function useSession(): Session { useSyncExternalStore(session.subscribe, session.getVersion); return session; }
