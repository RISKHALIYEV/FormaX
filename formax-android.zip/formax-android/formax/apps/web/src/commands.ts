import { session } from './session';
import { useUI } from './store';
import * as A from './actions';

export interface Command { id: string; label: string; shortcut?: string; run: () => void; enabled?: () => boolean; keywords?: string }
const U = () => useUI.getState();
export const commands: Command[] = [
  { id: 'file.new', label: 'New project…', shortcut: 'Ctrl+N', run: A.newProject },
  { id: 'file.open', label: 'Open file…', shortcut: 'Ctrl+O', run: A.openFilePicker },
  { id: 'file.browser', label: 'Projects in this browser…', run: () => U().set({ dialog: { kind: 'projects' } }) },
  { id: 'file.example', label: 'Load example project', run: A.loadExample },
  { id: 'file.save', label: 'Save in this browser', shortcut: 'Ctrl+S', run: () => void A.saveBrowser() },
  { id: 'file.download', label: 'Download .formax file', shortcut: 'Ctrl+Shift+S', run: A.downloadFormax },
  { id: 'edit.undo', label: 'Undo', shortcut: 'Ctrl+Z', run: A.undo, enabled: () => session.canUndo },
  { id: 'edit.redo', label: 'Redo', shortcut: 'Ctrl+Y', run: A.redo, enabled: () => session.canRedo },
  { id: 'edit.all', label: 'Select all', shortcut: 'Ctrl+A', run: A.selectAll },
  { id: 'edit.none', label: 'Deselect', shortcut: 'Esc', run: () => A.select([]) },
  { id: 'edit.duplicate', label: 'Duplicate', shortcut: 'Ctrl+D', run: A.duplicateSelection, enabled: () => A.selected().length > 0 },
  { id: 'edit.rotate', label: 'Rotate…', run: A.rotateSelection, enabled: () => A.selected().length > 0 },
  { id: 'edit.scale', label: 'Scale…', run: A.scaleSelection, enabled: () => A.selected().length > 0 },
  { id: 'edit.delete', label: 'Delete', shortcut: 'Del', run: A.deleteSelection, enabled: () => A.selected().length > 0 },
  { id: 'view.plan', label: 'Plan view', shortcut: 'F2', run: () => U().set({ view: 'plan' }) },
  { id: 'view.3d', label: '3D view', shortcut: 'F3', run: () => U().set({ view: '3d' }) },
  { id: 'view.fit', label: 'Zoom to fit', shortcut: 'Z', run: () => U().set({ frame: U().frame + 1 }) },
  { id: 'view.up', label: 'Next level', shortcut: 'PgUp', run: () => A.levelStep(1) },
  { id: 'view.down', label: 'Previous level', shortcut: 'PgDn', run: () => A.levelStep(-1) },
  { id: 'view.theme', label: 'Toggle light / dark theme', run: () => U().setPrefs({ theme: U().theme === 'dark' ? 'light' : 'dark' }) },
  { id: 'model.persp', label: 'Perspective camera', run: () => U().set({ view: '3d', camera3d: 'perspective' }) },
  { id: 'model.ortho', label: 'Orthographic camera', run: () => U().set({ view: '3d', camera3d: 'orthographic' }) },
  { id: 'arch.footprint', label: 'Building footprint by size…', run: A.footprintDialog },
  { id: 'arch.level', label: 'Add level', run: () => A.addLevelAction(false) },
  { id: 'arch.levelcopy', label: 'Add level (copy of current)', run: () => A.addLevelAction(true) },
  { id: 'arch.roof', label: 'Add flat roof to current level', run: A.roofAction },
  { id: 'param.add', label: 'Add parameter…', run: A.addParameterDialog },
  { id: 'param.constraint', label: 'Add constraint…', run: A.addConstraintDialog },
  { id: 'param.panel', label: 'Show parameters', run: () => U().set({ rightTab: 'parameters', panel: window.innerWidth <= 900 ? 'right' : null }) },
  { id: 'param.issues', label: 'Validation issues…', run: () => U().set({ dialog: { kind: 'issues' } }) },
  { id: 'draw.settings', label: 'Drawing settings…', run: A.drawingSettings },
  { id: 'draw.plan', label: 'Preview floor plan', run: () => A.previewDrawing('plan') },
  { id: 'draw.elev', label: 'Preview elevation', run: () => A.previewDrawing('elev') },
  { id: 'export.plan.svg', label: 'Floor plan (SVG)', run: () => A.exportDrawing('plan', 'svg') },
  { id: 'export.plan.pdf', label: 'Floor plan (PDF)', run: () => A.exportDrawing('plan', 'pdf') },
  { id: 'export.elev.svg', label: 'Elevation (SVG)', run: () => A.exportDrawing('elev', 'svg') },
  { id: 'export.elev.pdf', label: 'Elevation (PDF)', run: () => A.exportDrawing('elev', 'pdf') },
  { id: 'export.csv', label: 'Room schedule (CSV)', run: A.exportSchedule },
  { id: 'set.lang.en', label: 'Language: English', run: () => U().setPrefs({ lang: 'en' }) },
  { id: 'set.lang.uz', label: 'Language: Oʻzbekcha', run: () => U().setPrefs({ lang: 'uz' }) },
  { id: 'set.ortho', label: 'Toggle orthogonal drawing', run: () => U().setPrefs({ snaps: { ...U().snaps, ortho: !U().snaps.ortho } }) },
  { id: 'help', label: 'Keyboard shortcuts', shortcut: 'F1', run: () => U().set({ dialog: { kind: 'help' } }) },
];
export const byId = (id: string) => commands.find((c) => c.id === id)!;
export const MENUS: Record<string, (string | '-')[]> = {
  File: ['file.new', 'file.open', 'file.browser', 'file.example', '-', 'file.save', 'file.download'],
  Edit: ['edit.undo', 'edit.redo', '-', 'edit.all', 'edit.none', '-', 'edit.duplicate', 'edit.rotate', 'edit.scale', 'edit.delete'],
  View: ['view.plan', 'view.3d', 'view.fit', '-', 'view.up', 'view.down', '-', 'view.theme'],
  Model: ['model.persp', 'model.ortho', 'view.3d'],
  Architecture: ['arch.footprint', '-', 'arch.level', 'arch.levelcopy', 'arch.roof'],
  Parametric: ['param.add', 'param.constraint', '-', 'param.panel', 'param.issues'],
  Drawing: ['draw.settings', '-', 'draw.plan', 'draw.elev'],
  Export: ['export.plan.svg', 'export.plan.pdf', 'export.elev.svg', 'export.elev.pdf', '-', 'export.csv', 'file.download'],
  Settings: ['set.lang.en', 'set.lang.uz', '-', 'view.theme', 'set.ortho', '-', 'help'],
};
export const TOOLS: { id: import('./store').Tool; key: string; label: string; icon: string }[] = [
  { id: 'select', key: 'V', label: 'Select', icon: 'select' }, { id: 'footprint', key: 'B', label: 'Building footprint', icon: 'footprint' }, { id: 'wall', key: 'W', label: 'Interior wall', icon: 'wall' },
  { id: 'room', key: 'R', label: 'Room', icon: 'room' }, { id: 'door', key: 'D', label: 'Door', icon: 'door' }, { id: 'window', key: 'N', label: 'Window', icon: 'window' }, { id: 'column', key: 'K', label: 'Column', icon: 'column' },
  { id: 'line', key: 'L', label: 'Line', icon: 'line' }, { id: 'polyline', key: 'P', label: 'Polyline', icon: 'polyline' }, { id: 'circle', key: 'C', label: 'Circle', icon: 'circle' }, { id: 'dimension', key: 'M', label: 'Dimension', icon: 'dimension' },
];
export const TOOL_HELP: Record<string, string> = {
  select: 'Click to select · drag to move · drag empty space to box-select (right→left = crossing) · Shift adds',
  footprint: 'Drag a rectangle: creates 4 parametric walls, a slab and building_width / building_length parameters',
  wall: 'Click start, click end (chains) · snaps to endpoints, midpoints, intersections · Shift = orthogonal · Esc ends',
  room: 'Click boundary points · click the first point or press Enter to close · snap to wall midpoints to stay parametric',
  door: 'Click on a wall to place a door', window: 'Click on a wall to place a window', column: 'Click to place a 400 × 400 mm column',
  line: 'Click start, click end', polyline: 'Click points · Enter or double-click to finish', circle: 'Click centre, click a point on the circle', dimension: 'Click two points to add a dimension',
};
