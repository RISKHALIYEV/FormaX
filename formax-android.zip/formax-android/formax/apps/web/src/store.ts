import { create } from 'zustand';
import type { Lang } from '@formax/localization';
import type { PaperSize, ElevationSide } from '@formax/drawing';

export type Tool = 'select' | 'footprint' | 'wall' | 'room' | 'door' | 'window' | 'line' | 'polyline' | 'circle' | 'dimension' | 'column';
export type Dialog =
  | { kind: 'form'; art?: 'create-project'; title: string; submit: string; fields: { key: string; label: string; type: 'text' | 'number' | 'select'; value: string; options?: string[]; hint?: string }[]; onSubmit: (v: Record<string, string>) => string | void }
  | { kind: 'confirm'; title: string; message: string; confirm: string; danger?: boolean; onConfirm: () => void }
  | { kind: 'projects' } | { kind: 'issues' } | { kind: 'preview'; title: string; svg: string } | { kind: 'recover'; time: string; text: string } | { kind: 'help' } | { kind: 'welcome' };
export interface Prefs { theme: 'light' | 'dark'; lang: Lang; grid: number; snaps: { endpoints: boolean; midpoints: boolean; intersections: boolean; edges: boolean; grid: boolean; ortho: boolean }; drawing: { paper: PaperSize; scale: 'auto' | number; side: ElevationSide } }
const DEFAULT_PREFS: Prefs = { theme: 'dark', lang: 'en', grid: 100, snaps: { endpoints: true, midpoints: true, intersections: true, edges: true, grid: true, ortho: false }, drawing: { paper: 'A3', scale: 'auto', side: 'south' } };
const loadPrefs = (): Prefs => { try { const p = JSON.parse(localStorage.getItem('formax.prefs') ?? '{}'); return { ...DEFAULT_PREFS, ...p, snaps: { ...DEFAULT_PREFS.snaps, ...p.snaps }, drawing: { ...DEFAULT_PREFS.drawing, ...p.drawing } }; } catch { return DEFAULT_PREFS; } };

interface UIState extends Prefs {
  tool: Tool; view: 'plan' | '3d'; level: string; selection: string[]; camera3d: 'perspective' | 'orthographic';
  toast: { id: number; msg: string; kind: 'info' | 'error' | 'ok' } | null; dialog: Dialog | null; menu: string | null; palette: boolean;
  cursor: { x: number; y: number; kind: string }; context: { x: number; y: number } | null; projectKey: string | null; panel: 'left' | 'right' | null; rightTab: 'properties' | 'parameters' | 'data';
  cancel: number; finish: number; frame: number; saveState: 'idle' | 'saving' | 'error'; lastSaved: string | null;
  set: (p: Partial<UIState>) => void; setPrefs: (p: Partial<Prefs>) => void;
}
export const useUI = create<UIState>((set, get) => ({
  ...loadPrefs(), tool: 'select', view: 'plan', level: 'L1', selection: [], camera3d: 'perspective', toast: null, dialog: null, menu: null, palette: false,
  cursor: { x: 0, y: 0, kind: '' }, context: null, projectKey: null, panel: null, rightTab: 'properties', cancel: 0, finish: 0, frame: 0, saveState: 'idle', lastSaved: null,
  set: (p) => set(p),
  setPrefs: (p) => { set(p); const s = get(); try { localStorage.setItem('formax.prefs', JSON.stringify({ theme: s.theme, lang: s.lang, grid: s.grid, snaps: s.snaps, drawing: s.drawing })); } catch { /* storage unavailable */ } },
}));
