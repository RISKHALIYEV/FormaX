const P: Record<string, string> = {
  select: 'M5 3l12 8-5 1.5L9.5 18 5 3z', footprint: 'M4 6h16v12H4zM4 6l3-3h13', wall: 'M3 17L17 3M6 20L20 6', room: 'M4 5h16v14H4zM4 12h8v7', door: 'M5 20V4h9v16M14 4l5 2v12l-5 2M11 12h.01', window: 'M4 5h16v14H4zM12 5v14M4 12h16',
  line: 'M4 20L20 4', polyline: 'M3 18l5-9 5 6 4-9 4 5', circle: 'M12 4a8 8 0 100 16 8 8 0 000-16z', dimension: 'M4 18V8M20 18V8M4 13h16M7 10l-3 3 3 3M17 10l3 3-3 3', column: 'M7 4h10M9 4v16M15 4v16M7 20h10',
  undo: 'M9 14L4 9l5-5M4 9h10a6 6 0 010 12h-3', redo: 'M15 14l5-5-5-5M20 9H10a6 6 0 000 12h3', plan: 'M3 3h18v18H3zM3 11h9v10M12 11V3', cube: 'M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3zM12 12l8-4.5M12 12v9M12 12L4 7.5',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 100 6 3 3 0 000-6z', eyeoff: 'M3 3l18 18M10.5 5.2A9.6 9.6 0 0112 5c6 0 10 7 10 7a17 17 0 01-3.2 3.9M6.5 6.8A17 17 0 002 12s4 7 10 7a9.5 9.5 0 004-.9', lock: 'M6 11h12v9H6zM8 11V8a4 4 0 018 0v3', unlock: 'M6 11h12v9H6zM8 11V8a4 4 0 017.5-2',
  warn: 'M12 3l10 18H2L12 3zM12 10v5M12 18h.01', ok: 'M4 12l5 5L20 6', x: 'M5 5l14 14M19 5L5 19', plus: 'M12 5v14M5 12h14', trash: 'M5 7h14M9 7V4h6v3M7 7l1 13h8l1-13', menu: 'M4 6h16M4 12h16M4 18h16', sliders: 'M4 7h10M18 7h2M4 17h2M10 17h10M14 5v4M6 15v4', layers: 'M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5', fit: 'M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5', cmd: 'M9 6a3 3 0 10-3 3h12a3 3 0 10-3-3v12a3 3 0 103-3H6a3 3 0 103 3V6z',
};
export const Icon = ({ n, size = 18 }: { n: string; size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={P[n] ?? P.x} /></svg>
);
