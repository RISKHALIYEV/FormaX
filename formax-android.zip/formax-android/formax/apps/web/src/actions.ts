import { v2, formatLength, projectOnSegment, dist } from '@formax/geometry';
import { addBuildingFootprint, addLevel, copyLevelContent, addRoofFromSlab, deleteObjects, duplicateObjects, rotateObjects, scaleObjects, centerOf, addParameter, addConstraint, defaultProject, translate, type ArchModel, type Project, type TxResult } from '@formax/core';
import { serializeProject, parseProjectFile } from '@formax/project-format';
import { buildPlan, buildElevation, layoutSheet, toSVG, toPDF, type Sheet } from '@formax/drawing';
import { t, type Key } from '@formax/localization';
import { session } from './session';
import { useUI, type Tool } from './store';
import { putProject, putAutosave, clearAutosave, listProjects } from './storage';
import exampleText from '../../../examples/sample.formax?raw';
import { isAndroid, nativeSave } from './native';

export const ui = () => useUI.getState();
export const tr = (k: Key) => t(ui().lang, k);
export function toast(msg: string, kind: 'info' | 'error' | 'ok' = 'info') { useUI.setState({ toast: { id: Date.now() + Math.random(), msg, kind } }); }
export const selected = (): string[] => ui().selection.filter((id) => session.model.get(id));
export const select = (ids: string[]) => useUI.setState({ selection: ids });
export const activeLevel = (): string => { const l = ui().level; return session.project.levels.some((x) => x.id === l) ? l : session.project.levels[0].id; };
export function run<T>(label: string, fn: (p: Project, m: ArchModel) => T): TxResult<T> { const r = session.commit(label, fn); if (!r.ok) toast(r.error ?? 'Change rejected', 'error'); return r; }
export const fmtLen = (mm: number) => formatLength(mm, session.project.units);

/** Saves a file: system "Save as" dialog inside the Android app, a normal browser download elsewhere. Resolves true on success. */
async function download(name: string, data: BlobPart, mime: string): Promise<boolean> {
  if (isAndroid()) return nativeSave(name, mime, data);
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([data], { type: mime })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  return true;
}
const safe = (s: string) => s.replace(/[^\w\-]+/g, '_').replace(/^_+|_+$/g, '') || 'project';

// ---------- project lifecycle ----------
function afterLoad(name?: string) { useUI.setState({ selection: [], level: session.project.levels[0].id, view: 'plan', tool: 'select', frame: ui().frame + 1, projectKey: name ?? null }); }
export function guardDirty(next: () => void) {
  if (!session.dirty) return next();
  useUI.setState({ dialog: { kind: 'confirm', title: 'Discard unsaved changes?', message: 'The current project has unsaved changes that will be lost.', confirm: 'Discard changes', danger: true, onConfirm: next } });
}
export function newProject() {
  guardDirty(() => {
    useUI.setState({ dialog: { kind: 'form', art: 'create-project', title: 'New project', submit: 'Create', fields: [{ key: 'name', label: 'Project name', type: 'text', value: 'New building' }, { key: 'units', label: 'Display units', type: 'select', value: 'm', options: ['mm', 'cm', 'm'] }],
      onSubmit: (v) => { if (!v.name.trim()) return 'Enter a project name.'; const p = defaultProject(v.name.trim()); p.units = v.units as Project['units']; session.load(p); afterLoad(); } } });
  });
}
export function openText(text: string, source: string, recovery = false) {
  const r = parseProjectFile(text, { ignoreIntegrity: recovery });
  if (!r.ok) {
    if (!recovery && r.errors[0]?.startsWith('Integrity')) { useUI.setState({ dialog: { kind: 'confirm', title: 'File integrity check failed', message: `${r.errors[0]} You can try to open it in recovery mode; review the result carefully.`, confirm: 'Open in recovery mode', danger: true, onConfirm: () => openText(text, source, true) } }); return; }
    useUI.setState({ dialog: { kind: 'confirm', title: `Cannot open ${source}`, message: r.errors.slice(0, 6).join('\n'), confirm: 'OK', onConfirm: () => {} } }); return;
  }
  session.load(r.project); afterLoad();
  toast(r.warnings.length ? r.warnings[0] : `Opened ${source}`, r.warnings.length ? 'info' : 'ok');
  if (session.model.issues.some((i) => i.severity === 'error')) toast(`Opened with ${session.model.issues.filter((i) => i.severity === 'error').length} validation error(s) – see Issues.`, 'error');
}
export function openFilePicker() {
  guardDirty(() => {
    const inp = document.createElement('input'); inp.type = 'file'; inp.accept = '.formax,.json,application/json';
    inp.onchange = async () => { const f = inp.files?.[0]; if (!f) return; try { openText(await f.text(), f.name); } catch (e) { toast(`Could not read file: ${(e as Error).message}`, 'error'); } };
    inp.click();
  });
}
export function loadExample() { guardDirty(() => openText(exampleText, 'example project')); }
export async function saveBrowser() {
  const key = ui().projectKey ?? session.project.id;
  try {
    const text = serializeProject(session.project); await putProject({ id: key, name: session.project.name, modified: new Date().toISOString(), text });
    await clearAutosave().catch(() => {}); useUI.setState({ projectKey: key, lastSaved: new Date().toISOString() }); session.markSaved(); toast(`Saved “${session.project.name}” in this browser`, 'ok');
  } catch (e) { toast(`Save failed: ${(e as Error).message}. Use “Download .formax” instead.`, 'error'); }
}
export function downloadFormax() { void download(`${safe(session.project.name)}.formax`, serializeProject(session.project), 'application/json').then((ok) => { if (ok) { session.markSaved(); toast('Project file saved', 'ok'); } else toast('Save cancelled', 'info'); }); }
export async function autosave() {
  if (!session.dirty) return;
  try { await putAutosave({ id: 'current', text: serializeProject(session.project), time: new Date().toISOString(), unsaved: true, name: session.project.name }); } catch { /* best effort */ }
}
export const projectsList = listProjects;

// ---------- editing ----------
export function undo() { if (!session.undo()) toast('Nothing to undo'); else select(selected()); }
export function redo() { if (!session.redo()) toast('Nothing to redo'); else select(selected()); }
export function deleteSelection() {
  const ids = selected(); if (!ids.length) return;
  const go = () => { run(`Delete ${ids.length} object(s)`, (p) => deleteObjects(p, ids)); select([]); };
  if (ids.length > 1) useUI.setState({ dialog: { kind: 'confirm', title: `Delete ${ids.length} objects?`, message: 'Hosted doors and windows are deleted with their walls. You can undo this.', confirm: 'Delete', danger: true, onConfirm: go } }); else go();
}
export function duplicateSelection() { const ids = selected(); if (!ids.length) return; const r = run('Duplicate', (p) => duplicateObjects(p, ids, 1000, 1000)); if (r.ok) select(r.value!); }
export function selectAll() { select(session.project.objects.filter((o) => o.level === activeLevel() && session.project.layers.find((l) => l.id === o.layer)?.visible !== false).map((o) => o.id)); }
export function rotateSelection() {
  const ids = selected(); if (!ids.length) return toast('Select objects to rotate');
  useUI.setState({ dialog: { kind: 'form', title: 'Rotate selection', submit: 'Rotate', fields: [{ key: 'deg', label: 'Angle (degrees, counter-clockwise)', type: 'number', value: '90', hint: 'Rotated points become numeric coordinates (formula bindings of those points are baked).' }],
    onSubmit: (v) => { const d = Number(v.deg); if (!Number.isFinite(d)) return 'Enter a number.'; const r = run('Rotate', (p, m) => rotateObjects(p, m, ids, (d * Math.PI) / 180, centerOf(m, ids))); if (!r.ok) return r.error; } } });
}
export function scaleSelection() {
  const ids = selected(); if (!ids.length) return toast('Select objects to scale');
  useUI.setState({ dialog: { kind: 'form', title: 'Scale selection', submit: 'Scale', fields: [{ key: 'k', label: 'Scale factor', type: 'number', value: '1.5', hint: 'Positions scale about the selection centre; wall thickness is not scaled. Moved points become numeric.' }],
    onSubmit: (v) => { const k = Number(v.k); if (!(k > 0)) return 'Scale factor must be greater than 0.'; const r = run('Scale', (p, m) => scaleObjects(p, m, ids, k, centerOf(m, ids))); if (!r.ok) return r.error; } } });
}
export function nudge(dx: number, dy: number) { const ids = selected(); if (ids.length) run('Move', (p) => translate(p, ids, dx, dy)); }
export function footprintDialog() {
  useUI.setState({ dialog: { kind: 'form', title: 'Building footprint', submit: 'Create', fields: [{ key: 'w', label: 'Width (mm)', type: 'number', value: '15000' }, { key: 'l', label: 'Length (mm)', type: 'number', value: '12000' }],
    onSubmit: (v) => { const w = Number(v.w), l = Number(v.l); if (!(w > 0 && l > 0)) return 'Width and length must be positive.'; const r = run('Building footprint', (p) => addBuildingFootprint(p, { x: 0, y: 0, width: w, length: l, level: activeLevel() })); if (!r.ok) return r.error; useUI.setState({ frame: ui().frame + 1 }); } } });
}
export function addLevelAction(copy: boolean) {
  const r = run('Add level', (p) => { const from = activeLevel(), id = addLevel(p); if (copy) copyLevelContent(p, from, id); return id; });
  if (r.ok) useUI.setState({ level: r.value! });
}
export function roofAction() { const lv = activeLevel(); run('Add flat roof', (p) => addRoofFromSlab(p, lv)); }
export function addParameterDialog() {
  useUI.setState({ dialog: { kind: 'form', title: 'New parameter', submit: 'Add', fields: [{ key: 'name', label: 'Name', type: 'text', value: '' }, { key: 'expr', label: 'Value or formula', type: 'text', value: '1000', hint: 'Examples: 15000, building_width / 2, if(floor_height > 3000, 1, 0)' }],
    onSubmit: (v) => { const r = run(`Add parameter ${v.name}`, (p) => addParameter(p, v.name.trim(), v.expr.trim())); if (!r.ok) return r.error; useUI.setState({ rightTab: 'parameters' }); } } });
}
export function addConstraintDialog() {
  useUI.setState({ dialog: { kind: 'form', title: 'New constraint', submit: 'Add', fields: [{ key: 'name', label: 'Name', type: 'text', value: 'Maximum width' }, { key: 'expr', label: 'Condition (true/false formula)', type: 'text', value: 'building_width <= 20000' }, { key: 'msg', label: 'Message when violated', type: 'text', value: 'The building must fit the plot.' }],
    onSubmit: (v) => { const r = run('Add constraint', (p) => addConstraint(p, v.name.trim() || 'Constraint', v.expr.trim(), v.msg.trim() || 'Constraint violated')); if (!r.ok) return r.error; } } });
}
export function levelStep(d: number) { const ls = session.project.levels, i = ls.findIndex((l) => l.id === activeLevel()); const n = ls[Math.max(0, Math.min(ls.length - 1, i + d))]; useUI.setState({ level: n.id, selection: [] }); }
export function setTool(tool: Tool) { useUI.setState({ tool, view: 'plan', cancel: ui().cancel + 1 }); }

// ---------- drawing / data export ----------
function sheetFor(kind: 'plan' | 'elev'): Sheet { const m = session.model; return kind === 'plan' ? buildPlan(m, activeLevel()) : buildElevation(m, ui().drawing.side); }
export function makeDrawing(kind: 'plan' | 'elev') {
  const sheet = sheetFor(kind); if (!sheet.prims.length) { toast('Nothing to draw yet – the model has no walls on this level.', 'error'); return null; }
  const d = ui().drawing; let lay = layoutSheet(sheet, { paper: d.paper, scale: d.scale, projectName: session.project.name });
  if (!lay.fits) { lay = layoutSheet(sheet, { paper: d.paper, scale: 'auto', projectName: session.project.name }); toast(`The drawing does not fit at 1:${d.scale} on ${d.paper}; used 1:${lay.scale}.`); }
  return { lay, name: `${safe(session.project.name)}_${kind === 'plan' ? 'plan_' + activeLevel() : 'elevation_' + d.side}` };
}
export function exportDrawing(kind: 'plan' | 'elev', fmt: 'svg' | 'pdf') {
  const r = makeDrawing(kind); if (!r) return;
  const p = fmt === 'svg' ? download(`${r.name}.svg`, toSVG(r.lay), 'image/svg+xml') : download(`${r.name}.pdf`, toPDF(r.lay) as unknown as BlobPart, 'application/pdf');
  void p.then((ok) => toast(ok ? `Exported ${r.name}.${fmt}` : 'Export cancelled', ok ? 'ok' : 'info'));
}
export function previewDrawing(kind: 'plan' | 'elev') { const r = makeDrawing(kind); if (r) useUI.setState({ dialog: { kind: 'preview', title: `${kind === 'plan' ? 'Floor plan' : 'Elevation'} – 1:${r.lay.scale} ${ui().drawing.paper}`, svg: toSVG(r.lay) } }); }
export function drawingSettings() {
  const d = ui().drawing;
  useUI.setState({ dialog: { kind: 'form', title: 'Drawing settings', submit: 'Apply', fields: [{ key: 'paper', label: 'Paper', type: 'select', value: d.paper, options: ['A4', 'A3', 'A2', 'A1'] }, { key: 'scale', label: 'Scale (1:n)', type: 'select', value: String(d.scale), options: ['auto', '20', '50', '100', '200', '500'] }, { key: 'side', label: 'Elevation side', type: 'select', value: d.side, options: ['south', 'north', 'east', 'west'] }],
    onSubmit: (v) => { ui().setPrefs({ drawing: { paper: v.paper as never, scale: v.scale === 'auto' ? 'auto' : Number(v.scale), side: v.side as never } }); } } });
}
export function roomScheduleCSV(m: ArchModel = session.model): string {
  const rows = [['Id', 'Name', 'Level', 'Net area (m2)', 'Gross area (m2)', 'Perimeter (mm)']];
  for (const r of m.byType('room')) rows.push([r.id, r.name, m.levels.get(r.level)?.name ?? r.level, (r.netArea / 1e6).toFixed(3), (r.grossArea / 1e6).toFixed(3), r.perimeter.toFixed(0)]);
  return rows.map((r) => r.map((c) => (/[",\n]/.test(c) ? `"${c.replace(/"/g, '""')}"` : c)).join(',')).join('\n');
}
export function exportSchedule() { void download(`${safe(session.project.name)}_rooms.csv`, roomScheduleCSV(), 'text/csv').then((ok) => toast(ok ? 'Room schedule exported' : 'Export cancelled', ok ? 'ok' : 'info')); }

// ---------- opening placement helper (plan tool) ----------
export function wallAt(m: ArchModel, level: string, p: { x: number; y: number }, tol: number) {
  let best: { id: string; offset: number; length: number; d: number } | null = null;
  for (const w of m.byType('wall', level)) { const pr = projectOnSegment(v2(p.x, p.y), w.a, w.b); if (pr.distance <= w.thickness / 2 + tol && (!best || pr.distance < best.d)) best = { id: w.id, offset: pr.t * dist(w.a, w.b), length: dist(w.a, w.b), d: pr.distance }; }
  return best;
}
export { t };
