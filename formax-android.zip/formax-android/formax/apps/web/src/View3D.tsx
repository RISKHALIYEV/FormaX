import { useEffect, useRef, useState } from 'react';
import { Viewport3D } from '@formax/rendering';
import { session, useSession } from './session';
import { useUI } from './store';
import { select } from './actions';
import { Icon } from './icons';

export function View3D() {
  const host = useRef<HTMLDivElement>(null), vp = useRef<Viewport3D | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useSession();
  const selection = useUI((s) => s.selection), theme = useUI((s) => s.theme), cam = useUI((s) => s.camera3d), frame = useUI((s) => s.frame);
  useEffect(() => {
    try { const v = new Viewport3D(host.current!, useUI.getState().theme === 'dark'); vp.current = v; v.onPick = (id, add) => { const cur = useUI.getState().selection; select(id ? (add ? (cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id]) : [id]) : add ? cur : []); }; v.setCameraMode(useUI.getState().camera3d); sync(); v.frame(); }
    catch (e) { setErr(`3D view is unavailable: ${(e as Error).message || 'WebGL could not be initialised'}. Check that hardware acceleration is enabled. The 2D plan keeps working.`); }
    return () => { vp.current?.dispose(); vp.current = null; };
  }, []);
  function sync() {
    const v = vp.current; if (!v) return; const p = session.project;
    v.update(session.model, { visibleLayers: new Set(p.layers.filter((l) => l.visible).map((l) => l.id)), colors: new Map(p.materials.map((m) => [m.id, m.color])), selection: new Set(useUI.getState().selection) });
  }
  useEffect(sync, [session.version, selection]);
  useEffect(() => vp.current?.setDark(theme === 'dark'), [theme]);
  useEffect(() => vp.current?.setCameraMode(cam), [cam]);
  useEffect(() => { vp.current?.frame(); }, [frame]);
  if (err) return <div className="state-error" role="alert"><Icon n="warn" size={28} /><p>{err}</p></div>;
  return (
    <div className="view3d" ref={host}>
      <div className="vp-controls" role="toolbar" aria-label="3D view controls">
        <button className={cam === 'perspective' ? 'on' : ''} onClick={() => useUI.setState({ camera3d: 'perspective' })} title="Perspective camera">Perspective</button>
        <button className={cam === 'orthographic' ? 'on' : ''} onClick={() => useUI.setState({ camera3d: 'orthographic' })} title="Orthographic camera">Orthographic</button>
        <button onClick={() => vp.current?.frame('iso')} title="Frame the whole model"><Icon n="fit" size={15} /> Frame all</button>
        <button onClick={() => vp.current?.frame('top')} title="Top view">Top</button>
      </div>
      <div className="vp-hint">Left drag: orbit · Right drag: pan · Wheel / pinch: zoom · Click: select</div>
    </div>
  );
}
