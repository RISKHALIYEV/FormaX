/** Local-first storage in IndexedDB. Everything stays on the device. */
export interface StoredProject { id: string; name: string; modified: string; text: string }
const DB = 'formax', VERSION = 1;
function open(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    if (typeof indexedDB === 'undefined') return rej(new Error('IndexedDB is not available in this browser context.'));
    const r = indexedDB.open(DB, VERSION);
    r.onupgradeneeded = () => { const d = r.result; if (!d.objectStoreNames.contains('projects')) d.createObjectStore('projects', { keyPath: 'id' }); if (!d.objectStoreNames.contains('autosave')) d.createObjectStore('autosave', { keyPath: 'id' }); };
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error ?? new Error('Cannot open database'));
  });
}
async function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise<T>((res, rej) => { const t = db.transaction(store, mode), rq = fn(t.objectStore(store)); t.oncomplete = () => { db.close(); res(rq.result); }; t.onerror = () => { db.close(); rej(t.error ?? new Error('Storage error')); }; t.onabort = () => { db.close(); rej(t.error ?? new Error('Storage aborted (quota?)')); }; });
}
export const putProject = (p: StoredProject) => tx('projects', 'readwrite', (s) => s.put(p));
export const getProject = (id: string) => tx<StoredProject | undefined>('projects', 'readonly', (s) => s.get(id));
export const listProjects = async (): Promise<StoredProject[]> => (await tx<StoredProject[]>('projects', 'readonly', (s) => s.getAll())).sort((a, b) => b.modified.localeCompare(a.modified));
export const deleteProject = (id: string) => tx('projects', 'readwrite', (s) => s.delete(id));
export interface Autosave { id: 'current'; text: string; time: string; unsaved: boolean; name: string }
export const putAutosave = (a: Autosave) => tx('autosave', 'readwrite', (s) => s.put(a));
export const getAutosave = () => tx<Autosave | undefined>('autosave', 'readonly', (s) => s.get('current'));
export const clearAutosave = () => tx('autosave', 'readwrite', (s) => s.delete('current'));
