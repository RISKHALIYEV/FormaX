import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
import { aliases } from '../../aliases';
const root = fileURLToPath(new URL('.', import.meta.url));

/** Browsers block <script type="module"> and crossorigin assets on file:// (blank page when double-clicking index.html).
 *  The production build is a single IIFE bundle loaded with a classic deferred script, so it also opens from disk,
 *  from Tauri's asset protocol and from an Android WebView. */
const fileProtocolFriendly = (): Plugin => ({
  name: 'formax-file-protocol-friendly', apply: 'build',
  transformIndexHtml: { order: 'post', handler: (html) => html.replace(/<script type="module" crossorigin/g, '<script defer').replace(/<link rel="stylesheet" crossorigin/g, '<link rel="stylesheet"') },
});
export default defineConfig({
  root, base: './', plugins: [react(), fileProtocolFriendly()], resolve: { alias: aliases },
  server: { port: 5173, fs: { allow: [fileURLToPath(new URL('../..', import.meta.url))] } },
  build: { outDir: 'dist', emptyOutDir: true, chunkSizeWarningLimit: 1200, modulePreload: false, rollupOptions: { output: { format: 'iife', inlineDynamicImports: true } } },
});
