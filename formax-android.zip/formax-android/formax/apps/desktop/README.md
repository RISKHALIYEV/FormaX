# FormaX Desktop (Tauri 2) — configuration only, NOT built in this repository's verification
Requires Rust (stable), the Tauri prerequisites for Windows (WebView2, MSVC build tools) and Node 20+.

    npm install
    npm install -D @tauri-apps/cli@^2
    cd apps/desktop && npx tauri icon path/to/1024x1024.png     # generates src-tauri/icons (not committed)
    cd ../.. && npm run build && cd apps/desktop && npx tauri build

Status: the web UI is the same bundle (`apps/web/dist`). File open/save uses the webview's file input/download
mechanism; native dialogs (tauri-plugin-dialog / fs), double-click `.formax` file association handling and
reading the launch argument are **not wired yet** (see ROADMAP.md). No installer has been produced.
