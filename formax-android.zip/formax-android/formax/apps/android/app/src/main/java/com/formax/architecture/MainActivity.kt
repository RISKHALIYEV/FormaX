package com.formax.architecture

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

/**
 * Hosts the shared FormaX web bundle (assets/web) in a WebView served from the virtual origin
 * https://appassets.androidplatform.net (a secure origin, so IndexedDB, localStorage and WebGL work).
 * The manifest declares no INTERNET permission: nothing can leave the device and nothing is fetched remotely.
 *
 * Native services exposed to the web layer:
 *  - window.FormaXAndroid.saveFile(name, mime, base64): system "Save as" dialog (Storage Access Framework, no permission needed)
 *  - window.FormaXAndroid.setTheme(dark): status/navigation bar colours follow the app theme
 *  - hardware Back -> window.__formaxBack() (closes dialogs/panels first); double-back to exit
 *  - opening a project via the file chooser or an Android "open with" intent -> window.__formaxOpenText(name, text)
 */
class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null
    private var pendingSave: ByteArray? = null
    private var pendingSaveName = ""
    private var pageReady = false
    private var pendingOpen: Pair<String, String>? = null
    private var lastBack = 0L
    private val ui = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        web = WebView(this)
        setContentView(web)
        web.setBackgroundColor(Color.parseColor("#15191C"))
        if (0 != (applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE)) WebView.setWebContentsDebuggingEnabled(true)

        val loader = WebViewAssetLoader.Builder().addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            allowFileAccess = false; allowContentAccess = true
            setSupportZoom(false); builtInZoomControls = false; textZoom = 100
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "FormaXAndroid")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
            // Never navigate away from the bundled app.
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != "appassets.androidplatform.net"
            override fun onPageFinished(view: WebView, url: String) {
                pageReady = true
                pendingOpen?.let { (n, t) -> deliverOpen(n, t) }; pendingOpen = null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { startActivityForResult(Intent.createChooser(params.createIntent(), getString(R.string.open_project)), REQ_OPEN); true }
                catch (e: Exception) { chooser = null; cb.onReceiveValue(null); false }
            }
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(function(){return !!(window.__formaxBack && window.__formaxBack());})()") { consumed ->
                    if (consumed == "true") return@evaluateJavascript
                    val now = System.currentTimeMillis()
                    if (now - lastBack < 2000) finish()
                    else { lastBack = now; Toast.makeText(this@MainActivity, R.string.press_back_again, Toast.LENGTH_SHORT).show() }
                }
            }
        })
        handleIntent(intent)
        web.loadUrl("https://appassets.androidplatform.net/assets/web/index.html")
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handleIntent(intent) }

    /** A project opened from a file manager / "open with" arrives as a content:// URI. */
    private fun handleIntent(i: Intent?) {
        val uri = i?.data ?: return
        if (i?.action != Intent.ACTION_VIEW) return
        try {
            val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: return
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "project.formax"
            if (pageReady) deliverOpen(name, text) else pendingOpen = name to text
        } catch (e: Exception) { Toast.makeText(this, R.string.save_failed, Toast.LENGTH_SHORT).show() }
    }
    private fun deliverOpen(name: String, text: String) {
        web.evaluateJavascript("window.__formaxOpenText && window.__formaxOpenText(${JSONObject.quote(name)}, ${JSONObject.quote(text)})", null)
    }
    private fun notifySaved(ok: Boolean, name: String) {
        web.evaluateJavascript("window.__formaxNative && window.__formaxNative.saved(${ok}, ${JSONObject.quote(name)})", null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun saveFile(name: String, mime: String, base64: String) {
            val bytes = try { Base64.decode(base64, Base64.DEFAULT) } catch (e: Exception) { ui.post { notifySaved(false, name) }; return }
            ui.post {
                if (pendingSave != null) { notifySaved(false, name); return@post }
                pendingSave = bytes; pendingSaveName = name
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE); type = mime.ifBlank { "application/octet-stream" }; putExtra(Intent.EXTRA_TITLE, name)
                }
                try { startActivityForResult(intent, REQ_SAVE) }
                catch (e: Exception) { pendingSave = null; notifySaved(false, name) }
            }
        }
        @JavascriptInterface
        fun setTheme(dark: Boolean) {
            ui.post {
                val c = Color.parseColor(if (dark) "#15191C" else "#F4F6F7")
                window.statusBarColor = c; window.navigationBarColor = c
                val ctl = WindowCompat.getInsetsController(window, window.decorView)
                ctl.isAppearanceLightStatusBars = !dark; ctl.isAppearanceLightNavigationBars = !dark
                web.setBackgroundColor(c)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when (requestCode) {
            REQ_OPEN -> { chooser?.onReceiveValue(if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null); chooser = null }
            REQ_SAVE -> {
                val bytes = pendingSave; val name = pendingSaveName; pendingSave = null
                val uri = data?.data
                if (resultCode != Activity.RESULT_OK || uri == null || bytes == null) { notifySaved(false, name); return }
                val ok = try { contentResolver.openOutputStream(uri, "wt")?.use { it.write(bytes) } != null } catch (e: Exception) { false }
                Toast.makeText(this, if (ok) getString(R.string.saved_fmt, name) else getString(R.string.save_failed), Toast.LENGTH_SHORT).show()
                notifySaved(ok, name)
            }
            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }
    override fun onDestroy() { chooser?.onReceiveValue(null); web.destroy(); super.onDestroy() }

    private companion object { const val REQ_OPEN = 1; const val REQ_SAVE = 2 }
}
