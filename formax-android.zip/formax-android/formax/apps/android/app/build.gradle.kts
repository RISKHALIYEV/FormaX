plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

// Version: override with -PformaxVersionName=1.2.3 -PformaxVersionCode=12 (CI passes the run number as code).
val vName = (project.findProperty("formaxVersionName") as String?) ?: "0.1.0"
val vCode = ((project.findProperty("formaxVersionCode") as String?) ?: "1").toInt()

// Release signing comes ONLY from environment variables; no key or password is stored in the repository.
val ksPath = System.getenv("FORMAX_KEYSTORE_PATH")

android {
    namespace = "com.formax.architecture"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.formax.architecture"
        minSdk = 26; targetSdk = 34
        versionCode = vCode; versionName = vName
    }
    signingConfigs {
        if (ksPath != null) create("release") {
            storeFile = file(ksPath)
            storePassword = System.getenv("FORMAX_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("FORMAX_KEY_ALIAS")
            keyPassword = System.getenv("FORMAX_KEY_PASSWORD")
        }
    }
    buildTypes {
        debug { applicationIdSuffix = ".debug"; versionNameSuffix = "-debug" }
        release {
            isMinifyEnabled = false
            if (ksPath != null) signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-splashscreen:1.0.1")
}
