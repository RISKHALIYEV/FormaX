# FormaX Android host
Native WebView host for the FormaX web bundle. Package `com.formax.architecture`. **Not compiled in the preparation environment**; see `../../docs/ANDROID_BUILD.md` and `../../docs/TERMUX_BUILD.md`.

    bash scripts/build-android.sh debug      # from the repository root

Output: `dist-apk/app-debug.apk`.
