#!/usr/bin/env bash
exec "$(dirname "${BASH_SOURCE[0]}")/build-android.sh" debug "$@"
