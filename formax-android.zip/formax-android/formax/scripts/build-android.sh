#!/usr/bin/env bash
# FormaX Android build driver.  Usage: scripts/build-android.sh [debug|release]
# Steps: check tools -> npm ci -> typecheck+tests -> web build -> copy into Android assets -> Gradle -> collect APK in dist-apk/
set -euo pipefail
TYPE="${1:-debug}"
case "$TYPE" in debug|release) ;; *) echo "Usage: $0 [debug|release]" >&2; exit 2;; esac
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"; cd "$ROOT"

need() { command -v "$1" >/dev/null 2>&1 || { echo "ERROR: '$1' not found. See docs/TERMUX_BUILD.md" >&2; exit 1; }; }
need node; need npm; need java
JV="$(java -version 2>&1 | head -n1 | sed -E 's/.*version "([0-9]+).*/\1/')"
[ "${JV:-0}" -ge 17 ] || { echo "ERROR: JDK 17 or newer required (found: ${JV:-unknown})" >&2; exit 1; }
[ -n "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ] || { echo "ERROR: set ANDROID_HOME to your Android SDK directory" >&2; exit 1; }
export ANDROID_HOME="${ANDROID_HOME:-$ANDROID_SDK_ROOT}"

echo "==> Web dependencies";  npm ci --no-audit --no-fund
echo "==> Typecheck + tests"; npm run typecheck && npm test
echo "==> Web build";         npm run build
echo "==> Copy web build into the Android project"; node scripts/sync-android.mjs

GRADLE_ARGS=()
# Termux (Android/aarch64): the aapt2 binary downloaded by Gradle is x86_64-only. Use Termux's own aapt2 if present.
if [ -n "${TERMUX_VERSION:-}" ] || [ -d /data/data/com.termux ]; then
  AAPT2="${AAPT2_PATH:-$(command -v aapt2 || true)}"
  if [ -n "$AAPT2" ]; then GRADLE_ARGS+=("-Pandroid.aapt2FromMavenOverride=$AAPT2"); echo "==> Termux detected, using aapt2: $AAPT2"
  else echo "WARN: Termux detected but no aapt2 found (pkg install aapt2). The build will most likely fail; use GitHub Actions instead." >&2; fi
fi
[ -n "${FORMAX_VERSION_NAME:-}" ] && GRADLE_ARGS+=("-PformaxVersionName=$FORMAX_VERSION_NAME")
[ -n "${FORMAX_VERSION_CODE:-}" ] && GRADLE_ARGS+=("-PformaxVersionCode=$FORMAX_VERSION_CODE")

TASK="assembleDebug"; [ "$TYPE" = release ] && TASK="assembleRelease"
if [ "$TYPE" = release ] && [ -z "${FORMAX_KEYSTORE_PATH:-}" ]; then
  echo "WARN: FORMAX_KEYSTORE_PATH is not set -> the release APK will be UNSIGNED and cannot be installed. See docs/TERMUX_BUILD.md (signing)." >&2
fi
echo "==> Gradle $TASK"
( cd apps/android && chmod +x ./gradlew && ./gradlew "$TASK" --no-daemon "${GRADLE_ARGS[@]}" )

mkdir -p dist-apk; found=0
for f in apps/android/app/build/outputs/apk/"$TYPE"/*.apk; do [ -f "$f" ] && { cp "$f" dist-apk/; echo "APK: dist-apk/$(basename "$f")"; found=1; }; done
[ "$found" = 1 ] || { echo "ERROR: no APK produced" >&2; exit 1; }
