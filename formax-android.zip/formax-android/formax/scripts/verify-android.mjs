// Static verification of the Android project: assets, resources, ids, wrapper, web sync. Usage: node scripts/verify-android.mjs
import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
const R = new URL('..', import.meta.url).pathname; let bad = 0;
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) bad++; };
const f = (p) => join(R, p), has = (p) => existsSync(f(p)), txt = (p) => readFileSync(f(p), 'utf8');
const pngSize = (p) => { const b = readFileSync(f(p)); return b.readUInt32BE(16) + 'x' + b.readUInt32BE(20); };
const walk = (d) => readdirSync(d).flatMap((n) => statSync(join(d, n)).isDirectory() ? walk(join(d, n)) : [join(d, n)]);

for (const p of ['assets/logo/logo.svg', 'assets/logo/logo.png', 'assets/logo/logo-dark.svg', 'assets/logo/logo-light.svg', 'assets/icons/playstore-512.png', 'assets/splash/splash.svg', 'assets/splash/splash-1080x1920.png',
  'assets/illustrations/welcome.svg', 'assets/illustrations/empty-project.svg', 'assets/illustrations/error.svg', 'assets/illustrations/no-files.svg', 'assets/illustrations/create-project.svg']) ok(has(p), 'asset exists: ' + p);
ok(pngSize('assets/icons/playstore-512.png') === '512x512', 'Play icon is 512x512');

const res = 'apps/android/app/src/main/res';
const dens = { mdpi: [48, 108], hdpi: [72, 162], xhdpi: [96, 216], xxhdpi: [144, 324], xxxhdpi: [192, 432] };
for (const [d, [l, a]] of Object.entries(dens)) for (const [n, s] of [['ic_launcher', l], ['ic_launcher_round', l], ['ic_launcher_foreground', a], ['ic_launcher_background', a], ['ic_launcher_monochrome', a]]) {
  const p = `${res}/mipmap-${d}/${n}.png`; ok(has(p) && pngSize(p) === `${s}x${s}`, `${p} ${s}px`);
}
ok(has(`${res}/mipmap-anydpi-v26/ic_launcher.xml`) && has(`${res}/mipmap-anydpi-v26/ic_launcher_round.xml`) && txt(`${res}/mipmap-anydpi-v26/ic_launcher.xml`).includes('<monochrome'), 'adaptive icon XML (with monochrome)');
ok(has(`${res}/drawable/ic_splash.xml`) && txt(`${res}/values/themes.xml`).includes('@drawable/ic_splash'), 'splash drawable wired into splash theme');

// every @type/name reference resolves
const have = { mipmap: new Set(), drawable: new Set(), color: new Set(), string: new Set(), style: new Set() };
for (const p of walk(f(res))) { const m = p.match(/(mipmap|drawable)[^/]*\/([\w]+)\.(png|xml)$/); if (m) have[m[1]].add(m[2]); if (/values\/.*\.xml$/.test(p)) for (const x of readFileSync(p, 'utf8').matchAll(/<(color|string|style) name="([\w.]+)"/g)) have[x[1]].add(x[2]); }
const all = txt('apps/android/app/src/main/AndroidManifest.xml') + walk(f(res)).filter((p) => p.endsWith('.xml')).map((p) => readFileSync(p, 'utf8')).join('\n');
const missing = [...all.matchAll(/@(mipmap|drawable|color|string|style)\/([\w.]+)/g)].filter((m) => !have[m[1]].has(m[2]));
ok(missing.length === 0, 'all resource references resolve' + (missing.length ? ': ' + missing.map((m) => m[0]).join(', ') : ''));
const kt = txt('apps/android/app/src/main/java/com/formax/architecture/MainActivity.kt');
ok([...kt.matchAll(/R\.string\.(\w+)/g)].every((m) => have.string.has(m[1])), 'Kotlin R.string references resolve');

const g = txt('apps/android/app/build.gradle.kts');
ok(g.includes('applicationId = "com.formax.architecture"') && g.includes('namespace = "com.formax.architecture"') && kt.startsWith('package com.formax.architecture'), 'application id / namespace / Kotlin package are com.formax.architecture');
ok(/versionCode = vCode/.test(g) && /versionName = vName/.test(g), 'version metadata configured');
ok(!/uses-permission/.test(txt('apps/android/app/src/main/AndroidManifest.xml')), 'manifest requests no permissions');
ok(has('apps/android/gradlew') && has('apps/android/gradle/wrapper/gradle-wrapper.jar') && /gradle-8\.7-bin\.zip/.test(txt('apps/android/gradle/wrapper/gradle-wrapper.properties')), 'Gradle wrapper (8.7) present');
ok(/com\.android\.application.*8\.5\.2/.test(txt('apps/android/build.gradle.kts')) && /android.useAndroidX=true/.test(txt('apps/android/gradle.properties')), 'AGP 8.5.2 + AndroidX configured');
for (const k of ['saveFile', 'ACTION_CREATE_DOCUMENT', 'setTheme', '__formaxBack', 'ACTION_VIEW', 'shouldOverrideUrlLoading']) ok(kt.includes(k), 'MainActivity implements ' + k);
for (const p of ['scripts/build-android.sh', 'scripts/build-debug.sh', 'scripts/build-release.sh', 'docs/TERMUX_BUILD.md', '.github/workflows/android-build.yml']) ok(has(p), 'exists: ' + p);
const synced = has('apps/android/app/src/main/assets/web/index.html');
ok(synced, 'web build synchronized into Android assets (run npm run build && node scripts/sync-android.mjs)');
if (synced) { const a = txt('apps/android/app/src/main/assets/web/index.html'), refs = [...a.matchAll(/(?:src|href)="\.\/([^"]+)"/g)].map((m) => m[1]); ok(refs.every((r) => has('apps/android/app/src/main/assets/web/' + r)), 'index.html asset references exist in Android assets (' + refs.length + ')'); }
console.log(bad ? `\n${bad} check(s) FAILED` : '\nAll static checks passed'); process.exit(bad ? 1 : 0);
