// Generates examples/sample.formax using the same core the app uses (run: npm run example)
import { writeFileSync } from 'node:fs';
import { Session, defaultProject, addBuildingFootprint, addWall, addRoom, addOpening, addLevel, copyLevelContent, addRoofFromSlab, addConstraint, findSnap } from '@formax/core';
import { serializeProject } from '@formax/project-format';
import { v2 } from '@formax/geometry';

const s = new Session(defaultProject('Two-storey house (example)'));
const must = (r: { ok: boolean; error?: string }) => { if (!r.ok) throw new Error(r.error); };
const snap = { tol: 200, grid: 100, endpoints: true, midpoints: true, intersections: true, edges: true, gridOn: true, level: 'L1' };
must(s.commit('footprint', (p) => addBuildingFootprint(p, { x: 0, y: 0, width: 15000, length: 12000, level: 'L1' })));
const a = findSnap(s.model, v2(7500, 0), snap), b = findSnap(s.model, v2(7500, 12000), snap);
must(s.commit('partition', (p) => addWall(p, { a: a.ex, b: b.ex, level: 'L1' })));
must(s.commit('rooms', (p) => {
  addRoom(p, { level: 'L1', name: 'Living room', points: [{ x: 0, y: 0 }, { x: 'building_width / 2', y: 0 }, { x: 'building_width / 2', y: 'building_length' }, { x: 0, y: 'building_length' }] });
  addRoom(p, { level: 'L1', name: 'Kitchen & dining', points: [{ x: 'building_width / 2', y: 0 }, { x: 'building_width', y: 0 }, { x: 'building_width', y: 'building_length' }, { x: 'building_width / 2', y: 'building_length' }] });
}));
must(s.commit('openings', (p) => { addOpening(p, { type: 'door', host: 'w1', offset: 3750, level: 'L1' }); addOpening(p, { type: 'window', host: 'w1', offset: 11250, level: 'L1' }); addOpening(p, { type: 'window', host: 'w3', offset: 3750, level: 'L1' }); addOpening(p, { type: 'window', host: 'w3', offset: 11250, level: 'L1' }); addOpening(p, { type: 'door', host: 'w5', offset: 6000, level: 'L1' }); }));
must(s.commit('storey', (p) => { const id = addLevel(p, 'First floor'); copyLevelContent(p, 'L1', id); addRoofFromSlab(p, id); }));
must(s.commit('constraint', (p) => addConstraint(p, 'Plot width', 'building_width <= 20000', 'The building must fit the 20 m plot.')));
writeFileSync(new URL('../examples/sample.formax', import.meta.url), serializeProject(s.project, { now: '2026-11-18T00:00:00.000Z' }));
console.log('walls', s.model.byType('wall').length, 'rooms', s.model.byType('room').map((r) => `${r.name} ${(r.netArea / 1e6).toFixed(2)} m2`), 'issues', s.model.issues.length);
