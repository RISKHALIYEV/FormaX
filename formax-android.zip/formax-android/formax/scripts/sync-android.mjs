// Copies the built web app into the Android project's assets (run `npm run build` first).
// The service worker is not needed inside the app (assets are bundled), so it is left out.
import { cpSync, rmSync, existsSync, mkdirSync } from 'node:fs';
const src = new URL('../apps/web/dist/', import.meta.url), dst = new URL('../apps/android/app/src/main/assets/web/', import.meta.url);
if (!existsSync(src)) { console.error('apps/web/dist not found – run `npm run build` first'); process.exit(1); }
rmSync(dst, { recursive: true, force: true }); mkdirSync(dst, { recursive: true }); cpSync(src, dst, { recursive: true });
rmSync(new URL('sw.js', dst), { force: true });
console.log('Synced web build to Android assets');
