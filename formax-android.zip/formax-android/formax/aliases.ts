import { fileURLToPath } from 'node:url';
const p = (n: string) => fileURLToPath(new URL(`./packages/${n}/src/index.ts`, import.meta.url));
export const aliases: Record<string, string> = Object.fromEntries(
  ['geometry', 'parametric', 'architecture', 'drawing', 'rendering', 'project-format', 'localization', 'core'].map((n) => [`@formax/${n}`, p(n)]));
