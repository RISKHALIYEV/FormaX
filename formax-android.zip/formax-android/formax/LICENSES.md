# Licenses
FormaX source: MIT (see `package.json`; add a LICENSE file before distribution).
Runtime dependencies (versions as installed):
| Package | Version | License |
|---|---|---|
| react | 18.3.1 | MIT |
| react-dom | 18.3.1 | MIT |
| three | 0.169.0 | MIT |
| zustand | 4.5.7 | MIT |
| @vitejs/plugin-react | 4.7.0 | MIT |
Development dependencies: vite,vitest,typescript,@vitejs/plugin-react, all permissive (MIT; TypeScript is Apache-2.0).
Optional, not bundled: Tauri 2 (MIT/Apache-2.0), AndroidX libraries (Apache-2.0). Open CASCADE (LGPL-2.1 + exception) is **not** used.
Transitive dependencies were not audited individually; run a license scanner (e.g. `npx license-checker`) before a release.
