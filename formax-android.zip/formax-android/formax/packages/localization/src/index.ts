export type Lang = 'en' | 'uz';
const en = {
  'menu.file': 'File', 'menu.edit': 'Edit', 'menu.view': 'View', 'menu.model': 'Model', 'menu.architecture': 'Architecture', 'menu.parametric': 'Parametric', 'menu.drawing': 'Drawing', 'menu.export': 'Export', 'menu.settings': 'Settings',
  'tool.select': 'Select', 'tool.wall': 'Interior wall', 'tool.footprint': 'Building footprint', 'tool.room': 'Room', 'tool.door': 'Door', 'tool.window': 'Window', 'tool.line': 'Line', 'tool.polyline': 'Polyline', 'tool.circle': 'Circle', 'tool.dimension': 'Dimension', 'tool.column': 'Column',
  'view.2d': 'Plan', 'view.3d': '3D', 'panel.project': 'Project', 'panel.layers': 'Layers', 'panel.tools': 'Tools', 'panel.properties': 'Properties', 'panel.parameters': 'Parameters', 'panel.data': 'Data', 'panel.issues': 'Issues',
  'file.new': 'New project', 'file.open': 'Open file…', 'file.save': 'Save', 'file.saveas': 'Download .formax', 'file.browser': 'Projects in this browser…', 'file.example': 'Load example project',
  'edit.undo': 'Undo', 'edit.redo': 'Redo', 'edit.delete': 'Delete', 'edit.duplicate': 'Duplicate', 'edit.rotate': 'Rotate…', 'edit.scale': 'Scale…', 'edit.selectall': 'Select all',
  'status.unsaved': 'Unsaved changes', 'status.saved': 'Saved', 'status.noselection': 'Nothing selected', 'empty.title': 'Empty project', 'empty.hint': 'Choose “Building footprint” and drag a rectangle in the plan.',
  'export.svg': 'Floor plan (SVG)', 'export.pdf': 'Floor plan (PDF)', 'export.elev.svg': 'Elevation (SVG)', 'export.elev.pdf': 'Elevation (PDF)',
} as const;
export type Key = keyof typeof en;
const uz: Record<Key, string> = {
  'menu.file': 'Fayl', 'menu.edit': 'Tahrirlash', 'menu.view': 'Ko‘rinish', 'menu.model': 'Model', 'menu.architecture': 'Arxitektura', 'menu.parametric': 'Parametrik', 'menu.drawing': 'Chizma', 'menu.export': 'Eksport', 'menu.settings': 'Sozlamalar',
  'tool.select': 'Tanlash', 'tool.wall': 'Ichki devor', 'tool.footprint': 'Bino konturi', 'tool.room': 'Xona', 'tool.door': 'Eshik', 'tool.window': 'Deraza', 'tool.line': 'Chiziq', 'tool.polyline': 'Siniq chiziq', 'tool.circle': 'Aylana', 'tool.dimension': 'O‘lcham', 'tool.column': 'Kolonna',
  'view.2d': 'Reja', 'view.3d': '3D', 'panel.project': 'Loyiha', 'panel.layers': 'Qatlamlar', 'panel.tools': 'Asboblar', 'panel.properties': 'Xossalar', 'panel.parameters': 'Parametrlar', 'panel.data': 'Ma’lumotlar', 'panel.issues': 'Muammolar',
  'file.new': 'Yangi loyiha', 'file.open': 'Faylni ochish…', 'file.save': 'Saqlash', 'file.saveas': '.formax yuklab olish', 'file.browser': 'Brauzerdagi loyihalar…', 'file.example': 'Namuna loyihani yuklash',
  'edit.undo': 'Bekor qilish', 'edit.redo': 'Qaytarish', 'edit.delete': 'O‘chirish', 'edit.duplicate': 'Nusxalash', 'edit.rotate': 'Burish…', 'edit.scale': 'Masshtablash…', 'edit.selectall': 'Hammasini tanlash',
  'status.unsaved': 'Saqlanmagan o‘zgarishlar', 'status.saved': 'Saqlangan', 'status.noselection': 'Hech narsa tanlanmagan', 'empty.title': 'Bo‘sh loyiha', 'empty.hint': '“Bino konturi” asbobini tanlab, rejada to‘rtburchak chizing.',
  'export.svg': 'Reja (SVG)', 'export.pdf': 'Reja (PDF)', 'export.elev.svg': 'Fasad (SVG)', 'export.elev.pdf': 'Fasad (PDF)',
};
const dict = { en, uz } as Record<Lang, Record<Key, string>>;
export const t = (lang: Lang, key: Key): string => dict[lang][key] ?? en[key];
export const languages: { id: Lang; name: string }[] = [{ id: 'en', name: 'English' }, { id: 'uz', name: 'Oʻzbekcha' }];
