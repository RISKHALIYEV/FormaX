import { Vec2, v2, add, sub, scale, normalize, perp, polygonCentroid, bboxOf, dist, dot } from '@formax/geometry';
import type { ArchModel, RWall, RObj } from '@formax/architecture';

/** Vector primitives. Geometry is in model millimetres (y up); line widths and text sizes are in paper millimetres. */
export type Prim =
  | { k: 'poly'; pts: Vec2[]; closed: boolean; fill?: string; stroke?: string; w: number }
  | { k: 'text'; at: Vec2; text: string; size: number; anchor: 'start' | 'middle' | 'end'; color?: string; rot?: number };
export interface Sheet { prims: Prim[]; title: string; note?: string }
export type PaperSize = 'A4' | 'A3' | 'A2' | 'A1';
export const PAPER: Record<PaperSize, [number, number]> = { A4: [297, 210], A3: [420, 297], A2: [594, 420], A1: [841, 594] };
export const STANDARD_SCALES = [20, 50, 100, 200, 500, 1000];

const INK = '#1a1a1a', POCHE = '#2b2b2b', THIN = 0.13, MED = 0.25;
const rect = (c: Vec2, d: Vec2, n: Vec2, hw: number, hh: number): Vec2[] => [add(add(c, scale(d, -hw)), scale(n, -hh)), add(add(c, scale(d, hw)), scale(n, -hh)), add(add(c, scale(d, hw)), scale(n, hh)), add(add(c, scale(d, -hw)), scale(n, hh))];
const fmt = (mm: number) => String(Math.round(mm));

function dimension(out: Prim[], a: Vec2, b: Vec2, offset: number, label?: string) {
  const d = normalize(sub(b, a)), n = perp(d), o = scale(n, offset);
  const a2 = add(a, o), b2 = add(b, o), tick = 1.2; // paper mm handled via model units below
  const ext = scale(n, offset + Math.sign(offset || 1) * 150);
  out.push({ k: 'poly', pts: [add(a, scale(n, Math.sign(offset || 1) * 100)), add(a, ext)], closed: false, stroke: INK, w: THIN });
  out.push({ k: 'poly', pts: [add(b, scale(n, Math.sign(offset || 1) * 100)), add(b, ext)], closed: false, stroke: INK, w: THIN });
  out.push({ k: 'poly', pts: [a2, b2], closed: false, stroke: INK, w: THIN });
  for (const q of [a2, b2]) out.push({ k: 'poly', pts: [add(q, scale(add(d, n), -tick * 25)), add(q, scale(add(d, n), tick * 25))], closed: false, stroke: INK, w: MED });
  let ang = (Math.atan2(d.y, d.x) * 180) / Math.PI; if (ang > 90 || ang <= -90) ang += 180;
  out.push({ k: 'text', at: add(scale(add(a2, b2), 0.5), scale(n, Math.sign(offset || 1) * 60)), text: label ?? fmt(dist(a, b)), size: 2.2, anchor: 'middle', rot: ang });
}

export interface PlanOptions { dimensions?: boolean }
/** Floor plan of one level, derived directly from the resolved model. */
export function buildPlan(model: ArchModel, levelId: string, opts: PlanOptions = {}): Sheet {
  const out: Prim[] = []; const lv = model.levels.get(levelId);
  const walls = model.byType('wall', levelId);
  for (const w of walls) out.push({ k: 'poly', pts: w.polygon, closed: true, fill: POCHE, stroke: POCHE, w: 0.05 });
  const openings = [...model.byType('door', levelId), ...model.byType('window', levelId)];
  for (const o of openings) {
    const w = model.get<RWall>(o.host); if (!w || w.type !== 'wall') continue;
    const d = normalize(sub(w.b, w.a)), n = perp(d), c = add(w.a, scale(d, o.offset));
    out.push({ k: 'poly', pts: rect(c, d, n, o.width / 2, w.thickness / 2 + 2), closed: true, fill: '#ffffff', w: 0 });
    if (o.type === 'window') {
      for (const f of [-1, 0, 1]) out.push({ k: 'poly', pts: [add(add(c, scale(d, -o.width / 2)), scale(n, (f * w.thickness) / 3)), add(add(c, scale(d, o.width / 2)), scale(n, (f * w.thickness) / 3))], closed: false, stroke: INK, w: f === 0 ? THIN : THIN });
      out.push({ k: 'poly', pts: rect(c, d, n, o.width / 2, w.thickness / 2), closed: true, stroke: INK, w: THIN });
    } else {
      const hinge = add(c, scale(d, -o.width / 2)), tip = add(hinge, scale(n, o.width));
      out.push({ k: 'poly', pts: [hinge, tip], closed: false, stroke: INK, w: MED });
      const arc: Vec2[] = []; for (let i = 0; i <= 16; i++) { const th = (i / 16) * (Math.PI / 2); arc.push(add(hinge, add(scale(d, o.width * Math.cos(th)), scale(n, o.width * Math.sin(th))))); }
      out.push({ k: 'poly', pts: arc, closed: false, stroke: INK, w: THIN });
    }
  }
  for (const c of model.byType('column', levelId)) out.push({ k: 'poly', pts: rect(c.p, v2(1, 0), v2(0, 1), c.width / 2, c.depth / 2), closed: true, fill: POCHE, stroke: INK, w: THIN });
  for (const b of model.byType('beam', levelId)) out.push({ k: 'poly', pts: [b.a, b.b], closed: false, stroke: '#777777', w: THIN });
  for (const r of model.byType('room', levelId)) {
    out.push({ k: 'poly', pts: r.net, closed: true, stroke: '#888888', w: 0.08 });
    const c = polygonCentroid(r.net);
    out.push({ k: 'text', at: add(c, v2(0, 150)), text: r.name, size: 3, anchor: 'middle' });
    out.push({ k: 'text', at: add(c, v2(0, -200)), text: `${(r.netArea / 1e6).toFixed(2)} m²`, size: 2.4, anchor: 'middle', color: '#444444' });
  }
  for (const l of model.byType('line', levelId)) out.push({ k: 'poly', pts: [l.a, l.b], closed: false, stroke: INK, w: THIN });
  for (const l of model.byType('polyline', levelId)) out.push({ k: 'poly', pts: l.points, closed: false, stroke: INK, w: THIN });
  for (const c of model.byType('circle', levelId)) { const pts: Vec2[] = []; for (let i = 0; i < 48; i++) { const th = (i / 48) * 2 * Math.PI; pts.push(v2(c.c.x + c.r * Math.cos(th), c.c.y + c.r * Math.sin(th))); } out.push({ k: 'poly', pts, closed: true, stroke: INK, w: THIN }); }
  for (const d of model.byType('dimension', levelId)) dimension(out, d.a, d.b, d.offset);
  if (opts.dimensions !== false && walls.length) {
    const bb = bboxOf(walls.flatMap((w) => w.polygon))!, off = 900;
    dimension(out, v2(bb.min.x, bb.min.y), v2(bb.max.x, bb.min.y), -off);
    dimension(out, v2(bb.min.x, bb.min.y), v2(bb.min.x, bb.max.y), -off);
  }
  return { prims: out, title: `Floor plan – ${lv?.name ?? levelId}` };
}

export type ElevationSide = 'south' | 'north' | 'east' | 'west';
/** Orthographic elevation (walls, openings of viewer-facing walls, level lines). Section views are not implemented. */
export function buildElevation(model: ArchModel, side: ElevationSide): Sheet {
  const h = (p: Vec2) => (side === 'south' ? p.x : side === 'north' ? -p.x : side === 'east' ? p.y : -p.y);
  const depth = (p: Vec2) => (side === 'south' ? p.y : side === 'north' ? -p.y : side === 'east' ? -p.x : p.x);
  const out: Prim[] = [], walls = model.byType('wall');
  if (!walls.length) return { prims: [], title: `Elevation – ${side}` };
  const all = walls.flatMap((w) => w.polygon), hs = all.map(h), h0 = Math.min(...hs), h1 = Math.max(...hs);
  const dmin = Math.min(...all.map(depth)), dmax = Math.max(...all.map(depth)), dmid = (dmin + dmax) / 2;
  const view = side === 'south' ? v2(0, 1) : side === 'north' ? v2(0, -1) : side === 'east' ? v2(-1, 0) : v2(1, 0);
  out.push({ k: 'poly', pts: [v2(h0 - 1500, 0), v2(h1 + 1500, 0)], closed: false, stroke: INK, w: 0.5 });
  const sorted = [...walls].sort((a, b) => depth(polygonCentroid(b.polygon)) - depth(polygonCentroid(a.polygon)));
  for (const w of sorted) {
    const x = w.polygon.map(h), a = Math.min(...x), b = Math.max(...x);
    out.push({ k: 'poly', pts: [v2(a, w.z), v2(b, w.z), v2(b, w.z + w.height), v2(a, w.z + w.height)], closed: true, fill: '#e6e1d3', stroke: INK, w: MED });
    const wd = normalize(sub(w.b, w.a));
    if (Math.abs(dot(wd, view)) > 0.3 || depth(polygonCentroid(w.polygon)) > dmid) continue;
    for (const o of model.openingsOf(w.id)) {
      const c = h(add(w.a, scale(wd, o.offset))), z0 = w.z + o.sill;
      out.push({ k: 'poly', pts: [v2(c - o.width / 2, z0), v2(c + o.width / 2, z0), v2(c + o.width / 2, z0 + o.height), v2(c - o.width / 2, z0 + o.height)], closed: true, fill: o.type === 'window' ? '#cfe6f1' : '#a8855a', stroke: INK, w: MED });
      if (o.type === 'window') out.push({ k: 'poly', pts: [v2(c, z0), v2(c, z0 + o.height)], closed: false, stroke: INK, w: THIN });
    }
  }
  for (const [, l] of model.levels) {
    out.push({ k: 'poly', pts: [v2(h0 - 1200, l.elevation), v2(h1 + 1200, l.elevation)], closed: false, stroke: '#888888', w: THIN });
    out.push({ k: 'text', at: v2(h1 + 1300, l.elevation + 60), text: `${l.elevation >= 0 ? '+' : ''}${(l.elevation / 1000).toFixed(3)}`, size: 2.2, anchor: 'start' });
  }
  const top = Math.max(...walls.map((w) => w.z + w.height));
  dimension(out, v2(h1, 0), v2(h1, top), 700, `${fmt(top)}`);
  return { prims: out, title: `Elevation – ${side}` };
}

// ---------- Layout onto a sheet of paper ----------
export interface LayoutOptions { paper?: PaperSize; scale?: number | 'auto'; projectName?: string; margin?: number }
export interface Layout { prims: Prim[]; width: number; height: number; scale: number; fits: boolean }
/** Maps model-space primitives to paper millimetres (y down) and adds frame and title block. */
export function layoutSheet(sheet: Sheet, o: LayoutOptions = {}): Layout {
  const [W, H] = PAPER[o.paper ?? 'A3'], m = o.margin ?? 12, tb = 14;
  const pts = sheet.prims.flatMap((p) => (p.k === 'poly' ? p.pts : [p.at]));
  const bb = bboxOf(pts) ?? { min: v2(0, 0), max: v2(1, 1) };
  const pad = 600, wMM = bb.max.x - bb.min.x + 2 * pad, hMM = bb.max.y - bb.min.y + 2 * pad, availW = W - 2 * m, availH = H - 2 * m - tb;
  let sc = typeof o.scale === 'number' ? o.scale : 100, fits = wMM / sc <= availW && hMM / sc <= availH;
  if (o.scale === 'auto' || o.scale === undefined) { const f = STANDARD_SCALES.find((s) => wMM / s <= availW && hMM / s <= availH); sc = f ?? STANDARD_SCALES[STANDARD_SCALES.length - 1]; fits = !!f; }
  const ox = m + (availW - (bb.max.x - bb.min.x) / sc) / 2, oy = m + (availH - (bb.max.y - bb.min.y) / sc) / 2;
  const P = (p: Vec2): Vec2 => v2(ox + (p.x - bb.min.x) / sc, oy + (bb.max.y - p.y) / sc);
  const prims: Prim[] = sheet.prims.map((p) => (p.k === 'poly' ? { ...p, pts: p.pts.map(P) } : { ...p, at: P(p.at) }));
  const frame = [v2(m / 2, m / 2), v2(W - m / 2, m / 2), v2(W - m / 2, H - m / 2), v2(m / 2, H - m / 2)];
  prims.push({ k: 'poly', pts: frame, closed: true, stroke: INK, w: 0.35 });
  prims.push({ k: 'poly', pts: [v2(m / 2, H - m / 2 - tb), v2(W - m / 2, H - m / 2 - tb)], closed: false, stroke: INK, w: 0.25 });
  prims.push({ k: 'text', at: v2(m, H - m / 2 - 5), text: `${o.projectName ?? 'FormaX project'} — ${sheet.title}`, size: 4, anchor: 'start' });
  prims.push({ k: 'text', at: v2(W - m, H - m / 2 - 5), text: `Scale 1:${sc}   ${o.paper ?? 'A3'}`, size: 3.2, anchor: 'end' });
  return { prims, width: W, height: H, scale: sc, fits };
}

const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string));
const n2 = (n: number) => Number(n.toFixed(3));
export function toSVG(l: Layout): string {
  const body = l.prims.map((p) => {
    if (p.k === 'poly') {
      const d = p.pts.map((q, i) => `${i ? 'L' : 'M'}${n2(q.x)} ${n2(q.y)}`).join('') + (p.closed ? 'Z' : '');
      return `<path d="${d}" fill="${p.fill ?? 'none'}" stroke="${p.stroke ?? 'none'}" stroke-width="${p.w}" stroke-linejoin="miter"/>`;
    }
    const anchor = p.anchor, tr = p.rot ? ` transform="rotate(${-p.rot} ${n2(p.at.x)} ${n2(p.at.y)})"` : '';
    return `<text x="${n2(p.at.x)}" y="${n2(p.at.y)}" font-size="${p.size}" text-anchor="${anchor}" fill="${p.color ?? INK}" font-family="Helvetica, Arial, sans-serif"${tr}>${esc(p.text)}</text>`;
  }).join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${l.width}mm" height="${l.height}mm" viewBox="0 0 ${l.width} ${l.height}">\n<rect width="${l.width}" height="${l.height}" fill="#ffffff"/>\n${body}\n</svg>\n`;
}

const PT = 72 / 25.4;
const rgb = (hex?: string): string => { const h = (hex ?? '#000000').replace('#', ''); return [0, 2, 4].map((i) => (parseInt(h.slice(i, i + 2), 16) / 255).toFixed(3)).join(' '); };
const latin1 = (s: string) => s.replace(/[^\x20-\xff]/g, '?').replace(/([\\()])/g, '\\$1');
/** Minimal single-page vector PDF writer (Helvetica, WinAnsi). Text width for alignment is approximated. */
export function toPDF(l: Layout): Uint8Array {
  const Wp = l.width * PT, Hp = l.height * PT, X = (v: number) => (v * PT).toFixed(2), Y = (v: number) => (Hp - v * PT).toFixed(2);
  let c = '';
  for (const p of l.prims) {
    if (p.k === 'poly') {
      if (p.pts.length < 2) continue;
      c += `${p.w > 0 ? (p.w * PT).toFixed(3) : '0'} w ${rgb(p.fill)} rg ${rgb(p.stroke)} RG\n` + p.pts.map((q, i) => `${X(q.x)} ${Y(q.y)} ${i ? 'l' : 'm'}`).join('\n') + (p.closed ? '\nh' : '');
      c += p.fill && p.stroke && p.w > 0 ? '\nB\n' : p.fill ? '\nf\n' : p.stroke ? '\nS\n' : '\nn\n';
    } else {
      const size = p.size * PT, w = p.text.length * size * 0.5, dx = p.anchor === 'middle' ? -w / 2 : p.anchor === 'end' ? -w : 0;
      const a = ((p.rot ?? 0) * Math.PI) / 180, cs = Math.cos(a), sn = Math.sin(a), x = p.at.x * PT + dx * cs, y = Hp - p.at.y * PT + dx * sn;
      c += `BT /F1 ${size.toFixed(2)} Tf ${rgb(p.color)} rg ${cs.toFixed(4)} ${sn.toFixed(4)} ${(-sn).toFixed(4)} ${cs.toFixed(4)} ${x.toFixed(2)} ${y.toFixed(2)} Tm (${latin1(p.text)}) Tj ET\n`;
    }
  }
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>', '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${Wp.toFixed(2)} ${Hp.toFixed(2)}] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>`,
    `<< /Length ${c.length} >>\nstream\n${c}endstream`, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
  ];
  let pdf = '%PDF-1.4\n'; const offs: number[] = [];
  objs.forEach((o, i) => { offs.push(pdf.length); pdf += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = pdf.length;
  pdf += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map((o) => `${String(o).padStart(10, '0')} 00000 n \n`).join('') + `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  const bytes = new Uint8Array(pdf.length); for (let i = 0; i < pdf.length; i++) bytes[i] = pdf.charCodeAt(i) & 0xff;
  return bytes;
}
export type { RObj };
