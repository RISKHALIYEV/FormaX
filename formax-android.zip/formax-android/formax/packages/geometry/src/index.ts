/**
 * FormaX geometry foundation.
 * Deterministic 2D computational geometry in millimetres. This is NOT a B-rep kernel;
 * see ARCHITECTURE.md ("Geometry kernel decision") for the Open CASCADE evaluation.
 */
export interface Vec2 { x: number; y: number }
export const EPS = 1e-9;
export const v2 = (x: number, y: number): Vec2 => ({ x, y });
export const add = (a: Vec2, b: Vec2): Vec2 => v2(a.x + b.x, a.y + b.y);
export const sub = (a: Vec2, b: Vec2): Vec2 => v2(a.x - b.x, a.y - b.y);
export const scale = (a: Vec2, k: number): Vec2 => v2(a.x * k, a.y * k);
export const dot = (a: Vec2, b: Vec2): number => a.x * b.x + a.y * b.y;
export const cross = (a: Vec2, b: Vec2): number => a.x * b.y - a.y * b.x;
export const len = (a: Vec2): number => Math.hypot(a.x, a.y);
export const dist = (a: Vec2, b: Vec2): number => Math.hypot(a.x - b.x, a.y - b.y);
export const lerp = (a: Vec2, b: Vec2, t: number): Vec2 => v2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
export const normalize = (a: Vec2): Vec2 => { const l = len(a); return l < EPS ? v2(0, 0) : v2(a.x / l, a.y / l); };
export const perp = (a: Vec2): Vec2 => v2(-a.y, a.x);
export const rotate = (p: Vec2, angleRad: number, origin: Vec2 = v2(0, 0)): Vec2 => {
  const c = Math.cos(angleRad), s = Math.sin(angleRad), d = sub(p, origin);
  return v2(origin.x + d.x * c - d.y * s, origin.y + d.x * s + d.y * c);
};
export const nearlyEqual = (a: number, b: number, tol = 1e-6): boolean => Math.abs(a - b) <= tol;

/** Intersection of segments a1-a2 and b1-b2 (touching counts). Parallel/collinear returns null. */
export function segmentIntersection(a1: Vec2, a2: Vec2, b1: Vec2, b2: Vec2): { point: Vec2; t: number; u: number } | null {
  const r = sub(a2, a1), s = sub(b2, b1), den = cross(r, s);
  if (Math.abs(den) < EPS) return null;
  const q = sub(b1, a1), t = cross(q, s) / den, u = cross(q, r) / den;
  const e = 1e-9;
  if (t < -e || t > 1 + e || u < -e || u > 1 + e) return null;
  return { point: v2(a1.x + r.x * t, a1.y + r.y * t), t, u };
}
export function lineIntersection(p1: Vec2, d1: Vec2, p2: Vec2, d2: Vec2): Vec2 | null {
  const den = cross(d1, d2);
  if (Math.abs(den) < EPS) return null;
  const t = cross(sub(p2, p1), d2) / den;
  return v2(p1.x + d1.x * t, p1.y + d1.y * t);
}
/** Projection of p onto segment a-b, clamped. t in [0,1]. */
export function projectOnSegment(p: Vec2, a: Vec2, b: Vec2): { point: Vec2; t: number; distance: number } {
  const ab = sub(b, a), l2 = dot(ab, ab);
  const t = l2 < EPS ? 0 : Math.max(0, Math.min(1, dot(sub(p, a), ab) / l2));
  const point = v2(a.x + ab.x * t, a.y + ab.y * t);
  return { point, t, distance: dist(p, point) };
}
/** Signed area; positive for counter-clockwise polygons. */
export function polygonArea(pts: Vec2[]): number {
  let s = 0;
  for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; s += p.x * q.y - q.x * p.y; }
  return s / 2;
}
export function polygonPerimeter(pts: Vec2[]): number {
  let s = 0; for (let i = 0; i < pts.length; i++) s += dist(pts[i], pts[(i + 1) % pts.length]); return s;
}
export function polygonCentroid(pts: Vec2[]): Vec2 {
  const a = polygonArea(pts);
  if (Math.abs(a) < EPS) { const n = pts.length || 1; return v2(pts.reduce((s, p) => s + p.x, 0) / n, pts.reduce((s, p) => s + p.y, 0) / n); }
  let cx = 0, cy = 0;
  for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length], f = p.x * q.y - q.x * p.y; cx += (p.x + q.x) * f; cy += (p.y + q.y) * f; }
  return v2(cx / (6 * a), cy / (6 * a));
}
export function pointInPolygon(p: Vec2, pts: Vec2[]): boolean {
  let inside = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const a = pts[i], b = pts[j];
    if ((a.y > p.y) !== (b.y > p.y) && p.x < ((b.x - a.x) * (p.y - a.y)) / (b.y - a.y) + a.x) inside = !inside;
  }
  return inside;
}
export interface PolygonCheck { valid: boolean; reason?: string }
/** A polygon is valid if it has >=3 distinct vertices, non-zero area and no self-intersections. */
export function validatePolygon(pts: Vec2[]): PolygonCheck {
  if (pts.length < 3) return { valid: false, reason: 'A polygon needs at least 3 points.' };
  if (pts.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.y))) return { valid: false, reason: 'Polygon has non-finite coordinates.' };
  for (let i = 0; i < pts.length; i++) if (dist(pts[i], pts[(i + 1) % pts.length]) < 1e-6) return { valid: false, reason: 'Polygon has coincident consecutive points.' };
  if (Math.abs(polygonArea(pts)) < 1e-6) return { valid: false, reason: 'Polygon has zero area.' };
  const n = pts.length;
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
    if (j === i + 1 || (i === 0 && j === n - 1)) continue;
    if (segmentIntersection(pts[i], pts[(i + 1) % n], pts[j], pts[(j + 1) % n])) return { valid: false, reason: 'Polygon edges intersect each other.' };
  }
  return { valid: true };
}
/** Plan polygon (4 corners, CCW) of a wall with centre line a-b. Ends can be extended by half thickness for clean corners. */
export function wallPolygon(a: Vec2, b: Vec2, thickness: number, extendStart = false, extendEnd = false): Vec2[] {
  const d = normalize(sub(b, a)), n = perp(d), h = thickness / 2;
  const s = extendStart ? sub(a, scale(d, h)) : a, e = extendEnd ? add(b, scale(d, h)) : b;
  return [add(s, scale(n, -h)), add(e, scale(n, -h)), add(e, scale(n, h)), add(s, scale(n, h))];
}
/** Inward offset of a polygon with per-edge distances (edge i = p[i]->p[i+1]) using mitred corners. */
export function offsetPolygonInward(pts: Vec2[], dists: number[]): Vec2[] {
  const n = pts.length, sgn = polygonArea(pts) >= 0 ? 1 : -1;
  const lines = pts.map((p, i) => {
    const d = normalize(sub(pts[(i + 1) % n], p)), nrm = scale(perp(d), sgn * dists[i]);
    return { p: add(p, nrm), d };
  });
  return pts.map((p, i) => {
    const l0 = lines[(i + n - 1) % n], l1 = lines[i];
    return lineIntersection(l0.p, l0.d, l1.p, l1.d) ?? l1.p;
  });
}
export interface BBox { min: Vec2; max: Vec2 }
export function bboxOf(pts: Vec2[]): BBox | null {
  if (!pts.length) return null;
  const min = v2(Infinity, Infinity), max = v2(-Infinity, -Infinity);
  for (const p of pts) { min.x = Math.min(min.x, p.x); min.y = Math.min(min.y, p.y); max.x = Math.max(max.x, p.x); max.y = Math.max(max.y, p.y); }
  return { min, max };
}

// ---- Units (internal unit is always millimetres) ----
export type LengthUnit = 'mm' | 'cm' | 'm';
const FACTOR: Record<LengthUnit, number> = { mm: 1, cm: 10, m: 1000 };
export const toMM = (value: number, unit: LengthUnit): number => value * FACTOR[unit];
export const fromMM = (mm: number, unit: LengthUnit): number => mm / FACTOR[unit];
export const convertLength = (v: number, from: LengthUnit, to: LengthUnit): number => fromMM(toMM(v, from), to);
export function formatLength(mm: number, unit: LengthUnit, digits?: number): string {
  const d = digits ?? (unit === 'mm' ? 0 : unit === 'cm' ? 1 : 3);
  return `${fromMM(mm, unit).toFixed(d)} ${unit}`;
}
export const formatArea = (mm2: number): string => `${(mm2 / 1e6).toFixed(2)} m²`;
