import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { wallBoxes, type ArchModel, type RObj, type RWall } from '@formax/architecture';

export interface SceneState { visibleLayers: Set<string>; colors: Map<string, string>; selection: Set<string>; hiddenLevels?: Set<string> }
export type CameraMode = 'perspective' | 'orthographic';
interface Entry { sig: string; obj: THREE.Object3D }
const MM = 0.001; // scene units are metres; model data is millimetres

/** Three.js viewport (Z-up). Meshes are generated from resolved architectural data and cached per object (rebuilt only when their data changes). */
export class Viewport3D {
  readonly renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private root = new THREE.Group();
  private persp = new THREE.PerspectiveCamera(45, 1, 0.05, 5000);
  private ortho = new THREE.OrthographicCamera(-10, 10, 10, -10, -5000, 5000);
  private cam: THREE.Camera = this.persp;
  private controls: OrbitControls;
  private entries = new Map<string, Entry>();
  private selection = new Set<string>();
  private needsRender = true;
  private raf = 0; private disposed = false; private orthoSize = 10;
  private ro: ResizeObserver;
  onPick?: (id: string | null, additive: boolean) => void;
  stats = { objects: 0, rebuilt: 0 };

  constructor(private host: HTMLElement, dark = false) {
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false }); // throws if WebGL is unavailable; caller shows an error state
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    host.appendChild(this.renderer.domElement);
    this.renderer.domElement.style.touchAction = 'none';
    this.scene.up.set(0, 0, 1); this.persp.up.set(0, 0, 1); this.ortho.up.set(0, 0, 1);
    this.root.scale.setScalar(MM); this.scene.add(this.root);
    this.scene.add(new THREE.HemisphereLight(0xffffff, 0x8a8f99, 1.25));
    const sun = new THREE.DirectionalLight(0xffffff, 1.6); sun.position.set(30, -40, 60); this.scene.add(sun);
    const grid = new THREE.GridHelper(100, 100, 0x888888, 0xbbbbbb); grid.rotation.x = Math.PI / 2; (grid.material as THREE.Material).transparent = true; (grid.material as THREE.Material).opacity = 0.45; grid.name = 'grid'; grid.position.z = -0.25; /* below slabs to avoid z-fighting with floors */ this.scene.add(grid);
    const axes = new THREE.AxesHelper(3); axes.name = 'axes'; this.scene.add(axes);
    this.setDark(dark);
    this.controls = new OrbitControls(this.persp, this.renderer.domElement);
    this.controls.mouseButtons = { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    this.controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }; // one finger orbits, two fingers pinch-zoom + pan
    this.controls.addEventListener('change', () => (this.needsRender = true));
    this.persp.position.set(14, -16, 11); this.controls.update();
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(host); this.resize();
    const el = this.renderer.domElement; let down: { x: number; y: number; t: number } | null = null;
    el.addEventListener('pointerdown', (e) => { down = { x: e.clientX, y: e.clientY, t: performance.now() }; });
    el.addEventListener('pointerup', (e) => {
      if (!down || e.button !== 0) return; const moved = Math.hypot(e.clientX - down.x, e.clientY - down.y); down = null;
      if (moved < 5) this.pick(e);
    });
    const loop = () => { if (this.disposed) return; this.raf = requestAnimationFrame(loop); if (this.needsRender) { this.needsRender = false; this.renderer.render(this.scene, this.cam); } };
    loop();
  }
  setDark(dark: boolean) { this.scene.background = new THREE.Color(dark ? 0x15181c : 0xeceff2); this.needsRender = true; }
  private resize() {
    const w = Math.max(1, this.host.clientWidth), h = Math.max(1, this.host.clientHeight);
    this.renderer.setSize(w, h, false); this.renderer.domElement.style.width = '100%'; this.renderer.domElement.style.height = '100%';
    const a = w / h; this.persp.aspect = a; this.persp.updateProjectionMatrix();
    const s = this.orthoSize; this.ortho.left = -s * a; this.ortho.right = s * a; this.ortho.top = s; this.ortho.bottom = -s; this.ortho.updateProjectionMatrix(); this.needsRender = true;
  }
  setCameraMode(mode: CameraMode) {
    const from = this.cam, to = mode === 'perspective' ? this.persp : this.ortho; if (from === to) return;
    const target = this.controls.target.clone(), dir = from.position.clone().sub(target), dist = dir.length();
    to.position.copy(target).add(dir); to.up.set(0, 0, 1);
    if (mode === 'orthographic') { this.orthoSize = Math.max(0.5, dist * Math.tan(THREE.MathUtils.degToRad(this.persp.fov / 2))); this.ortho.zoom = 1; this.resize(); }
    this.cam = to; this.controls.object = to; this.controls.update(); this.needsRender = true;
  }
  get mode(): CameraMode { return this.cam === this.persp ? 'perspective' : 'orthographic'; }
  frame(preset: 'iso' | 'top' = 'iso') {
    const box = new THREE.Box3().setFromObject(this.root);
    if (box.isEmpty()) box.set(new THREE.Vector3(-5, -5, 0), new THREE.Vector3(5, 5, 3));
    const c = box.getCenter(new THREE.Vector3()), r = Math.max(2, box.getSize(new THREE.Vector3()).length() / 2);
    const dir = preset === 'top' ? new THREE.Vector3(0.0001, -0.0001, 1) : new THREE.Vector3(1, -1.25, 0.9).normalize();
    this.controls.target.copy(c); this.cam.position.copy(c).add(dir.multiplyScalar(r * 2.4));
    if (this.cam === this.ortho) { this.orthoSize = r * 1.2; this.ortho.zoom = 1; this.resize(); }
    this.persp.far = r * 50; this.persp.updateProjectionMatrix(); this.controls.update(); this.needsRender = true;
  }
  private pick(e: PointerEvent) {
    const r = this.renderer.domElement.getBoundingClientRect(), ndc = new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    const ray = new THREE.Raycaster(); ray.setFromCamera(ndc, this.cam);
    const hit = ray.intersectObjects(this.root.children, true).find((h) => { let o: THREE.Object3D | null = h.object; while (o) { if (o.userData.id) return true; o = o.parent; } return false; });
    let id: string | null = null; let o: THREE.Object3D | null = hit?.object ?? null; while (o) { if (o.userData.id) { id = o.userData.id as string; break; } o = o.parent; }
    this.onPick?.(id, e.shiftKey);
  }
  /** Sync scene with the model: only objects whose resolved data / colour changed are rebuilt. */
  update(model: ArchModel, st: SceneState) {
    const seen = new Set<string>(); this.stats.rebuilt = 0;
    for (const o of model.resolved.values()) {
      if (!['wall', 'room', 'slab', 'roof', 'column', 'beam'].includes(o.type)) continue;
      if (!st.visibleLayers.has(o.layer) || st.hiddenLevels?.has(o.level)) continue;
      seen.add(o.id);
      const color = st.colors.get(o.material) ?? '#cccccc';
      const extra = o.type === 'wall' ? JSON.stringify(model.openingsOf(o.id).map((x) => [x.type, x.offset, x.width, x.height, x.sill])) : '';
      const sig = `${color}|${JSON.stringify(o)}|${extra}`, cur = this.entries.get(o.id);
      if (cur?.sig === sig) continue;
      if (cur) this.discard(cur.obj);
      const obj = this.build(o, model, color); obj.userData.id = o.id; this.root.add(obj); this.entries.set(o.id, { sig, obj }); this.stats.rebuilt++;
    }
    for (const [id, e] of [...this.entries]) if (!seen.has(id)) { this.discard(e.obj); this.entries.delete(id); this.stats.rebuilt++; }
    this.stats.objects = this.entries.size; this.setSelection(st.selection, true);
    if (this.stats.rebuilt) this.needsRender = true;
  }
  setSelection(sel: Set<string>, force = false) {
    if (!force && sel.size === this.selection.size && [...sel].every((s) => this.selection.has(s))) return;
    this.selection = new Set(sel);
    for (const [id, e] of this.entries) e.obj.traverse((m) => { const mat = (m as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined; if (mat && 'emissive' in mat && !m.userData.glass) mat.emissive.setHex(sel.has(id) ? 0x1b5fd1 : 0x000000); });
    this.needsRender = true;
  }
  private discard(o: THREE.Object3D) { this.root.remove(o); o.traverse((m) => { const mesh = m as THREE.Mesh; mesh.geometry?.dispose(); const mt = mesh.material; if (mt) (Array.isArray(mt) ? mt : [mt]).forEach((x) => x.dispose()); }); }
  private mesh(g: THREE.BufferGeometry, color: string, edges = true, opts: Partial<THREE.MeshStandardMaterialParameters> = {}): THREE.Object3D {
    const grp = new THREE.Group(); grp.add(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color, roughness: 0.85, metalness: 0, polygonOffset: true, polygonOffsetFactor: 1, polygonOffsetUnits: 1, ...opts })));
    if (edges) grp.add(new THREE.LineSegments(new THREE.EdgesGeometry(g, 30), new THREE.LineBasicMaterial({ color: 0x222222, transparent: true, opacity: 0.55 })));
    return grp;
  }
  private poly(pts: { x: number; y: number }[], depth: number, z: number, color: string): THREE.Object3D {
    const g = new THREE.ExtrudeGeometry(new THREE.Shape(pts.map((p) => new THREE.Vector2(p.x, p.y))), { depth, bevelEnabled: false }); g.translate(0, 0, z); return this.mesh(g, color);
  }
  private build(o: RObj, model: ArchModel, color: string): THREE.Object3D {
    switch (o.type) {
      case 'wall': return this.buildWall(o, model, color);
      case 'room': return this.poly(o.net, 12, o.z, color);
      case 'slab': return this.poly(o.points, o.thickness, o.top - o.thickness, color);
      case 'roof': return this.poly(o.points, o.thickness, o.top - o.thickness, color);
      case 'column': { const g = new THREE.BoxGeometry(o.width, o.depth, o.height); g.translate(o.p.x, o.p.y, o.z + o.height / 2); return this.mesh(g, color); }
      case 'beam': {
        const dx = o.b.x - o.a.x, dy = o.b.y - o.a.y, L = Math.hypot(dx, dy), g = new THREE.BoxGeometry(L, o.width, o.depth);
        const m = this.mesh(g, color); m.rotation.z = Math.atan2(dy, dx); m.position.set((o.a.x + o.b.x) / 2, (o.a.y + o.b.y) / 2, o.top - o.depth / 2); return m;
      }
      default: return new THREE.Group();
    }
  }
  private buildWall(w: RWall, model: ArchModel, color: string): THREE.Object3D {
    const grp = new THREE.Group(), ops = model.openingsOf(w.id), ang = Math.atan2(w.b.y - w.a.y, w.b.x - w.a.x);
    grp.position.set(w.a.x, w.a.y, w.z); grp.rotation.z = ang;
    for (const b of wallBoxes(w, ops)) {
      const g = new THREE.BoxGeometry(b.x1 - b.x0, w.thickness, b.z1 - b.z0); g.translate((b.x0 + b.x1) / 2, 0, (b.z0 + b.z1) / 2); grp.add(this.mesh(g, color));
    }
    for (const o of ops) {
      const isWin = o.type === 'window', t = isWin ? 30 : 45, g = new THREE.BoxGeometry(o.width, t, o.height); g.translate(o.offset, 0, o.sill + o.height / 2);
      const m = this.mesh(g, isWin ? '#9cc7dc' : '#8b6b45', !isWin, isWin ? { transparent: true, opacity: 0.38, roughness: 0.1 } : {}); if (isWin) m.traverse((x) => (x.userData.glass = true));
      grp.add(m);
    }
    return grp;
  }
  dispose() {
    this.disposed = true; cancelAnimationFrame(this.raf); this.ro.disconnect(); this.controls.dispose();
    for (const e of this.entries.values()) this.discard(e.obj); this.entries.clear();
    this.renderer.dispose(); this.renderer.domElement.remove();
  }
}
