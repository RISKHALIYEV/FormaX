import { ArchModel, newErrors, type ChangeResult, type Issue, type Project, defaultProject } from '@formax/architecture';

export interface TxResult<T = unknown> { ok: boolean; issues: Issue[]; error?: string; value?: T }
interface Snapshot { label: string; project: Project }
const LIMIT = 200;

/**
 * Document session: owns the project, the derived ArchModel, undo/redo and transactions.
 * No UI dependency. Every change is a transaction: if it would introduce any new error the previous valid state is kept.
 */
export class Session {
  project: Project;
  model: ArchModel;
  private undoStack: Snapshot[] = [];
  private redoStack: Snapshot[] = [];
  private listeners = new Set<() => void>();
  version = 0;
  dirty = false;
  lastIssues: Issue[] = [];
  constructor(project: Project = defaultProject()) { this.project = project; this.model = new ArchModel(project); }

  subscribe = (fn: () => void) => { this.listeners.add(fn); return () => { this.listeners.delete(fn); }; };
  getVersion = () => this.version;
  private touch() { this.version++; this.listeners.forEach((l) => l()); }
  get canUndo() { return this.undoStack.length > 0; }
  get canRedo() { return this.redoStack.length > 0; }
  get undoLabel() { return this.undoStack[this.undoStack.length - 1]?.label; }
  get redoLabel() { return this.redoStack[this.redoStack.length - 1]?.label; }

  /** Replace the whole document (open / new). Clears history. */
  load(project: Project, dirty = false) { this.project = project; this.model = new ArchModel(project); this.undoStack = []; this.redoStack = []; this.dirty = dirty; this.lastIssues = this.model.issues; this.touch(); }
  markSaved() { this.dirty = false; this.touch(); }

  /** Run a mutation on a copy of the project. Rejected (state untouched) when it throws or introduces new errors. */
  commit<T>(label: string, mutate: (p: Project, m: ArchModel) => T): TxResult<T> {
    const draft = structuredClone(this.project);
    let value: T;
    try { value = mutate(draft, this.model); } catch (e) { return this.fail([], (e as Error).message); }
    const next = new ArchModel(draft);
    const bad = newErrors(this.model.issues, next.issues);
    if (bad.length) return this.fail(bad, bad[0].message);
    this.push(label); this.project = draft; this.model = next; this.dirty = true; this.lastIssues = next.issues; this.redoStack = []; this.touch();
    return { ok: true, issues: next.issues, value };
  }
  /** Incremental parameter transaction (only dependent nodes are recomputed). */
  setParameter(name: string, expr: string): TxResult<ChangeResult> {
    const before = structuredClone(this.project), old = this.project.parameters.find((q) => q.name === name)?.expr ?? '';
    if (old === expr) return { ok: true, issues: this.model.issues };
    const res = this.model.changeParameter(name, expr);
    if (!res.ok) return this.fail(res.issues, res.issues[0]?.message ?? 'Change rejected', res);
    this.undoStack.push({ label: `Set ${name}`, project: before }); if (this.undoStack.length > LIMIT) this.undoStack.shift();
    this.project.parameterHistory.push({ time: new Date().toISOString(), name, from: old, to: expr });
    if (this.project.parameterHistory.length > 500) this.project.parameterHistory.shift();
    this.redoStack = []; this.dirty = true; this.lastIssues = res.issues; this.touch();
    return { ok: true, issues: res.issues, value: res };
  }
  undo(): boolean {
    const s = this.undoStack.pop(); if (!s) return false;
    this.redoStack.push({ label: s.label, project: this.project }); this.restore(s.project); return true;
  }
  redo(): boolean {
    const s = this.redoStack.pop(); if (!s) return false;
    this.undoStack.push({ label: s.label, project: this.project }); this.restore(s.project); return true;
  }
  private restore(p: Project) { this.project = p; this.model = new ArchModel(p); this.dirty = true; this.lastIssues = this.model.issues; this.touch(); }
  private push(label: string) { this.undoStack.push({ label, project: this.project }); if (this.undoStack.length > LIMIT) this.undoStack.shift(); }
  private fail<T>(issues: Issue[], error: string, value?: T): TxResult<T> {
    this.lastIssues = issues.length ? issues : this.model.issues; this.touch(); return { ok: false, issues, error, value };
  }
}
export * from '@formax/architecture';
