import { isValidParamName, type Project } from '@formax/architecture';

export const FORMAT_VERSION = 1;
export const APP_VERSION = '0.1.0';
export interface Asset { id: string; name: string; mime: string; data: string; checksum: string }
export interface FormaxFile {
  format: 'formax'; schemaVersion: number; app: { name: string; version: string };
  metadata: { name: string; created: string; modified: string };
  project: Project; assets: Asset[]; integrity: { algorithm: 'cyrb53'; hash: string };
}
/** 53-bit non-cryptographic hash (cyrb53). Detects corruption/truncation; it is NOT tamper protection. */
export function cyrb53(str: string, seed = 0): string {
  let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
  for (let i = 0; i < str.length; i++) { const ch = str.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(14, '0');
}
export function canonical(v: unknown): string {
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v as object).sort().map((k) => `${JSON.stringify(k)}:${canonical((v as Record<string, unknown>)[k])}`).join(',')}}`;
  return JSON.stringify(v);
}
const bodyHash = (schemaVersion: number, project: unknown, assets: unknown) => cyrb53(canonical({ schemaVersion, project, assets }));

export function serializeProject(project: Project, opts: { assets?: Asset[]; created?: string; now?: string } = {}): string {
  const assets = opts.assets ?? [], now = opts.now ?? new Date().toISOString();
  const file: FormaxFile = {
    format: 'formax', schemaVersion: FORMAT_VERSION, app: { name: 'FormaX', version: APP_VERSION },
    metadata: { name: project.name, created: opts.created ?? now, modified: now },
    project, assets, integrity: { algorithm: 'cyrb53', hash: bodyHash(FORMAT_VERSION, project, assets) },
  };
  return JSON.stringify(file, null, 1);
}
export function makeAsset(id: string, name: string, mime: string, base64: string): Asset { return { id, name, mime, data: base64, checksum: cyrb53(base64) }; }

type R = Record<string, unknown>;
const isObj = (v: unknown): v is R => typeof v === 'object' && v !== null && !Array.isArray(v);
const isExpr = (v: unknown) => (typeof v === 'number' && Number.isFinite(v)) || (typeof v === 'string' && v.trim() !== '');
const TYPES = ['wall', 'room', 'door', 'window', 'slab', 'roof', 'column', 'beam', 'dimension', 'line', 'polyline', 'circle'];
/** Structural validation of an untrusted project object. Returns a list of problems (empty = valid). */
export function validateProjectShape(p: unknown): string[] {
  const e: string[] = [];
  if (!isObj(p)) return ['project is not an object'];
  for (const k of ['id', 'name']) if (typeof p[k] !== 'string') e.push(`project.${k} must be a string`);
  if (!['mm', 'cm', 'm'].includes(p.units as string)) e.push('project.units must be mm, cm or m');
  for (const k of ['parameters', 'constraints', 'levels', 'layers', 'materials', 'objects', 'parameterHistory']) if (!Array.isArray(p[k])) e.push(`project.${k} must be an array`);
  if (e.length) return e;
  const dupe = (arr: R[], key: string, what: string) => { const s = new Set<unknown>(); for (const x of arr) { if (s.has(x[key])) e.push(`duplicate ${what} '${String(x[key])}'`); s.add(x[key]); } };
  const params = p.parameters as R[]; params.forEach((q, i) => { if (!isObj(q) || typeof q.name !== 'string' || typeof q.expr !== 'string') e.push(`parameters[${i}] needs string name and expr`); else if (!isValidParamName(q.name)) e.push(`parameters[${i}] has an invalid name '${q.name}'`); });
  dupe(params, 'name', 'parameter');
  (p.constraints as R[]).forEach((q, i) => { if (!isObj(q) || typeof q.id !== 'string' || typeof q.expr !== 'string' || typeof q.message !== 'string') e.push(`constraints[${i}] is malformed`); });
  const levels = p.levels as R[]; levels.forEach((l, i) => { if (!isObj(l) || typeof l.id !== 'string' || !isExpr(l.elevation) || !isExpr(l.height)) e.push(`levels[${i}] is malformed`); });
  (p.layers as R[]).forEach((l, i) => { if (!isObj(l) || typeof l.id !== 'string' || typeof l.visible !== 'boolean') e.push(`layers[${i}] is malformed`); });
  (p.materials as R[]).forEach((m, i) => { if (!isObj(m) || typeof m.id !== 'string' || typeof m.color !== 'string') e.push(`materials[${i}] is malformed`); });
  const objs = p.objects as R[]; dupe(objs, 'id', 'object id');
  const levelIds = new Set(levels.map((l) => l.id)), ids = new Set(objs.map((o) => o.id));
  const pt = (v: unknown) => isObj(v) && isExpr(v.x) && isExpr(v.y);
  objs.forEach((o, i) => {
    const t = `objects[${i}]`;
    if (!isObj(o) || typeof o.id !== 'string' || !TYPES.includes(o.type as string)) { e.push(`${t} has an unknown type`); return; }
    for (const k of ['name', 'layer', 'level', 'material']) if (typeof o[k] !== 'string') e.push(`${t}.${k} must be a string`);
    if (!levelIds.has(o.level)) e.push(`${t} (${String(o.id)}) refers to missing level '${String(o.level)}'`);
    const needPts: Record<string, string[]> = { wall: ['a', 'b'], beam: ['a', 'b'], dimension: ['a', 'b'], line: ['a', 'b'], column: ['p'], circle: ['c'] };
    for (const k of needPts[o.type as string] ?? []) if (!pt(o[k])) e.push(`${t}.${k} must be a point`);
    if (['room', 'slab', 'roof', 'polyline'].includes(o.type as string) && !(Array.isArray(o.points) && (o.points as unknown[]).every(pt))) e.push(`${t}.points must be a list of points`);
    const need: Record<string, string[]> = { wall: ['thickness', 'height'], door: ['offset', 'width', 'height', 'sill'], window: ['offset', 'width', 'height', 'sill'], slab: ['thickness', 'top'], roof: ['thickness', 'elevation'], column: ['width', 'depth', 'height'], beam: ['width', 'depth', 'elevation'], dimension: ['offset'], circle: ['r'] };
    for (const k of need[o.type as string] ?? []) if (!isExpr(o[k])) e.push(`${t}.${k} must be a number or formula`);
    if ((o.type === 'door' || o.type === 'window') && !ids.has(o.host)) e.push(`${t} (${String(o.id)}) refers to missing host wall '${String(o.host)}'`);
  });
  return e;
}

export type ParseResult = { ok: true; project: Project; assets: Asset[]; warnings: string[]; metadata: FormaxFile['metadata'] } | { ok: false; errors: string[] };
/** Safe loader: never throws; refuses corrupted, future-version or malformed files (unless `ignoreIntegrity` for recovery). */
export function parseProjectFile(text: string, opts: { ignoreIntegrity?: boolean } = {}): ParseResult {
  let raw: unknown;
  try { raw = JSON.parse(text); } catch (e) { return { ok: false, errors: [`Not a valid FormaX file (JSON error: ${(e as Error).message}).`] }; }
  if (!isObj(raw) || raw.format !== 'formax') return { ok: false, errors: ['This is not a FormaX project file.'] };
  const v = raw.schemaVersion;
  if (typeof v !== 'number' || !Number.isInteger(v) || v < 1) return { ok: false, errors: ['Missing or invalid schemaVersion.'] };
  if (v > FORMAT_VERSION) return { ok: false, errors: [`File schema version ${v} is newer than this app supports (${FORMAT_VERSION}). Update FormaX.`] };
  const warnings: string[] = [];
  // Migrations from older schema versions would run here (none exist yet: schema 1 is the first version).
  const errors = validateProjectShape(raw.project);
  if (errors.length) return { ok: false, errors };
  const assets = Array.isArray(raw.assets) ? (raw.assets as Asset[]) : [];
  for (const a of assets) if (!isObj(a) || typeof a.data !== 'string' || cyrb53(a.data) !== a.checksum) errors.push(`Asset '${String((a as unknown as R)?.id)}' is corrupted (checksum mismatch).`);
  if (errors.length) return { ok: false, errors };
  const integ = raw.integrity as R | undefined;
  if (!integ || integ.hash !== bodyHash(v, raw.project, assets)) {
    if (!opts.ignoreIntegrity) return { ok: false, errors: ['Integrity check failed: the file is corrupted or was modified outside FormaX.'] };
    warnings.push('Integrity check failed; file loaded in recovery mode.');
  }
  const md = isObj(raw.metadata) ? (raw.metadata as unknown as FormaxFile['metadata']) : { name: (raw.project as Project).name, created: '', modified: '' };
  return { ok: true, project: raw.project as Project, assets, warnings, metadata: md };
}
