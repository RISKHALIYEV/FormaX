import { Engine, type NodeInput } from '@formax/parametric';
import { Vec2, v2, wallPolygon, polygonArea, polygonPerimeter, validatePolygon, offsetPolygonInward, sub, normalize, cross, dot, projectOnSegment, dist } from '@formax/geometry';
import type { ArchObject, Expr, Issue, Project, WallObj, OpeningObj } from './types';
import { exprPaths, getPath } from './fields';

interface RB { id: string; name: string; layer: string; level: string; material: string; z: number; levelHeight: number }
export interface RWall extends RB { type: 'wall'; a: Vec2; b: Vec2; thickness: number; height: number; length: number; polygon: Vec2[]; extendStart: boolean; extendEnd: boolean }
export interface ROpening extends RB { type: 'door' | 'window'; host: string; offset: number; width: number; height: number; sill: number }
export interface RRoom extends RB { type: 'room'; points: Vec2[]; net: Vec2[]; grossArea: number; netArea: number; perimeter: number }
export interface RSlab extends RB { type: 'slab'; points: Vec2[]; thickness: number; top: number }
export interface RRoof extends RB { type: 'roof'; points: Vec2[]; thickness: number; top: number }
export interface RColumn extends RB { type: 'column'; p: Vec2; width: number; depth: number; height: number }
export interface RBeam extends RB { type: 'beam'; a: Vec2; b: Vec2; width: number; depth: number; top: number }
export interface RDim extends RB { type: 'dimension'; a: Vec2; b: Vec2; offset: number; length: number }
export interface RLine extends RB { type: 'line'; a: Vec2; b: Vec2 }
export interface RPoly extends RB { type: 'polyline'; points: Vec2[] }
export interface RCircle extends RB { type: 'circle'; c: Vec2; r: number }
export type RObj = RWall | ROpening | RRoom | RSlab | RRoof | RColumn | RBeam | RDim | RLine | RPoly | RCircle;

type OfType<T extends RObj['type']> = RObj extends infer U ? (U extends RObj ? (T extends U['type'] ? U : never) : never) : never;
export interface ChangeResult { ok: boolean; issues: Issue[]; recomputed: string[]; affectedObjects: string[] }
export const issueKey = (i: Issue) => `${i.severity}|${i.objectId ?? ''}|${i.message}`;
/** Error issues present in `next` that were not already present in `prev`. */
export const newErrors = (prev: Issue[], next: Issue[]): Issue[] => {
  const old = new Set(prev.map(issueKey));
  return next.filter((i) => i.severity === 'error' && !old.has(issueKey(i)));
};

/** Resolved (numeric) view of a Project, plus the incremental parametric engine that drives it. */
export class ArchModel {
  readonly engine = new Engine();
  resolved = new Map<string, RObj>();
  levels = new Map<string, { elevation: number; height: number; name: string }>();
  issues: Issue[] = [];
  constructor(public project: Project) { this.rebuild(); }

  rebuild(): void {
    const defs: Record<string, NodeInput> = {};
    const p = this.project;
    for (const q of p.parameters) defs[q.name] = { expr: q.expr, referenceable: true };
    for (const c of p.constraints) defs[`constraint:${c.id}`] = { expr: c.expr, referenceable: false };
    for (const l of p.levels) for (const f of ['elevation', 'height'] as const) { const e = l[f]; if (typeof e === 'string') defs[`level:${l.id}.${f}`] = { expr: e, referenceable: false }; }
    for (const o of p.objects) for (const path of exprPaths(o)) { const e = getPath(o, path); if (typeof e === 'string') defs[`${o.id}.${path}`] = { expr: e, referenceable: false }; }
    this.engine.load(defs);
    this.resolveAll();
    this.issues = this.validate();
  }
  private num(id: string, path: string, e: Expr, fallback = NaN): number {
    if (typeof e === 'number') return Number.isFinite(e) ? e : fallback;
    const v = this.engine.value(`${id}.${path}`);
    return typeof v === 'number' ? v : fallback;
  }
  private resolveLevels() {
    this.levels.clear();
    for (const l of this.project.levels) {
      const el = this.num(`level:${l.id}`, 'elevation', l.elevation), h = this.num(`level:${l.id}`, 'height', l.height);
      this.levels.set(l.id, { elevation: el, height: h, name: l.name });
    }
  }
  private resolveAll() {
    this.resolveLevels(); this.resolved.clear();
    for (const o of this.project.objects) if (o.type !== 'room') this.resolveOne(o);
    for (const o of this.project.objects) if (o.type === 'room') this.resolveOne(o);
  }
  private resolveOne(o: ArchObject): void {
    this.resolved.delete(o.id);
    const lv = this.levels.get(o.level); if (!lv || !Number.isFinite(lv.elevation) || !Number.isFinite(lv.height)) return;
    const n = (path: string): number => this.num(o.id, path, getPath(o, path));
    const pt = (k: string): Vec2 => v2(n(`${k}.x`), n(`${k}.y`));
    const pts = (k: string, arr: unknown[]): Vec2[] => arr.map((_, i) => pt(`${k}.${i}`));
    const ok = (...v: number[]) => v.every(Number.isFinite);
    const b: RB = { id: o.id, name: o.name, layer: o.layer, level: o.level, material: o.material, z: lv.elevation, levelHeight: lv.height };
    let r: RObj | null = null;
    switch (o.type) {
      case 'wall': {
        const a = pt('a'), bb = pt('b'), t = n('thickness'), h = n('height');
        if (ok(a.x, a.y, bb.x, bb.y, t, h)) r = { ...b, type: 'wall', a, b: bb, thickness: t, height: h, length: dist(a, bb), polygon: wallPolygon(a, bb, t, o.extendStart, o.extendEnd), extendStart: o.extendStart, extendEnd: o.extendEnd };
        break;
      }
      case 'door': case 'window': {
        const off = n('offset'), w = n('width'), h = n('height'), s = n('sill');
        if (ok(off, w, h, s)) r = { ...b, type: o.type, host: o.host, offset: off, width: w, height: h, sill: s };
        break;
      }
      case 'room': {
        const points = pts('points', o.points);
        if (points.every((q) => ok(q.x, q.y)) && points.length >= 3) {
          const walls = [...this.resolved.values()].filter((x): x is RWall => x.type === 'wall' && x.level === o.level);
          const insets = points.map((p0, i) => roomEdgeInset(p0, points[(i + 1) % points.length], walls));
          const net = offsetPolygonInward(points, insets);
          r = { ...b, type: 'room', points, net, grossArea: Math.abs(polygonArea(points)), netArea: Math.abs(polygonArea(net)), perimeter: polygonPerimeter(net) };
        }
        break;
      }
      case 'slab': { const points = pts('points', o.points), t = n('thickness'), top = n('top'); if (points.every((q) => ok(q.x, q.y)) && ok(t, top)) r = { ...b, type: 'slab', points, thickness: t, top: lv.elevation + top }; break; }
      case 'roof': { const points = pts('points', o.points), t = n('thickness'), el = n('elevation'); if (points.every((q) => ok(q.x, q.y)) && ok(t, el)) r = { ...b, type: 'roof', points, thickness: t, top: lv.elevation + el + t }; break; }
      case 'column': { const p = pt('p'), w = n('width'), d = n('depth'), h = n('height'); if (ok(p.x, p.y, w, d, h)) r = { ...b, type: 'column', p, width: w, depth: d, height: h }; break; }
      case 'beam': { const a = pt('a'), bb = pt('b'), w = n('width'), d = n('depth'), el = n('elevation'); if (ok(a.x, a.y, bb.x, bb.y, w, d, el)) r = { ...b, type: 'beam', a, b: bb, width: w, depth: d, top: lv.elevation + el }; break; }
      case 'dimension': { const a = pt('a'), bb = pt('b'), off = n('offset'); if (ok(a.x, a.y, bb.x, bb.y, off)) r = { ...b, type: 'dimension', a, b: bb, offset: off, length: dist(a, bb) }; break; }
      case 'line': { const a = pt('a'), bb = pt('b'); if (ok(a.x, a.y, bb.x, bb.y)) r = { ...b, type: 'line', a, b: bb }; break; }
      case 'polyline': { const points = pts('points', o.points); if (points.every((q) => ok(q.x, q.y))) r = { ...b, type: 'polyline', points }; break; }
      case 'circle': { const c = pt('c'), rad = n('r'); if (ok(c.x, c.y, rad)) r = { ...b, type: 'circle', c, r: rad }; break; }
    }
    if (r) this.resolved.set(o.id, r);
  }
  get<T extends RObj = RObj>(id: string): T | undefined { return this.resolved.get(id) as T | undefined; }
  byType<T extends RObj['type']>(t: T, level?: string): OfType<T>[] {
    return [...this.resolved.values()].filter((o) => o.type === t && (!level || o.level === level)) as OfType<T>[];
  }
  openingsOf(wallId: string): ROpening[] { return [...this.resolved.values()].filter((o): o is ROpening => (o.type === 'door' || o.type === 'window') && o.host === wallId); }

  validate(): Issue[] {
    const out: Issue[] = [];
    const eng = this.engine.errors;
    for (const [id, msg] of Object.entries(eng)) {
      if (id.startsWith('constraint:')) { const c = this.project.constraints.find((x) => `constraint:${x.id}` === id); out.push({ severity: 'error', message: `Constraint '${c?.name ?? id}': ${msg}` }); }
      else if (id.startsWith('level:')) out.push({ severity: 'error', message: `Level ${id.slice(6)}: ${msg}` });
      else if (id.includes('.')) { const oid = id.split('.')[0]; out.push({ severity: 'error', objectId: oid, message: `${oid} › ${id.slice(oid.length + 1)}: ${msg}` }); }
      else out.push({ severity: 'error', message: `Parameter '${id}': ${msg}` });
    }
    for (const c of this.project.constraints) {
      const v = this.engine.value(`constraint:${c.id}`);
      if (v === false) out.push({ severity: 'error', message: `Constraint violated – ${c.name}: ${c.message}` });
      else if (typeof v === 'number') out.push({ severity: 'error', message: `Constraint '${c.name}' must evaluate to true/false.` });
    }
    // numeric-type problems for fields that evaluated to booleans
    for (const o of this.project.objects) if (!this.resolved.has(o.id) && !out.some((i) => i.objectId === o.id)) {
      out.push({ severity: 'error', objectId: o.id, message: `${o.id} (${o.name}) has fields that do not evaluate to numbers, or its level is invalid.` });
    }
    const layerIds = new Set(this.project.layers.map((l) => l.id));
    for (const o of this.resolved.values()) {
      const lbl = `${o.id} (${o.name})`;
      if (!layerIds.has(o.layer)) out.push({ severity: 'warning', objectId: o.id, message: `${lbl}: unknown layer '${o.layer}'.` });
      switch (o.type) {
        case 'wall':
          if (o.length < 1) out.push({ severity: 'error', objectId: o.id, message: `Wall ${lbl} has zero length.` });
          if (o.thickness <= 0) out.push({ severity: 'error', objectId: o.id, message: `Wall ${lbl} thickness must be positive (is ${o.thickness} mm).` });
          if (o.height <= 0) out.push({ severity: 'error', objectId: o.id, message: `Wall ${lbl} height must be positive (is ${o.height} mm).` });
          break;
        case 'door': case 'window': {
          const w = this.resolved.get(o.host);
          if (o.width <= 0 || o.height <= 0 || o.sill < 0) { out.push({ severity: 'error', objectId: o.id, message: `${lbl}: width and height must be positive and sill must not be negative.` }); break; }
          if (!w || w.type !== 'wall') { out.push({ severity: 'error', objectId: o.id, message: `${lbl}: host wall '${o.host}' does not exist.` }); break; }
          if (o.offset - o.width / 2 < -1e-6 || o.offset + o.width / 2 > w.length + 1e-6)
            out.push({ severity: 'error', objectId: o.id, message: `${o.type === 'door' ? 'Door' : 'Window'} ${lbl} (${Math.round(o.width)} mm wide, centred at ${Math.round(o.offset)} mm) does not fit on wall ${w.id}, which is ${Math.round(w.length)} mm long.` });
          if (o.sill + o.height > w.height + 1e-6) out.push({ severity: 'error', objectId: o.id, message: `${lbl}: top at ${Math.round(o.sill + o.height)} mm exceeds the height of wall ${w.id} (${Math.round(w.height)} mm).` });
          for (const q of this.openingsOf(w.id)) if (q.id < o.id && Math.abs(q.offset - o.offset) < (q.width + o.width) / 2 - 1e-6)
            out.push({ severity: 'error', objectId: o.id, message: `${lbl} overlaps ${q.id} on wall ${w.id}.` });
          break;
        }
        case 'room': { const c = validatePolygon(o.points); if (!c.valid) out.push({ severity: 'error', objectId: o.id, message: `Room ${lbl}: ${c.reason}` }); else if (!validatePolygon(o.net).valid || o.netArea <= 0) out.push({ severity: 'error', objectId: o.id, message: `Room ${lbl}: boundary collapses once wall thickness is deducted.` }); break; }
        case 'slab': case 'roof': { const c = validatePolygon(o.points); if (!c.valid) out.push({ severity: 'error', objectId: o.id, message: `${o.type} ${lbl}: ${c.reason}` }); if (o.thickness <= 0) out.push({ severity: 'error', objectId: o.id, message: `${lbl}: thickness must be positive.` }); break; }
        case 'column': if (o.width <= 0 || o.depth <= 0 || o.height <= 0) out.push({ severity: 'error', objectId: o.id, message: `Column ${lbl} dimensions must be positive.` }); break;
        case 'beam': if (o.width <= 0 || o.depth <= 0 || dist(o.a, o.b) < 1) out.push({ severity: 'error', objectId: o.id, message: `Beam ${lbl} has invalid dimensions or zero length.` }); break;
        case 'circle': if (o.r <= 0) out.push({ severity: 'error', objectId: o.id, message: `Circle ${lbl} radius must be positive.` }); break;
        default: break;
      }
    }
    for (const o of this.project.objects) {
      if (o.type === 'door' || o.type === 'window') {
        const lv = this.resolved.get((o as OpeningObj).host); if (lv && lv.level !== o.level) out.push({ severity: 'error', objectId: o.id, message: `${o.id}: host wall is on a different level.` });
      }
    }
    return out;
  }

  /**
   * Incremental parameter edit: only nodes that depend on `name` are re-evaluated and only the objects owning them are re-resolved.
   * If the new value introduces any new error, everything is reverted and the previous valid state is kept.
   */
  changeParameter(name: string, expr: string): ChangeResult {
    const p = this.project.parameters.find((q) => q.name === name);
    if (!p) return { ok: false, issues: [{ severity: 'error', message: `Unknown parameter '${name}'.` }], recomputed: [], affectedObjects: [] };
    const old = p.expr, prevIssues = this.issues, prevErrors = this.engine.errors;
    const res = this.engine.update({ [name]: { expr, referenceable: true } });
    const fresh = Object.entries(res.errors).filter(([id, m]) => prevErrors[id] !== m);
    const revert = (affected: string[]) => { p.expr = old; this.engine.update({ [name]: { expr: old, referenceable: true } }); this.reresolve(affected); this.issues = prevIssues; };
    const affected = this.ownersOf(res.recomputed);
    if (fresh.length) { revert(affected); const iss = this.engineIssues(Object.fromEntries(fresh)); return { ok: false, issues: iss, recomputed: res.recomputed, affectedObjects: affected }; }
    p.expr = expr;
    this.reresolve(affected);
    const issues = this.validate(); const bad = newErrors(prevIssues, issues);
    if (bad.length) { revert(affected); return { ok: false, issues: bad, recomputed: res.recomputed, affectedObjects: affected }; }
    this.issues = issues;
    return { ok: true, issues, recomputed: res.recomputed, affectedObjects: affected };
  }
  private engineIssues(errs: Record<string, string>): Issue[] {
    return Object.entries(errs).map(([id, m]) => ({ severity: 'error' as const, message: `${id}: ${m}` }));
  }
  private ownersOf(nodeIds: string[]): string[] {
    const s = new Set<string>();
    for (const id of nodeIds) { if (id.startsWith('constraint:') || id.startsWith('level:')) s.add('*'); else if (id.includes('.')) s.add(id.split('.')[0]); }
    return [...s];
  }
  private reresolve(ids: string[]) {
    this.resolveLevels();
    if (ids.includes('*')) { this.resolveAll(); return; }
    const objs = this.project.objects.filter((o) => ids.includes(o.id));
    objs.filter((o) => o.type !== 'room').forEach((o) => this.resolveOne(o));
    const levels = new Set(objs.map((o) => o.level));
    for (const o of this.project.objects) if (o.type === 'room' && (ids.includes(o.id) || (objs.some((x) => x.type === 'wall') && levels.has(o.level)))) this.resolveOne(o);
  }
}

/** Half the thickness of the wall that this room edge runs along, or 0 if the edge is not on a wall. */
function roomEdgeInset(a: Vec2, b: Vec2, walls: RWall[]): number {
  const mid = v2((a.x + b.x) / 2, (a.y + b.y) / 2), d = normalize(sub(b, a));
  let best = 0;
  for (const w of walls) {
    const wd = normalize(sub(w.b, w.a));
    if (Math.abs(cross(d, wd)) > 1e-3 || Math.abs(dot(d, wd)) < 0.5) continue;
    const pr = projectOnSegment(mid, w.a, w.b);
    if (pr.distance < 1) best = Math.max(best, w.thickness / 2);
  }
  return best;
}
export type { WallObj };
