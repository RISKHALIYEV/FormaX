import type { RWall, ROpening } from './model';
export interface LocalBox { x0: number; x1: number; z0: number; z1: number }
/**
 * Splits a wall into axis-aligned boxes (wall-local frame: x along the wall from its start, z up) leaving real openings
 * for doors and windows. Used by the 3D renderer; pure and unit-tested.
 */
export function wallBoxes(w: RWall, openings: ROpening[]): LocalBox[] {
  const ext = w.thickness / 2, start = w.extendStart ? -ext : 0, end = w.length + (w.extendEnd ? ext : 0), H = w.height;
  const boxes: LocalBox[] = []; let cur = start;
  for (const o of [...openings].sort((p, q) => p.offset - q.offset)) {
    const x0 = Math.max(start, o.offset - o.width / 2), x1 = Math.min(end, o.offset + o.width / 2);
    if (x1 <= x0) continue;
    if (x0 > cur) boxes.push({ x0: cur, x1: x0, z0: 0, z1: H });
    if (o.sill > 0) boxes.push({ x0, x1, z0: 0, z1: Math.min(o.sill, H) });
    if (o.sill + o.height < H) boxes.push({ x0, x1, z0: Math.max(0, o.sill + o.height), z1: H });
    cur = Math.max(cur, x1);
  }
  if (end > cur) boxes.push({ x0: cur, x1: end, z0: 0, z1: H });
  return boxes;
}
export const boxVolume = (b: LocalBox, t: number): number => (b.x1 - b.x0) * (b.z1 - b.z0) * t;
