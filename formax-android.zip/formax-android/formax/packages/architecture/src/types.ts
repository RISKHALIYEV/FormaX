import type { LengthUnit } from '@formax/geometry';
/** A numeric model value: literal millimetres or a formula over named parameters. */
export type Expr = number | string;
export interface P2E { x: Expr; y: Expr }
export type ObjType = 'wall' | 'room' | 'door' | 'window' | 'slab' | 'roof' | 'column' | 'beam' | 'dimension' | 'line' | 'polyline' | 'circle';
interface Base { id: string; type: ObjType; name: string; layer: string; level: string; material: string; parent?: string }
export interface WallObj extends Base { type: 'wall'; a: P2E; b: P2E; thickness: Expr; height: Expr; extendStart: boolean; extendEnd: boolean }
export interface OpeningObj extends Base { type: 'door' | 'window'; host: string; offset: Expr; width: Expr; height: Expr; sill: Expr }
export interface RoomObj extends Base { type: 'room'; points: P2E[] }
export interface SlabObj extends Base { type: 'slab'; points: P2E[]; thickness: Expr; top: Expr }
export interface RoofObj extends Base { type: 'roof'; points: P2E[]; thickness: Expr; elevation: Expr }
export interface ColumnObj extends Base { type: 'column'; p: P2E; width: Expr; depth: Expr; height: Expr }
export interface BeamObj extends Base { type: 'beam'; a: P2E; b: P2E; width: Expr; depth: Expr; elevation: Expr }
export interface DimensionObj extends Base { type: 'dimension'; a: P2E; b: P2E; offset: Expr }
export interface LineObj extends Base { type: 'line'; a: P2E; b: P2E }
export interface PolylineObj extends Base { type: 'polyline'; points: P2E[] }
export interface CircleObj extends Base { type: 'circle'; c: P2E; r: Expr }
export type ArchObject = WallObj | OpeningObj | RoomObj | SlabObj | RoofObj | ColumnObj | BeamObj | DimensionObj | LineObj | PolylineObj | CircleObj;
export interface Level { id: string; name: string; elevation: Expr; height: Expr }
export interface ParamDef { name: string; expr: string; description?: string }
export interface ConstraintDef { id: string; name: string; expr: string; message: string }
export interface Layer { id: string; name: string; visible: boolean; locked: boolean }
export interface MaterialDef { id: string; name: string; color: string }
export interface HistoryEntry { time: string; name: string; from: string; to: string }
export interface Project {
  id: string; name: string; units: LengthUnit;
  parameters: ParamDef[]; constraints: ConstraintDef[]; levels: Level[]; layers: Layer[]; materials: MaterialDef[];
  objects: ArchObject[]; parameterHistory: HistoryEntry[];
}
export interface Issue { severity: 'error' | 'warning'; objectId?: string; message: string }
