import { Vec2, v2, dist, projectOnSegment, segmentIntersection, nearlyEqual } from '@formax/geometry';
import type { ArchModel } from './model';
import type { Expr, P2E } from './types';
import { getPath } from './fields';

export type SnapKind = 'endpoint' | 'midpoint' | 'intersection' | 'edge' | 'grid' | 'free';
export interface SnapOptions { tol: number; grid: number; endpoints: boolean; midpoints: boolean; intersections: boolean; edges: boolean; gridOn: boolean; level: string; anchor?: { pt: Vec2; ex: P2E }; ortho?: boolean }
export interface SnapResult { point: Vec2; ex: P2E; kind: SnapKind }
const PRIORITY: Record<SnapKind, number> = { endpoint: 0, intersection: 1, midpoint: 2, edge: 3, grid: 4, free: 5 };
const wrap = (e: Expr): string => { const s = String(e); return /^[\w.]+$/.test(s) ? s : `(${s})`; };
const isZero = (e: Expr) => typeof e === 'number' && e === 0;
/** Expression for the midpoint of two coordinate expressions; keeps the parametric relation. */
export function midExpr(a: Expr, b: Expr): Expr {
  if (typeof a === 'number' && typeof b === 'number') return (a + b) / 2;
  if (String(a) === String(b)) return a;
  if (isZero(a)) return `${wrap(b)} / 2`;
  if (isZero(b)) return `${wrap(a)} / 2`;
  return `(${wrap(a)} + ${wrap(b)}) / 2`;
}
const r1 = (n: number) => Math.round(n * 1000) / 1000;

interface Seg { ra: Vec2; rb: Vec2; ea: P2E; eb: P2E }
export function findSnap(model: ArchModel, cursor: Vec2, o: SnapOptions): SnapResult {
  const anchors: { pt: Vec2; ex: P2E }[] = [], segs: Seg[] = [];
  for (const obj of model.project.objects) {
    if (obj.level !== o.level) continue;
    const r = model.get(obj.id); if (!r) continue;
    if ((obj.type === 'wall' || obj.type === 'line' || obj.type === 'beam') && (r.type === 'wall' || r.type === 'line' || r.type === 'beam')) {
      segs.push({ ra: r.a, rb: r.b, ea: obj.a, eb: obj.b });
      anchors.push({ pt: r.a, ex: obj.a }, { pt: r.b, ex: obj.b });
    } else if ((obj.type === 'room' || obj.type === 'slab' || obj.type === 'roof') && 'points' in r) {
      r.points.forEach((p, i) => anchors.push({ pt: p, ex: obj.points[i] }));
    } else if (obj.type === 'column' && r.type === 'column') anchors.push({ pt: r.p, ex: obj.p });
  }
  let c = cursor;
  const anc = o.anchor;
  if (o.ortho && anc) c = Math.abs(c.x - anc.pt.x) >= Math.abs(c.y - anc.pt.y) ? v2(c.x, anc.pt.y) : v2(anc.pt.x, c.y);
  const cands: SnapResult[] = [];
  if (o.endpoints) for (const a of anchors) if (dist(a.pt, c) <= o.tol) cands.push({ point: a.pt, ex: a.ex, kind: 'endpoint' });
  if (o.midpoints) for (const s of segs) {
    const m = v2((s.ra.x + s.rb.x) / 2, (s.ra.y + s.rb.y) / 2);
    if (dist(m, c) <= o.tol) cands.push({ point: m, ex: { x: midExpr(s.ea.x, s.eb.x), y: midExpr(s.ea.y, s.eb.y) }, kind: 'midpoint' });
  }
  const vertical = (s: Seg) => nearlyEqual(s.ra.x, s.rb.x, 1e-6), horizontal = (s: Seg) => nearlyEqual(s.ra.y, s.rb.y, 1e-6);
  if (o.intersections) for (let i = 0; i < segs.length; i++) for (let j = i + 1; j < segs.length; j++) {
    const hit = segmentIntersection(segs[i].ra, segs[i].rb, segs[j].ra, segs[j].rb); if (!hit || dist(hit.point, c) > o.tol) continue;
    const [s, t] = [segs[i], segs[j]]; let ex: P2E = { x: r1(hit.point.x), y: r1(hit.point.y) };
    if (vertical(s) && horizontal(t)) ex = { x: s.ea.x, y: t.ea.y }; else if (horizontal(s) && vertical(t)) ex = { x: t.ea.x, y: s.ea.y };
    cands.push({ point: hit.point, ex, kind: 'intersection' });
  }
  if (o.edges) for (const s of segs) {
    const pr = projectOnSegment(c, s.ra, s.rb); if (pr.distance > o.tol) continue;
    const g = o.gridOn && o.grid > 0 ? o.grid : 1, snapN = (n: number) => Math.round(n / g) * g;
    if (vertical(s)) cands.push({ point: v2(s.ra.x, snapN(pr.point.y)), ex: { x: s.ea.x, y: snapN(pr.point.y) }, kind: 'edge' });
    else if (horizontal(s)) cands.push({ point: v2(snapN(pr.point.x), s.ra.y), ex: { x: snapN(pr.point.x), y: s.ea.y }, kind: 'edge' });
    else cands.push({ point: pr.point, ex: { x: r1(pr.point.x), y: r1(pr.point.y) }, kind: 'edge' });
  }
  let best: SnapResult | undefined;
  for (const k of cands) if (!best || PRIORITY[k.kind] < PRIORITY[best.kind] || (PRIORITY[k.kind] === PRIORITY[best.kind] && dist(k.point, c) < dist(best.point, c))) best = k;
  if (!best) {
    const g = o.gridOn && o.grid > 0 ? o.grid : 0, f = (n: number) => (g ? Math.round(n / g) * g : Math.round(n));
    best = { point: v2(f(c.x), f(c.y)), ex: { x: f(c.x), y: f(c.y) }, kind: g ? 'grid' : 'free' };
  }
  if (o.ortho && anc) { // keep the locked coordinate bound to the anchor so alignment stays parametric
    const lockX = Math.abs(best.point.x - anc.pt.x) < Math.abs(best.point.y - anc.pt.y);
    best = lockX ? { ...best, point: v2(anc.pt.x, best.point.y), ex: { x: anc.ex.x, y: best.ex.y } } : { ...best, point: v2(best.point.x, anc.pt.y), ex: { x: best.ex.x, y: anc.ex.y } };
  }
  return best;
}
export const exprOf = (model: ArchModel, id: string, path: string): Expr => { const o = model.project.objects.find((x) => x.id === id); return o ? getPath(o, path) : 0; };
