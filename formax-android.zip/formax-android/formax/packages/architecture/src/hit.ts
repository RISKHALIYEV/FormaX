import { Vec2, projectOnSegment, pointInPolygon, dist, sub, normalize, dot, perp, polygonCentroid } from '@formax/geometry';
import type { ArchModel, RObj } from './model';
/** Object under a plan-space point (mm). Smaller/topmost items win: openings > walls > columns/beams/lines > rooms > slabs. */
export function hitTest(model: ArchModel, p: Vec2, tol: number, level: string, visibleLayers?: Set<string>): string | null {
  const order: Record<string, number> = { door: 0, window: 0, dimension: 1, line: 1, polyline: 1, circle: 1, column: 2, beam: 2, wall: 3, room: 4, slab: 5, roof: 6 };
  let best: { id: string; rank: number; d: number } | null = null;
  const consider = (o: RObj, d: number) => { const rank = order[o.type]; if (!best || rank < best.rank || (rank === best.rank && d < best.d)) best = { id: o.id, rank, d }; };
  for (const o of model.resolved.values()) {
    if (o.level !== level || (visibleLayers && !visibleLayers.has(o.layer))) continue;
    switch (o.type) {
      case 'wall': { const pr = projectOnSegment(p, o.a, o.b); if (pr.distance <= o.thickness / 2 + tol) consider(o, pr.distance); break; }
      case 'door': case 'window': {
        const w = model.get(o.host); if (w?.type !== 'wall') break;
        const d = normalize(sub(w.b, w.a)), t = dot(sub(p, w.a), d), n = Math.abs(dot(sub(p, w.a), perp(d)));
        if (Math.abs(t - o.offset) <= o.width / 2 + tol && n <= w.thickness / 2 + tol) consider(o, 0); break;
      }
      case 'column': if (Math.abs(p.x - o.p.x) <= o.width / 2 + tol && Math.abs(p.y - o.p.y) <= o.depth / 2 + tol) consider(o, dist(p, o.p)); break;
      case 'beam': case 'line': case 'dimension': { const pr = projectOnSegment(p, o.a, o.b); if (pr.distance <= tol) consider(o, pr.distance); break; }
      case 'polyline': for (let i = 0; i + 1 < o.points.length; i++) { const pr = projectOnSegment(p, o.points[i], o.points[i + 1]); if (pr.distance <= tol) consider(o, pr.distance); } break;
      case 'circle': { const d = Math.abs(dist(p, o.c) - o.r); if (d <= tol) consider(o, d); break; }
      case 'room': case 'slab': case 'roof': { const pts = o.type === 'room' ? o.net : o.points; if (pointInPolygon(p, pts)) consider(o, dist(p, polygonCentroid(pts))); break; }
    }
  }
  return best ? (best as { id: string }).id : null;
}
