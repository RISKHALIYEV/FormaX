import { Vec2, v2, rotate as rot, dist } from '@formax/geometry';
import type { ArchObject, Expr, Level, ObjType, OpeningObj, P2E, Project, WallObj } from './types';
import type { ArchModel } from './model';
import { exprPaths, getPath, nextId, parseExprInput, setPath, isValidParamName } from './fields';

const LAYER: Record<ObjType, string> = { wall: 'walls', room: 'rooms', door: 'openings', window: 'openings', slab: 'slabs', roof: 'slabs', column: 'structure', beam: 'structure', dimension: 'annotations', line: 'draft', polyline: 'draft', circle: 'draft' };
const MATERIAL: Record<ObjType, string> = { wall: 'plaster', room: 'tile', door: 'wood', window: 'glass', slab: 'concrete', roof: 'concrete', column: 'concrete', beam: 'concrete', dimension: 'plaster', line: 'plaster', polyline: 'plaster', circle: 'plaster' };

export function defaultProject(name = 'Untitled project'): Project {
  return {
    id: `prj-${Date.now().toString(36)}`, name, units: 'mm',
    parameters: [
      { name: 'floor_height', expr: '3200', description: 'Storey height' }, { name: 'wall_thickness', expr: '200', description: 'Exterior wall thickness' },
      { name: 'interior_thickness', expr: '100', description: 'Interior wall thickness' }, { name: 'door_width', expr: '900' }, { name: 'door_height', expr: '2100' },
      { name: 'window_width', expr: '1200' }, { name: 'window_height', expr: '1200' }, { name: 'window_sill', expr: '900' },
    ],
    constraints: [], levels: [{ id: 'L1', name: 'Ground floor', elevation: 0, height: 'floor_height' }],
    layers: ['walls', 'rooms', 'openings', 'slabs', 'structure', 'annotations', 'draft'].map((id) => ({ id, name: id[0].toUpperCase() + id.slice(1), visible: true, locked: false })),
    materials: [
      { id: 'plaster', name: 'Plaster', color: '#d9d4c7' }, { id: 'brick', name: 'Brick', color: '#a65b45' }, { id: 'concrete', name: 'Concrete', color: '#9a9a96' },
      { id: 'wood', name: 'Timber', color: '#8b6b45' }, { id: 'glass', name: 'Glass', color: '#9cc7dc' }, { id: 'tile', name: 'Tile', color: '#c9c2b2' },
    ],
    objects: [], parameterHistory: [],
  };
}
const base = (p: Project, type: ObjType, prefix: string, level: string, label: string) => {
  const id = nextId(p, prefix); const n = p.objects.filter((o) => o.type === type).length + 1;
  return { id, type, name: `${label} ${n}`, layer: LAYER[type], level, material: MATERIAL[type] } as const;
};
export function ensureParam(p: Project, name: string, expr: string): void { if (!p.parameters.some((q) => q.name === name)) p.parameters.push({ name, expr }); }
const uniqueParam = (p: Project, name: string): string => { let n = name, i = 2; while (p.parameters.some((q) => q.name === n)) n = `${name}_${i++}`; return n; };
const levelOf = (p: Project, id: string): Level => { const l = p.levels.find((x) => x.id === id); if (!l) throw new Error(`Unknown level '${id}'`); return l; };
const plus = (a: Expr, b: Expr): Expr => (typeof a === 'number' && typeof b === 'number' ? a + b : a === 0 ? b : b === 0 ? a : `${a} + ${b}`);
const r3 = (n: number) => Math.round(n * 1000) / 1000;
/** Offset an expression by a distance, preserving its formula. */
export function shiftExpr(e: Expr, d: number): Expr {
  if (Math.abs(d) < 1e-9) return e;
  if (typeof e === 'number') return r3(e + d);
  const s = /^[\w.]+$/.test(e) ? e : `(${e})`; return d > 0 ? `${s} + ${r3(d)}` : `${s} - ${r3(-d)}`;
}

export function addWall(p: Project, o: { a: P2E; b: P2E; level: string; exterior?: boolean }): string {
  levelOf(p, o.level); ensureParam(p, o.exterior ? 'wall_thickness' : 'interior_thickness', o.exterior ? '200' : '100'); ensureParam(p, 'floor_height', '3200');
  const lv = levelOf(p, o.level);
  const w: WallObj = { ...base(p, 'wall', 'w', o.level, o.exterior ? 'Exterior wall' : 'Interior wall'), type: 'wall', a: o.a, b: o.b, thickness: o.exterior ? 'wall_thickness' : 'interior_thickness', height: lv.height, extendStart: !!o.exterior, extendEnd: !!o.exterior, parent: o.level };
  p.objects.push(w); return w.id;
}
/** Rectangular building footprint: creates width/length parameters and four parametric walls (+ ground slab). */
export function addBuildingFootprint(p: Project, o: { x: number; y: number; width: number; length: number; level: string }): { ids: string[]; widthParam: string; lengthParam: string } {
  if (!(o.width > 0 && o.length > 0)) throw new Error('Footprint width and length must be positive.');
  const wp = uniqueParam(p, 'building_width'), lp = uniqueParam(p, 'building_length');
  p.parameters.push({ name: wp, expr: String(Math.round(o.width)), description: 'Building width (X)' }, { name: lp, expr: String(Math.round(o.length)), description: 'Building length (Y)' });
  const X1 = plus(o.x, wp), Y1 = plus(o.y, lp);
  const pts: P2E[] = [{ x: o.x, y: o.y }, { x: X1, y: o.y }, { x: X1, y: Y1 }, { x: o.x, y: Y1 }];
  const ids = pts.map((a, i) => addWall(p, { a, b: pts[(i + 1) % 4], level: o.level, exterior: true }));
  const sid = nextId(p, 's');
  p.objects.push({ ...base(p, 'slab', 's', o.level, 'Slab'), id: sid, type: 'slab', points: pts.map((q) => ({ ...q })), thickness: 200, top: 0, parent: o.level });
  return { ids: [...ids, sid], widthParam: wp, lengthParam: lp };
}
export function addRoom(p: Project, o: { points: P2E[]; level: string; name?: string }): string {
  levelOf(p, o.level); const b = base(p, 'room', 'r', o.level, 'Room');
  p.objects.push({ ...b, type: 'room', name: o.name ?? b.name, points: o.points.map((q) => ({ ...q })), parent: o.level }); return b.id;
}
export function addOpening(p: Project, o: { type: 'door' | 'window'; host: string; offset: number; level: string }): string {
  const host = p.objects.find((x) => x.id === o.host && x.type === 'wall'); if (!host) throw new Error(`Host wall '${o.host}' not found.`);
  const d = o.type === 'door';
  for (const [n, e] of d ? [['door_width', '900'], ['door_height', '2100']] : [['window_width', '1200'], ['window_height', '1200'], ['window_sill', '900']]) ensureParam(p, n, e);
  const b = base(p, o.type, d ? 'd' : 'n', o.level, d ? 'Door' : 'Window');
  const ob: OpeningObj = { ...b, type: o.type, host: o.host, offset: Math.round(o.offset), width: d ? 'door_width' : 'window_width', height: d ? 'door_height' : 'window_height', sill: d ? 0 : 'window_sill', parent: o.host };
  p.objects.push(ob); return b.id;
}
export function addGeneric(p: Project, type: 'line' | 'polyline' | 'circle' | 'dimension' | 'column' | 'beam' | 'slab' | 'roof', level: string, data: Record<string, unknown>): string {
  levelOf(p, level);
  const prefix = { line: 'ln', polyline: 'pl', circle: 'c', dimension: 'dm', column: 'col', beam: 'bm', slab: 's', roof: 'rf' }[type];
  const b = base(p, type, prefix, level, type[0].toUpperCase() + type.slice(1));
  p.objects.push({ ...b, parent: level, ...data } as ArchObject); return b.id;
}
export function addLevel(p: Project, name?: string): string {
  const last = p.levels[p.levels.length - 1]; const id = nextId(p, 'L');
  p.levels.push({ id, name: name ?? `Level ${p.levels.length + 1}`, elevation: plus(last.elevation, last.height), height: last.height }); return id;
}
/** Copies the walls, rooms, columns, beams and openings of one level to another (formulas are preserved). */
export function copyLevelContent(p: Project, from: string, to: string): string[] {
  levelOf(p, from); levelOf(p, to);
  const map = new Map<string, string>(), out: ArchObject[] = [];
  const src = p.objects.filter((o) => o.level === from && !['roof', 'dimension'].includes(o.type));
  const prefixOf = (o: ArchObject) => o.id.replace(/\d+$/, '');
  for (const o of src.filter((x) => x.type !== 'door' && x.type !== 'window')) { const c = structuredClone(o); c.id = nextId({ ...p, objects: [...p.objects, ...out] }, prefixOf(o)); c.level = to; c.parent = to; map.set(o.id, c.id); out.push(c); }
  for (const o of src.filter((x) => x.type === 'door' || x.type === 'window')) { const c = structuredClone(o) as OpeningObj; c.id = nextId({ ...p, objects: [...p.objects, ...out] }, prefixOf(o)); c.level = to; c.host = map.get(c.host) ?? c.host; c.parent = c.host; out.push(c); }
  p.objects.push(...out); return out.map((o) => o.id);
}
export function addRoofFromSlab(p: Project, level: string): string {
  const slab = p.objects.find((o) => o.level === level && o.type === 'slab'); if (!slab || slab.type !== 'slab') throw new Error('The level needs a slab (footprint) to derive a roof from.');
  const lv = levelOf(p, level);
  return addGeneric(p, 'roof', level, { points: structuredClone(slab.points), thickness: 200, elevation: lv.height });
}
export function deleteObjects(p: Project, ids: string[]): void {
  const set = new Set(ids);
  for (const o of p.objects) if ((o.type === 'door' || o.type === 'window') && set.has(o.host)) set.add(o.id);
  p.objects = p.objects.filter((o) => !set.has(o.id));
}
export function setField(p: Project, id: string, path: string, input: string): void {
  const o = p.objects.find((x) => x.id === id); if (!o) throw new Error(`Object '${id}' not found`);
  if (!exprPaths(o).includes(path)) throw new Error(`'${path}' is not an editable field of ${id}`);
  setPath(o, path, parseExprInput(input));
}
export function setProp(p: Project, id: string, key: 'name' | 'layer' | 'material', value: string): void {
  const o = p.objects.find((x) => x.id === id); if (!o) throw new Error(`Object '${id}' not found`); o[key] = value;
}
export function addParameter(p: Project, name: string, expr: string, description?: string): void {
  if (!isValidParamName(name)) throw new Error(`'${name}' is not a valid parameter name (letters, digits, underscore; not starting with a digit; not a reserved word).`);
  if (p.parameters.some((q) => q.name === name)) throw new Error(`Parameter '${name}' already exists.`);
  p.parameters.push({ name, expr, description });
}
export function removeParameter(p: Project, name: string): void { p.parameters = p.parameters.filter((q) => q.name !== name); }
export function addConstraint(p: Project, name: string, expr: string, message: string): void { p.constraints.push({ id: nextId({ ...p, objects: [], levels: p.constraints.map((c) => ({ id: c.id } as Level)) }, 'k'), name, expr, message }); }
export function removeConstraint(p: Project, id: string): void { p.constraints = p.constraints.filter((c) => c.id !== id); }

const posPrefixes = (o: ArchObject): string[] => [...new Set(exprPaths(o).filter((q) => q.endsWith('.x')).map((q) => q.slice(0, -2)))];
export function translate(p: Project, ids: string[], dx: number, dy: number): void {
  for (const o of p.objects) if (ids.includes(o.id)) for (const pre of posPrefixes(o)) { setPath(o, `${pre}.x`, shiftExpr(getPath(o, `${pre}.x`), dx)); setPath(o, `${pre}.y`, shiftExpr(getPath(o, `${pre}.y`), dy)); }
}
const numAt = (m: ArchModel, o: ArchObject, path: string): number => { const e = getPath(o, path); const v = typeof e === 'number' ? e : m.engine.value(`${o.id}.${path}`); if (typeof v !== 'number') throw new Error(`${o.id}.${path} is not valid`); return v; };
/** Rotation / scaling write numeric coordinates for moved points (formula bindings of those points are baked). */
export function transformPoints(p: Project, m: ArchModel, ids: string[], f: (q: Vec2) => Vec2): void {
  for (const o of p.objects) if (ids.includes(o.id)) for (const pre of posPrefixes(o)) {
    const q = f(v2(numAt(m, o, `${pre}.x`), numAt(m, o, `${pre}.y`))); setPath(o, `${pre}.x`, r3(q.x)); setPath(o, `${pre}.y`, r3(q.y));
  }
}
export function rotateObjects(p: Project, m: ArchModel, ids: string[], angleRad: number, center: Vec2): void { transformPoints(p, m, ids, (q) => rot(q, angleRad, center)); }
export function scaleObjects(p: Project, m: ArchModel, ids: string[], k: number, center: Vec2): void {
  if (!(k > 0) || !Number.isFinite(k)) throw new Error('Scale factor must be a positive number.');
  const set = new Set(ids);
  for (const o of p.objects) {
    if (o.type === 'circle' && set.has(o.id)) setPath(o, 'r', r3(numAt(m, o, 'r') * k));
    if ((o.type === 'door' || o.type === 'window') && set.has(o.host)) setPath(o, 'offset', r3(numAt(m, o, 'offset') * k));
  }
  transformPoints(p, m, ids, (q) => v2(center.x + (q.x - center.x) * k, center.y + (q.y - center.y) * k));
}
export function duplicateObjects(p: Project, ids: string[], dx: number, dy: number): string[] {
  const map = new Map<string, string>(), made: ArchObject[] = [];
  const src = p.objects.filter((o) => ids.includes(o.id) && o.type !== 'door' && o.type !== 'window');
  for (const o of src) { const c = structuredClone(o); c.id = nextId({ ...p, objects: [...p.objects, ...made] }, o.id.replace(/\d+$/, '')); map.set(o.id, c.id); made.push(c); }
  const tmp = { ...p, objects: [...p.objects, ...made] };
  for (const o of p.objects) if ((o.type === 'door' || o.type === 'window') && map.has(o.host)) { const c = structuredClone(o); c.id = nextId({ ...tmp, objects: [...tmp.objects, ...made] }, o.id.replace(/\d+$/, '')); c.host = map.get(o.host)!; c.parent = c.host; made.push(c); }
  p.objects.push(...made);
  translate(p, made.filter((o) => o.type !== 'door' && o.type !== 'window').map((o) => o.id), dx, dy);
  return made.map((o) => o.id);
}
export const centerOf = (m: ArchModel, ids: string[]): Vec2 => {
  const pts: Vec2[] = [];
  for (const id of ids) { const r = m.get(id); if (!r) continue; if ('points' in r) pts.push(...r.points); else if ('a' in r && 'b' in r) pts.push(r.a, r.b); else if ('p' in r) pts.push(r.p); else if ('c' in r) pts.push(r.c); }
  if (!pts.length) return v2(0, 0);
  return v2(pts.reduce((s, q) => s + q.x, 0) / pts.length, pts.reduce((s, q) => s + q.y, 0) / pts.length);
};
export { dist };
