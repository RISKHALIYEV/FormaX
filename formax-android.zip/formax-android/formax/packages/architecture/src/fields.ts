import type { ArchObject, Expr, Project } from './types';
/** Paths (dot notation) of every expression-valued field of an object. */
export function exprPaths(o: ArchObject): string[] {
  const pts = (k: string, n: number) => Array.from({ length: n }, (_, i) => [`${k}.${i}.x`, `${k}.${i}.y`]).flat();
  switch (o.type) {
    case 'wall': return ['a.x', 'a.y', 'b.x', 'b.y', 'thickness', 'height'];
    case 'door': case 'window': return ['offset', 'width', 'height', 'sill'];
    case 'room': case 'polyline': return pts('points', o.points.length);
    case 'slab': return [...pts('points', o.points.length), 'thickness', 'top'];
    case 'roof': return [...pts('points', o.points.length), 'thickness', 'elevation'];
    case 'column': return ['p.x', 'p.y', 'width', 'depth', 'height'];
    case 'beam': return ['a.x', 'a.y', 'b.x', 'b.y', 'width', 'depth', 'elevation'];
    case 'dimension': return ['a.x', 'a.y', 'b.x', 'b.y', 'offset'];
    case 'line': return ['a.x', 'a.y', 'b.x', 'b.y'];
    case 'circle': return ['c.x', 'c.y', 'r'];
  }
}
export function getPath(o: unknown, path: string): Expr {
  return path.split('.').reduce((c: any, k) => c[k], o) as Expr;
}
export function setPath(o: unknown, path: string, v: Expr): void {
  const ks = path.split('.'); const last = ks.pop()!;
  (ks.reduce((c: any, k) => c[k], o) as any)[last] = v;
}
/** Convert user text to a stored Expr: plain numbers become literals, everything else stays a formula. */
export function parseExprInput(s: string): Expr {
  const t = s.trim();
  return t !== '' && /^[+-]?(\d+\.?\d*|\.\d+)$/.test(t) ? Number(t) : t;
}
export const exprText = (e: Expr): string => String(e);
export function nextId(p: Project, prefix: string): string {
  let max = 0;
  for (const id of [...p.objects.map((o) => o.id), ...p.levels.map((l) => l.id)]) {
    const m = new RegExp(`^${prefix}(\\d+)$`).exec(id); if (m) max = Math.max(max, Number(m[1]));
  }
  return `${prefix}${max + 1}`;
}
export const RESERVED = new Set(['pi', 'true', 'false', 'if', 'min', 'max', 'abs', 'sqrt', 'round', 'floor', 'ceil', 'sin', 'cos', 'tan', 'rad', 'deg', 'pow', 'clamp', '__proto__', 'constructor', 'prototype', 'toString', 'hasOwnProperty']);
export const isValidParamName = (n: string): boolean => /^[A-Za-z_][A-Za-z0-9_]*$/.test(n) && !RESERVED.has(n);
