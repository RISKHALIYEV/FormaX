import { Ast, ExprError, Value, collectIdentifiers, evaluateAst, parseExpr } from './expr';

export interface NodeInput { expr: string; referenceable: boolean }
interface Node { id: string; expr: string; referenceable: boolean; ast?: Ast; deps: string[]; parseError?: string }
export interface UpdateResult { ok: boolean; recomputed: string[]; errors: Record<string, string> }

/**
 * Directed dependency graph over named formula nodes (parameters are referenceable; object fields / constraints are leaves).
 * - cycle detection (reports the cycle path)
 * - incremental recomputation: only the changed nodes and their transitive dependents are re-evaluated
 * - transactions: `transaction()` reverts every change when the result would contain errors
 */
export class Engine {
  private nodes = new Map<string, Node>();
  private dependents = new Map<string, Set<string>>();
  private values = new Map<string, Value>();
  private errs = new Map<string, string>();

  get errors(): Record<string, string> { return Object.fromEntries(this.errs); }
  value(id: string): Value | undefined { return this.values.get(id); }
  error(id: string): string | undefined { return this.errs.get(id); }
  has(id: string): boolean { return this.nodes.has(id); }
  dependencies(id: string): string[] { return this.nodes.get(id)?.deps ?? []; }
  dependentsOf(id: string): string[] { return [...(this.dependents.get(id) ?? [])]; }
  nodeIds(): string[] { return [...this.nodes.keys()]; }

  /** Replace everything and evaluate all nodes. */
  load(defs: Record<string, NodeInput>): UpdateResult {
    this.nodes.clear(); this.values.clear(); this.errs.clear();
    for (const [id, d] of Object.entries(defs)) this.nodes.set(id, this.makeNode(id, d));
    this.rebuildEdges();
    return this.evaluate(new Set(this.nodes.keys()));
  }
  /** Apply changes (null removes a node) and recompute only what is affected. */
  update(changes: Record<string, NodeInput | null>): UpdateResult {
    const dirty = new Set<string>();
    for (const [id, d] of Object.entries(changes)) {
      if (d === null) { this.nodes.delete(id); this.values.delete(id); this.errs.delete(id); }
      else this.nodes.set(id, this.makeNode(id, d));
      dirty.add(id);
    }
    // dependents must be computed from the *old* edges too, so collect before rebuilding
    const before = new Set<string>(); dirty.forEach((id) => this.collectDependents(id, before));
    this.rebuildEdges();
    dirty.forEach((id) => this.collectDependents(id, dirty));
    before.forEach((id) => dirty.add(id));
    return this.evaluate(dirty);
  }
  /** Atomic update: if any error exists afterwards, revert and report. */
  transaction(changes: Record<string, NodeInput | null>): UpdateResult {
    const prev: Record<string, NodeInput | null> = {};
    for (const id of Object.keys(changes)) { const n = this.nodes.get(id); prev[id] = n ? { expr: n.expr, referenceable: n.referenceable } : null; }
    const res = this.update(changes);
    const relevant = Object.entries(res.errors);
    if (relevant.length) { this.update(prev); return { ok: false, recomputed: res.recomputed, errors: res.errors }; }
    return res;
  }
  /** Topological order of all valid nodes (dependencies first). */
  order(): string[] {
    const out: string[] = [], seen = new Set<string>();
    const visit = (id: string, stack: Set<string>) => {
      if (seen.has(id) || stack.has(id)) return; stack.add(id);
      for (const d of this.nodes.get(id)?.deps ?? []) if (this.nodes.has(d)) visit(d, stack);
      stack.delete(id); seen.add(id); out.push(id);
    };
    for (const id of this.nodes.keys()) visit(id, new Set());
    return out;
  }
  findCycles(): string[][] {
    const color = new Map<string, number>(), cycles: string[][] = [], path: string[] = [];
    const dfs = (id: string) => {
      color.set(id, 1); path.push(id);
      for (const d of this.nodes.get(id)?.deps ?? []) {
        if (!this.nodes.get(d)?.referenceable) continue;
        if (color.get(d) === 1) cycles.push([...path.slice(path.indexOf(d)), d]);
        else if (!color.get(d)) dfs(d);
      }
      path.pop(); color.set(id, 2);
    };
    for (const id of this.nodes.keys()) if (!color.get(id)) dfs(id);
    return cycles;
  }

  // ---- internals ----
  private makeNode(id: string, d: NodeInput): Node {
    try {
      const ast = parseExpr(d.expr);
      return { id, expr: d.expr, referenceable: d.referenceable, ast, deps: [...collectIdentifiers(ast)] };
    } catch (e) {
      return { id, expr: d.expr, referenceable: d.referenceable, deps: [], parseError: e instanceof ExprError ? `Invalid formula: ${e.message}` : String(e) };
    }
  }
  private rebuildEdges() {
    this.dependents.clear();
    for (const n of this.nodes.values()) for (const d of n.deps) {
      if (!this.dependents.has(d)) this.dependents.set(d, new Set());
      this.dependents.get(d)!.add(n.id);
    }
  }
  private collectDependents(id: string, into: Set<string>) {
    const stack = [id];
    while (stack.length) for (const d of this.dependents.get(stack.pop()!) ?? []) if (!into.has(d)) { into.add(d); stack.push(d); }
  }
  private evaluate(dirty: Set<string>): UpdateResult {
    const cycleNodes = new Map<string, string>();
    for (const c of this.findCycles()) { const msg = `Circular dependency: ${c.join(' → ')}`; c.forEach((n) => cycleNodes.set(n, msg)); }
    // nodes in a cycle (or depending on one) are errors, and always (re)reported
    const recomputed: string[] = [], touched = new Set<string>();
    for (const id of this.order()) {
      const node = this.nodes.get(id)!;
      const inCycle = cycleNodes.get(id);
      if (!dirty.has(id) && !inCycle && !node.deps.some((d) => touched.has(d))) continue;
      touched.add(id); recomputed.push(id); this.values.delete(id);
      if (inCycle) { this.errs.set(id, inCycle); continue; }
      if (node.parseError) { this.errs.set(id, node.parseError); continue; }
      const badDep = node.deps.find((d) => !this.nodes.has(d) || !this.nodes.get(d)!.referenceable);
      if (badDep) { this.errs.set(id, `Unknown parameter '${badDep}'`); continue; }
      const failed = node.deps.find((d) => this.errs.has(d));
      if (failed) { this.errs.set(id, `Depends on '${failed}' which has an error`); continue; }
      try { this.values.set(id, evaluateAst(node.ast!, (n) => this.values.get(n))); this.errs.delete(id); }
      catch (e) { this.errs.set(id, e instanceof ExprError ? e.message : String(e)); }
    }
    for (const id of [...this.errs.keys()]) if (!this.nodes.has(id)) this.errs.delete(id);
    return { ok: this.errs.size === 0, recomputed, errors: this.errors };
  }
}
