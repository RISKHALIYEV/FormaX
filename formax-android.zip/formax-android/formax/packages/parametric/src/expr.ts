/** Safe expression language for FormaX formulas. Hand-written tokenizer + recursive-descent parser. No eval / Function. */
export type Value = number | boolean;
export class ExprError extends Error { constructor(message: string, public pos = 0) { super(message); this.name = 'ExprError'; } }

export type Ast =
  | { k: 'num'; v: number } | { k: 'bool'; v: boolean } | { k: 'id'; name: string }
  | { k: 'un'; op: '-' | '+' | '!'; a: Ast } | { k: 'bin'; op: string; a: Ast; b: Ast }
  | { k: 'call'; fn: string; args: Ast[] };

interface Tok { t: 'num' | 'id' | 'op' | 'end'; v: string; pos: number }
const OPS = ['<=', '>=', '==', '!=', '&&', '||', '+', '-', '*', '/', '%', '^', '(', ')', ',', '<', '>', '!'];

function tokenize(src: string): Tok[] {
  const out: Tok[] = []; let i = 0;
  while (i < src.length) {
    const c = src[i];
    if (/\s/.test(c)) { i++; continue; }
    const num = /^(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?/.exec(src.slice(i));
    if (num) { out.push({ t: 'num', v: num[0], pos: i }); i += num[0].length; continue; }
    const id = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i));
    if (id) { out.push({ t: 'id', v: id[0], pos: i }); i += id[0].length; continue; }
    const op = OPS.find((o) => src.startsWith(o, i));
    if (!op) throw new ExprError(`Unexpected character '${c}'`, i);
    out.push({ t: 'op', v: op, pos: i }); i += op.length;
  }
  out.push({ t: 'end', v: '', pos: src.length });
  return out;
}

class Parser {
  private i = 0;
  constructor(private toks: Tok[]) {}
  private get cur() { return this.toks[this.i]; }
  private isOp(v: string) { return this.cur.t === 'op' && this.cur.v === v; }
  private eat(v: string) { if (!this.isOp(v)) throw new ExprError(`Expected '${v}'`, this.cur.pos); this.i++; }
  parse(): Ast {
    const a = this.or();
    if (this.cur.t !== 'end') throw new ExprError(`Unexpected '${this.cur.v}'`, this.cur.pos);
    return a;
  }
  private level(ops: string[], next: () => Ast): Ast {
    let a = next();
    while (this.cur.t === 'op' && ops.includes(this.cur.v)) { const op = this.cur.v; this.i++; a = { k: 'bin', op, a, b: next() }; }
    return a;
  }
  private or = (): Ast => this.level(['||'], () => this.and());
  private and = (): Ast => this.level(['&&'], () => this.eq());
  private eq = (): Ast => this.level(['==', '!='], () => this.cmp());
  private cmp = (): Ast => this.level(['<', '>', '<=', '>='], () => this.add());
  private add = (): Ast => this.level(['+', '-'], () => this.mul());
  private mul = (): Ast => this.level(['*', '/', '%'], () => this.unary());
  private unary(): Ast {
    if (this.cur.t === 'op' && ['-', '+', '!'].includes(this.cur.v)) { const op = this.cur.v as '-' | '+' | '!'; this.i++; return { k: 'un', op, a: this.unary() }; }
    return this.pow();
  }
  private pow(): Ast {
    const a = this.primary();
    if (this.isOp('^')) { this.i++; return { k: 'bin', op: '^', a, b: this.unary() }; } // right-associative
    return a;
  }
  private primary(): Ast {
    const t = this.cur;
    if (t.t === 'num') { this.i++; return { k: 'num', v: Number(t.v) }; }
    if (t.t === 'id') {
      this.i++;
      if (t.v === 'true' || t.v === 'false') return { k: 'bool', v: t.v === 'true' };
      if (this.isOp('(')) {
        this.i++; const args: Ast[] = [];
        if (!this.isOp(')')) { do { args.push(this.or()); if (this.isOp(',')) this.i++; else break; } while (true); }
        this.eat(')'); return { k: 'call', fn: t.v, args };
      }
      return { k: 'id', name: t.v };
    }
    if (this.isOp('(')) { this.i++; const a = this.or(); this.eat(')'); return a; }
    throw new ExprError(t.t === 'end' ? 'Unexpected end of formula' : `Unexpected '${t.v}'`, t.pos);
  }
}
export function parseExpr(src: string): Ast {
  if (!src.trim()) throw new ExprError('Formula is empty');
  return new Parser(tokenize(src)).parse();
}
const CONSTANTS: Record<string, number> = { pi: Math.PI };
const own = (o: object, k: string): boolean => Object.prototype.hasOwnProperty.call(o, k);
export function collectIdentifiers(ast: Ast, out = new Set<string>()): Set<string> {
  switch (ast.k) {
    case 'id': if (!own(CONSTANTS, ast.name)) out.add(ast.name); break;
    case 'un': collectIdentifiers(ast.a, out); break;
    case 'bin': collectIdentifiers(ast.a, out); collectIdentifiers(ast.b, out); break;
    case 'call': ast.args.forEach((a) => collectIdentifiers(a, out)); break;
  }
  return out;
}
const FN: Record<string, [number, (...a: number[]) => number]> = {
  min: [-1, Math.min], max: [-1, Math.max], abs: [1, Math.abs], sqrt: [1, Math.sqrt], round: [1, Math.round],
  floor: [1, Math.floor], ceil: [1, Math.ceil], sin: [1, Math.sin], cos: [1, Math.cos], tan: [1, Math.tan],
  rad: [1, (d) => (d * Math.PI) / 180], deg: [1, (r) => (r * 180) / Math.PI], pow: [2, Math.pow],
  clamp: [3, (x, lo, hi) => Math.min(hi, Math.max(lo, x))],
};
const num = (v: Value, what: string): number => { if (typeof v !== 'number') throw new ExprError(`${what} must be a number, got a boolean`); return v; };
const bool = (v: Value, what: string): boolean => { if (typeof v !== 'boolean') throw new ExprError(`${what} must be true/false, got a number`); return v; };

export function evaluateAst(ast: Ast, scope: (name: string) => Value | undefined): Value {
  switch (ast.k) {
    case 'num': case 'bool': return ast.v;
    case 'id': {
      if (own(CONSTANTS, ast.name)) return CONSTANTS[ast.name];
      const v = scope(ast.name); if (v === undefined) throw new ExprError(`Unknown parameter '${ast.name}'`); return v;
    }
    case 'un': { const a = evaluateAst(ast.a, scope); return ast.op === '!' ? !bool(a, "Operand of '!'") : ast.op === '-' ? -num(a, "Operand of '-'") : num(a, "Operand of '+'"); }
    case 'bin': {
      const a = evaluateAst(ast.a, scope);
      if (ast.op === '&&') return bool(a, "Operand of '&&'") && bool(evaluateAst(ast.b, scope), "Operand of '&&'");
      if (ast.op === '||') return bool(a, "Operand of '||'") || bool(evaluateAst(ast.b, scope), "Operand of '||'");
      const b = evaluateAst(ast.b, scope);
      if (ast.op === '==') return a === b;
      if (ast.op === '!=') return a !== b;
      const x = num(a, `Left operand of '${ast.op}'`), y = num(b, `Right operand of '${ast.op}'`);
      switch (ast.op) {
        case '+': return x + y; case '-': return x - y; case '*': return x * y;
        case '/': if (y === 0) throw new ExprError('Division by zero'); return x / y;
        case '%': if (y === 0) throw new ExprError('Modulo by zero'); return x % y;
        case '^': return Math.pow(x, y);
        case '<': return x < y; case '>': return x > y; case '<=': return x <= y; case '>=': return x >= y;
      }
      throw new ExprError(`Unknown operator ${ast.op}`);
    }
    case 'call': {
      if (ast.fn === 'if') {
        if (ast.args.length !== 3) throw new ExprError('if() takes 3 arguments: if(condition, a, b)');
        return bool(evaluateAst(ast.args[0], scope), 'if() condition') ? evaluateAst(ast.args[1], scope) : evaluateAst(ast.args[2], scope);
      }
      const f = own(FN, ast.fn) ? FN[ast.fn] : undefined; if (!f) throw new ExprError(`Unknown function '${ast.fn}'`);
      if (f[0] >= 0 && ast.args.length !== f[0]) throw new ExprError(`${ast.fn}() takes ${f[0]} argument(s)`);
      if (f[0] < 0 && ast.args.length < 1) throw new ExprError(`${ast.fn}() needs at least 1 argument`);
      const r = f[1](...ast.args.map((a, i) => num(evaluateAst(a, scope), `Argument ${i + 1} of ${ast.fn}()`)));
      if (!Number.isFinite(r)) throw new ExprError(`${ast.fn}() produced a non-finite result`);
      return r;
    }
  }
}
export function evaluateExpr(src: string, scope: (name: string) => Value | undefined = () => undefined): Value {
  const v = evaluateAst(parseExpr(src), scope);
  if (typeof v === 'number' && !Number.isFinite(v)) throw new ExprError('Result is not a finite number');
  return v;
}
